package com.awal.glasslauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.*
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT
private const val PERIOD = 30L * 60 * 1000   // wallpaper changes every 30 minutes
private const val PICK = 11

class Day(val date: String, val code: Int, val max: Double, val min: Double)

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var bg: ImageView
    private lateinit var bubble: BubbleView
    private lateinit var card: LinearLayout
    private lateinit var wxBox: LinearLayout
    private lateinit var wxBig: TextView
    private lateinit var wxSmall: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var lastIdx = -1
    private var forecast: List<Day> = emptyList()
    private var allApps: List<AppItem> = emptyList()
    private val wpTick = Runnable { applyWallpaper(false) }
    private val wxTick = Runnable { refreshWeather() }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps() }
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, sp: Float, c: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = sp; setTextColor(c)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun glass(r: Int = 24) = GradientDrawable().apply {
        setColor(0x33FFFFFF); cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x66FFFFFF)
    }

    private fun btn(t: String, f: () -> Unit) = tv(t, 15f).apply {
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = glass(14)
        layoutParams = LinearLayout.LayoutParams(MP, WC).apply { topMargin = dp(10) }
        setOnClickListener { f() }
    }

    private fun glassDialog(content: View): Dialog {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        content.background = GradientDrawable().apply {
            setColor(Color.parseColor("#EE141C3A")); cornerRadius = dp(26).toFloat()
            setStroke(dp(1), 0x66FFFFFF)
        }
        dlg.setContentView(content)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), WC)
        return dlg
    }

    private fun vbox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
    }

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = getSharedPreferences("glass", MODE_PRIVATE)

        val root = FrameLayout(this)
        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageDrawable(defaultBg()) }
        root.addView(bg, FrameLayout.LayoutParams(MP, MP))
        root.addView(View(this).apply { setBackgroundColor(0x30000000) }, FrameLayout.LayoutParams(MP, MP))

        // top-left glass card: time + date (+ weather on the right)
        val timeTv = TextClock(this).apply {
            format12Hour = "hh:mm"; format24Hour = "HH:mm"; textSize = 44f
            setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        val dateTv = TextClock(this).apply {
            format12Hour = "EEE, MMM d"; format24Hour = "EEE, MMM d"; textSize = 15f
            setTextColor(0xDDFFFFFF.toInt()); setPadding(0, dp(2), dp(20), dp(4))
            setOnClickListener { showCalendar() }
        }
        wxBig = tv("", 20f, bold = true)
        wxSmall = tv("", 12f, 0xCCFFFFFF.toInt())
        wxBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.END; visibility = View.GONE
            addView(wxBig); addView(wxSmall)
            setOnClickListener { showForecast() }
        }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; addView(timeTv); addView(dateTv)
        }
        card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = glass(24); setPadding(dp(18), dp(10), dp(18), dp(12))
            addView(left, LinearLayout.LayoutParams(0, WC, 1f)); addView(wxBox)
        }
        root.addView(card, FrameLayout.LayoutParams(MP, WC).apply { setMargins(dp(14), dp(40), dp(14), 0) })

        // centre: glass circle with apps
        val dm = resources.displayMetrics
        val size = minOf((dm.widthPixels * 0.96).toInt(), (dm.heightPixels * 0.55).toInt())
        bubble = BubbleView(this)
        root.addView(bubble, FrameLayout.LayoutParams(size, size, Gravity.CENTER))

        // settings button
        val gear = tv("⚙", 22f).apply {
            gravity = Gravity.CENTER; background = glass(24); setOnClickListener { showSettings() }
        }
        root.addView(gear, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(24) })

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, ins ->
            val s = ins.getInsets(WindowInsetsCompat.Type.systemBars())
            (card.layoutParams as FrameLayout.LayoutParams).topMargin = s.top + dp(10)
            (gear.layoutParams as FrameLayout.LayoutParams).bottomMargin = s.bottom + dp(20)
            root.requestLayout()
            ins
        }

        // double tap on empty space = lock, long press = settings
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onDoubleTap(e: MotionEvent): Boolean { lockScreen(); return true }
            override fun onLongPress(e: MotionEvent) { showSettings() }
        })
        root.setOnTouchListener { _, ev -> gd.onTouchEvent(ev) }

        bubble.onEmptyDoubleTap = { lockScreen() }
        bubble.onLaunch = { a ->
            if (a.pkg in strSet("locked")) askPin("Enter PIN to open ${a.label}") { openApp(a) } else openApp(a)
        }
        bubble.onLong = { a ->
            if (a.pkg in strSet("locked")) askPin("Enter PIN") { showAppMenu(a) } else showAppMenu(a)
        }

        setContentView(root)

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        applyWallpaper(false)
        refreshWeather()
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(wpTick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        bubble.resetPan()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
    }

    @Deprecated("Launcher ignores back")
    override fun onBackPressed() { }

    // ---------- apps ----------
    private fun loadApps() {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val p = it.activityInfo.packageName
                    AppItem(it.loadLabel(pm).toString(), p, ComponentName(p, it.activityInfo.name),
                        it.loadIcon(pm), prefs.getInt("cnt_$p", 0))
                }.distinctBy { it.pkg }
            runOnUiThread { allApps = list; applyAppFilter() }
        }.start()
    }

    private fun showAppMenu(a: AppItem) {
        val locked = a.pkg in strSet("locked")
        val items = arrayOf("App info", "Uninstall", "Reset size", "Hide this app",
            if (locked) "Remove PIN lock" else "Lock with PIN")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                1 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                2 -> { a.count = 0; prefs.edit().remove("cnt_${a.pkg}").apply(); bubble.relayout(true) }
                3 -> {
                    saveSet("hidden", strSet("hidden").apply { add(a.pkg) }); applyAppFilter()
                    Toast.makeText(this, "Hidden. To show it again: Settings → Hidden apps", Toast.LENGTH_LONG).show()
                }
                else -> if (locked) {
                    saveSet("locked", strSet("locked").apply { remove(a.pkg) })
                } else if (!hasPin()) {
                    Toast.makeText(this, "Set a security PIN first", Toast.LENGTH_LONG).show(); showSetPin()
                } else {
                    saveSet("locked", strSet("locked").apply { add(a.pkg) })
                    Toast.makeText(this, "${a.label} is now PIN-locked", Toast.LENGTH_SHORT).show()
                }
            }
        }.show()
    }

    private fun openApp(a: AppItem) {
        a.count++
        prefs.edit().putInt("cnt_${a.pkg}", a.count).apply()
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(a.cn)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (e: Exception) { }
        bubble.relayout(true)
    }

    // ---------- hide / lock / PIN ----------
    private fun strSet(k: String): MutableSet<String> =
        (prefs.getString(k, "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableSet()

    private fun saveSet(k: String, v: Set<String>) = prefs.edit().putString(k, v.joinToString("\n")).apply()

    private fun applyAppFilter() {
        val h = strSet("hidden")
        bubble.setApps(allApps.filter { it.pkg !in h })
    }

    private fun hashPin(p: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest(("glass-salt:$p").toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun hasPin() = prefs.getString("pin", null) != null

    private fun pinField(hintText: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        hint = hintText; gravity = Gravity.CENTER; textSize = 22f
        setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt())
    }

    /** Asks for the PIN (if one is set), then runs onOk. */
    private fun askPin(msg: String, onOk: () -> Unit) {
        if (!hasPin()) { onOk(); return }
        val box = vbox()
        box.addView(tv(msg, 16f, bold = true))
        val et = pinField("PIN")
        val err = tv("", 12f, Color.parseColor("#FF8A80"))
        var dlg: Dialog? = null
        box.addView(et); box.addView(err)
        box.addView(btn("Unlock") {
            if (hashPin(et.text.toString()) == prefs.getString("pin", null)) { dlg?.dismiss(); onOk() }
            else { err.text = "Wrong PIN, try again"; et.setText("") }
        })
        val d2 = glassDialog(box)
        dlg = d2
        d2.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d2.show()
    }

    private fun showSetPin() {
        if (hasPin()) { askPin("Enter current PIN") { buildSetPin() } } else buildSetPin()
    }

    private fun buildSetPin() {
        val box = vbox()
        box.addView(tv("Security PIN", 18f, bold = true))
        val p1 = pinField("New PIN (4-8 digits)")
        val p2 = pinField("Repeat PIN")
        val err = tv("", 12f, Color.parseColor("#FF8A80"))
        var dlg: Dialog? = null
        box.addView(p1); box.addView(p2); box.addView(err)
        box.addView(btn("Save PIN") {
            val a = p1.text.toString()
            if (a.length < 4 || a.length > 8) err.text = "PIN must be 4 to 8 digits"
            else if (a != p2.text.toString()) err.text = "PINs do not match"
            else {
                prefs.edit().putString("pin", hashPin(a)).apply()
                Toast.makeText(this, "PIN saved", Toast.LENGTH_SHORT).show(); dlg?.dismiss()
            }
        })
        if (hasPin()) box.addView(btn("Remove PIN (unlocks all apps)") {
            prefs.edit().remove("pin").apply(); saveSet("locked", emptySet()); dlg?.dismiss()
            Toast.makeText(this, "PIN removed", Toast.LENGTH_SHORT).show()
        })
        val d2 = glassDialog(box)
        dlg = d2
        d2.show()
    }

    private fun showAppPicker(title: String, key: String) {
        if (key == "locked" && !hasPin()) {
            Toast.makeText(this, "Set a security PIN first", Toast.LENGTH_LONG).show(); showSetPin(); return
        }
        val sel = strSet(key)
        val box = vbox()
        var dlg: Dialog? = null
        box.addView(tv(title, 18f, bold = true))
        box.addView(btn("✔  Done") {
            saveSet(key, sel); applyAppFilter(); dlg?.dismiss()
        })
        for (a in allApps.sortedBy { it.label.lowercase() }) {
            box.addView(CheckBox(this).apply {
                text = a.label; textSize = 15f; setTextColor(Color.WHITE)
                isChecked = a.pkg in sel
                setOnCheckedChangeListener { _, c -> if (c) sel.add(a.pkg) else sel.remove(a.pkg) }
            })
        }
        val d2 = glassDialog(ScrollView(this).apply { addView(box) })
        dlg = d2
        d2.show()
    }

    // ---------- wallpaper ----------
    private fun defaultBg() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#0F2027"), Color.parseColor("#203A43"), Color.parseColor("#5B2C83"))
    )

    private fun wallpapers(): List<String> =
        (prefs.getString("wps", "") ?: "").split("\n").filter { it.isNotBlank() }

    private fun applyWallpaper(force: Boolean) {
        ui.removeCallbacks(wpTick)
        val list = wallpapers()
        if (list.isEmpty()) { bg.setImageDrawable(defaultBg()); lastIdx = -1; return }
        val now = System.currentTimeMillis()
        val idx = ((now / PERIOD) % list.size).toInt()
        if (idx != lastIdx || force) { lastIdx = idx; loadWallpaper(list[idx]) }
        ui.postDelayed(wpTick, PERIOD - now % PERIOD + 500)
    }

    private fun loadWallpaper(s: String) {
        Thread {
            val bmp = decode(Uri.parse(s))
            if (bmp != null) runOnUiThread {
                bg.animate().alpha(0f).setDuration(250).withEndAction {
                    bg.setImageBitmap(bmp); bg.animate().alpha(1f).setDuration(350).start()
                }.start()
            }
        }.start()
    }

    private fun decode(uri: Uri): android.graphics.Bitmap? = try {
        val dm = resources.displayMetrics
        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= dm.widthPixels && o.outHeight / (s * 2) >= dm.heightPixels) s *= 2
        val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = s }
        contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
    } catch (e: Exception) { null }

    private fun pickWallpapers() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, PICK)
    }

    @Deprecated("Simple picker result")
    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc == PICK && res == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            data.clipData?.let { for (k in 0 until it.itemCount) uris.add(it.getItemAt(k).uri) }
            data.data?.let { if (uris.isEmpty()) uris.add(it) }
            val cur = wallpapers().toMutableList()
            for (u in uris) {
                try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
                if (u.toString() !in cur) cur.add(u.toString())
            }
            prefs.edit().putString("wps", cur.joinToString("\n")).apply()
            applyWallpaper(true)
            Toast.makeText(this, "${cur.size} wallpapers selected", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- lock ----------
    private fun lockScreen() {
        if (LockService.instance?.lock() == true) return
        Toast.makeText(this, "Turn on Glass Launcher in Accessibility settings to enable double-tap lock", Toast.LENGTH_LONG).show()
        showSettings()
    }

    // ---------- weather ----------
    private fun online(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    private fun wx(code: Int): Pair<String, String> = when (code) {
        0 -> "☀️" to "Clear sky"
        1, 2 -> "⛅" to "Partly cloudy"
        3 -> "☁️" to "Cloudy"
        45, 48 -> "🌫️" to "Fog"
        in 51..57 -> "🌦️" to "Drizzle"
        in 61..67 -> "🌧️" to "Rain"
        in 71..77 -> "❄️" to "Snow"
        in 80..82 -> "🌧️" to "Showers"
        85, 86 -> "❄️" to "Snow showers"
        in 95..99 -> "⛈️" to "Thunderstorm"
        else -> "🌡️" to "Unknown"
    }

    private fun refreshWeather() {
        ui.removeCallbacks(wxTick)
        ui.postDelayed(wxTick, PERIOD)
        val city = (prefs.getString("city", "") ?: "").trim()
        if (city.isEmpty() || !online()) { wxBox.visibility = View.GONE; return }
        Thread {
            try {
                var geo = prefs.getString("geo_$city", null)
                if (geo == null) {
                    val g = JSONObject(http("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" +
                            URLEncoder.encode(city, "UTF-8")))
                    val r = g.getJSONArray("results").getJSONObject(0)
                    geo = "${r.getDouble("latitude")},${r.getDouble("longitude")}"
                    prefs.edit().putString("geo_$city", geo).apply()
                }
                val (lat, lon) = geo.split(",")
                val j = JSONObject(http("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                        "&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min" +
                        "&timezone=auto&forecast_days=7"))
                val cur = j.getJSONObject("current")
                val temp = Math.round(cur.getDouble("temperature_2m"))
                val code = cur.getInt("weather_code")
                val dl = j.getJSONObject("daily")
                val t = dl.getJSONArray("time"); val c = dl.getJSONArray("weather_code")
                val mx = dl.getJSONArray("temperature_2m_max"); val mn = dl.getJSONArray("temperature_2m_min")
                val days = (0 until t.length()).map { Day(t.getString(it), c.getInt(it), mx.getDouble(it), mn.getDouble(it)) }
                runOnUiThread {
                    forecast = days
                    val (emo, txt) = wx(code)
                    wxBig.text = "$emo $temp°C"
                    wxSmall.text = "$city · $txt"
                    wxBox.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                runOnUiThread { wxBox.visibility = View.GONE }
            }
        }.start()
    }

    private fun showForecast() {
        if (forecast.isEmpty()) return
        val box = vbox()
        box.addView(tv("7-Day Forecast", 18f, bold = true))
        val inDf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        val outDf = SimpleDateFormat("EEE, MMM d", Locale.ENGLISH)
        forecast.forEachIndexed { i, d ->
            val (emo, txt) = wx(d.code)
            val name = if (i == 0) "Today" else outDf.format(inDf.parse(d.date)!!)
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10))
                addView(tv(name, 14f), LinearLayout.LayoutParams(0, WC, 1.2f))
                addView(tv("$emo $txt", 14f), LinearLayout.LayoutParams(0, WC, 1.6f))
                addView(tv("${Math.round(d.max)}° / ${Math.round(d.min)}°", 14f, bold = true).apply { gravity = Gravity.END },
                    LinearLayout.LayoutParams(0, WC, 1f))
            }
            box.addView(row)
        }
        glassDialog(box).show()
    }

    // ---------- calendar ----------
    private fun showCalendar() {
        val today = Calendar.getInstance()
        val shown = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
        val box = vbox()
        val title = tv("", 18f, bold = true).apply { gravity = Gravity.CENTER }
        val prev = tv("◀", 20f).apply { setPadding(dp(16), dp(6), dp(16), dp(6)) }
        val next = tv("▶", 20f).apply { setPadding(dp(16), dp(6), dp(16), dp(6)) }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(prev); addView(title, LinearLayout.LayoutParams(0, WC, 1f)); addView(next)
        }
        val grid = GridLayout(this).apply { columnCount = 7 }

        fun cell(t: String, c: Int, hl: Boolean): TextView = tv(t, 14f, c).apply {
            gravity = Gravity.CENTER
            layoutParams = GridLayout.LayoutParams().apply { width = dp(40); height = dp(40) }
            if (hl) background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x88FFFFFF.toInt()) }
        }

        fun render() {
            title.text = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(shown.time)
            grid.removeAllViews()
            for (ch in "SMTWTFS") grid.addView(cell(ch.toString(), 0x99FFFFFF.toInt(), false))
            repeat(shown.get(Calendar.DAY_OF_WEEK) - 1) { grid.addView(cell("", 0, false)) }
            val sameMonth = shown.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    shown.get(Calendar.MONTH) == today.get(Calendar.MONTH)
            for (day in 1..shown.getActualMaximum(Calendar.DAY_OF_MONTH))
                grid.addView(cell(day.toString(), Color.WHITE, sameMonth && day == today.get(Calendar.DAY_OF_MONTH)))
        }
        prev.setOnClickListener { shown.add(Calendar.MONTH, -1); render() }
        next.setOnClickListener { shown.add(Calendar.MONTH, 1); render() }
        box.addView(head); box.addView(grid)
        render()
        glassDialog(box).show()
    }

    // ---------- settings ----------
    private fun showSettings() {
        val box = vbox()
        var dlg: Dialog? = null
        box.addView(tv("Settings", 20f, bold = true))
        box.addView(tv("Weather location (city name)", 13f, 0xCCFFFFFF.toInt()).apply { setPadding(0, dp(14), 0, 0) })
        val et = EditText(this).apply {
            setText(prefs.getString("city", "")); hint = "e.g. Chattogram"
            setTextColor(Color.WHITE); setHintTextColor(0x88FFFFFF.toInt()); setSingleLine()
        }
        box.addView(et)
        box.addView(btn("🖼  Choose wallpapers (${wallpapers().size} selected)") { pickWallpapers() })
        box.addView(btn("🗑  Clear all wallpapers") {
            prefs.edit().remove("wps").apply(); applyWallpaper(true)
            Toast.makeText(this, "Wallpapers cleared", Toast.LENGTH_SHORT).show()
        })
        box.addView(btn("🔒  Enable double-tap lock") {
            Toast.makeText(this, "Find Glass Launcher in the list and turn it ON", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        box.addView(btn("🏠  Set as default Home app") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) })
        box.addView(btn("🙈  Hidden apps") { askPin("Enter PIN") { showAppPicker("Tick apps to hide", "hidden") } })
        box.addView(btn("🔐  PIN-locked apps") { askPin("Enter PIN") { showAppPicker("Tick apps to PIN-lock", "locked") } })
        box.addView(btn("🔑  Set / change security PIN") { showSetPin() })
        box.addView(btn("✔  Save") {
            prefs.edit().putString("city", et.text.toString().trim()).apply()
            refreshWeather(); dlg?.dismiss()
        })
        box.addView(tv("About", 16f, bold = true).apply { setPadding(0, dp(22), 0, dp(4)) })
        box.addView(tv("Glass Launcher v1.0", 13f, 0xCCFFFFFF.toInt()))
        box.addView(tv("Creator: Mohammod Abdul Awal", 13f, 0xCCFFFFFF.toInt()))
        box.addView(tv("Student: Department of English, National University.", 13f, 0xCCFFFFFF.toInt()))
        val sv = ScrollView(this).apply { addView(box) }
        val d2 = glassDialog(sv)
        dlg = d2
        d2.show()
    }
}
