# Film Camera (Android)

Photos and videos are saved directly to **DCIM/Camera** — no separate gallery.
Pinch (two-finger) zoom, auto-lighting, tap-to-focus/expose, film filters, beauty, night mode.

Creator: Mohammod Abdul Awal
Student: Department of English, National University
Mail: awal.sorkar.144@gmail.com

## Build APK with GitHub Actions
1. Upload `app.zip` (or all extracted files) to a GitHub repo.
2. Make sure `.github/workflows/build.yml` exists in the repo.
3. Actions tab -> "Build APK" -> download `FilmCamera-APK` (or from Releases).
