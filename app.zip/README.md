# Awal Media Player

Video • Audio • Photos in one app (ExoPlayer / Media3).

Creator: Mohammod Abdul Awal
Student: Department of English, National University.
Mail: awal.sorkar.144@gmail.com
