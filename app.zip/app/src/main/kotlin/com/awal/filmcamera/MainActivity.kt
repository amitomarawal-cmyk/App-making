// Film Camera
// Creator: Mohammod Abdul Awal | Student: Department of English, National University
// Mail: awal.sorkar.144@gmail.com
package com.awal.filmcamera

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {

    companion object {
        private const val HOST = "appassets.androidplatform.net"
        private const val REQ_PERMS = 77
    }

    private lateinit var web: WebView
    private var loaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        configureWebView()
        if (granted(Manifest.permission.CAMERA) && granted(Manifest.permission.RECORD_AUDIO)) {
            loadApp()
        } else {
            requestPermissions(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO),
                REQ_PERMS
            )
        }
    }

    private fun granted(p: String): Boolean {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadApp() {
        if (loaded) return
        loaded = true
        web.loadUrl("https://$HOST/assets/index.html")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.setOnLongClickListener { true }
        web.isLongClickable = false
        web.addJavascriptInterface(Bridge(applicationContext), "AndroidCam")

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val u = request.url
                if (u.scheme == "mailto") {
                    try {
                        startActivity(Intent(Intent.ACTION_SENDTO, u))
                    } catch (e: Exception) {
                        // no mail app
                    }
                    return true
                }
                return u.host != HOST
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val ok = ArrayList<String>()
                    for (r in request.resources) {
                        if (r == PermissionRequest.RESOURCE_VIDEO_CAPTURE &&
                            granted(Manifest.permission.CAMERA)
                        ) {
                            ok.add(r)
                        }
                        if (r == PermissionRequest.RESOURCE_AUDIO_CAPTURE &&
                            granted(Manifest.permission.RECORD_AUDIO)
                        ) {
                            ok.add(r)
                        }
                    }
                    if (ok.isEmpty()) {
                        request.deny()
                    } else {
                        request.grant(ok.toTypedArray())
                    }
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS) {
            if (!granted(Manifest.permission.CAMERA)) {
                Toast.makeText(
                    this,
                    "ক্যামেরার অনুমতি দিন (Settings > Apps > Film Camera > Permissions)",
                    Toast.LENGTH_LONG
                ).show()
            }
            loadApp()
        }
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.evaluateJavascript("window.appResume&&window.appResume()", null)
    }

    override fun onPause() {
        web.evaluateJavascript("window.appPause&&window.appPause()", null)
        web.onPause()
        super.onPause()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.closeAbout&&window.closeAbout())?'1':'0'") { r ->
            if (r == null || !r.contains("1")) {
                finish()
            }
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
