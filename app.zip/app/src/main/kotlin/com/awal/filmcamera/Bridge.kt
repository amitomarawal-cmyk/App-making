// Film Camera
// Creator: Mohammod Abdul Awal | Student: Department of English, National University
// Mail: awal.sorkar.144@gmail.com
package com.awal.filmcamera

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import java.io.OutputStream

/** JS -> Android bridge: saves photos/videos straight into DCIM/Camera (no storage permission needed). */
class Bridge(private val ctx: Context) {

    private class Sess(val uri: Uri, val out: OutputStream)

    private val map = HashMap<Int, Sess>()
    private var next = 1

    @JavascriptInterface
    @Synchronized
    fun begin(name: String, mime: String): Int {
        return try {
            val video = mime.startsWith("video")
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/Camera")
            values.put(MediaStore.MediaColumns.DATE_TAKEN, System.currentTimeMillis())
            values.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val collection = if (video) {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }
            val uri = ctx.contentResolver.insert(collection, values)
            if (uri == null) {
                -1
            } else {
                val out = ctx.contentResolver.openOutputStream(uri)
                if (out == null) {
                    ctx.contentResolver.delete(uri, null, null)
                    -1
                } else {
                    val id = next
                    next = next + 1
                    map[id] = Sess(uri, out)
                    id
                }
            }
        } catch (e: Exception) {
            -1
        }
    }

    @JavascriptInterface
    fun chunk(id: Int, b64: String): Boolean {
        val s = synchronized(this) { map[id] }
        if (s == null) return false
        return try {
            val data = Base64.decode(b64, Base64.DEFAULT)
            s.out.write(data)
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun finish(id: Int): Boolean {
        val s = synchronized(this) { map.remove(id) }
        if (s == null) return false
        return try {
            s.out.flush()
            s.out.close()
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            ctx.contentResolver.update(s.uri, values, null, null)
            true
        } catch (e: Exception) {
            try {
                ctx.contentResolver.delete(s.uri, null, null)
            } catch (e2: Exception) {
                // ignore
            }
            false
        }
    }

    @JavascriptInterface
    fun abort(id: Int) {
        val s = synchronized(this) { map.remove(id) }
        if (s == null) return
        try {
            s.out.close()
        } catch (e: Exception) {
            // ignore
        }
        try {
            ctx.contentResolver.delete(s.uri, null, null)
        } catch (e: Exception) {
            // ignore
        }
    }
}
