package com.awal.mediaplayer.utils;

import android.media.audiofx.BassBoost;

public class BassBoostHelper {
    private BassBoost bassBoost;
    private boolean enabled = false;

    public void attach(int audioSessionId) {
        release();
        try {
            bassBoost = new BassBoost(0, audioSessionId);
            bassBoost.setEnabled(true);
            enabled = true;
        } catch (Exception e) {
            e.printStackTrace();
            enabled = false;
        }
    }

    public void setStrength(short strength) {
        if (bassBoost != null && enabled) {
            try {
                bassBoost.setStrength(strength);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void release() {
        if (bassBoost != null) {
            try {
                bassBoost.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
            bassBoost = null;
            enabled = false;
        }
    }

    public boolean isEnabled() {
        return enabled;
    }
}
