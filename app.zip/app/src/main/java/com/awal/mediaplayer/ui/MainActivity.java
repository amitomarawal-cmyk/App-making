package com.awal.mediaplayer.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.awal.mediaplayer.R;
import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {

    private boolean pickingVideo = false;

    private final ActivityResultLauncher<String[]> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            boolean granted = result.values().stream().anyMatch(v -> v);
            if (granted) launchFilePicker();
            else Toast.makeText(this, "Storage permission required", Toast.LENGTH_SHORT).show();
        });

    private final ActivityResultLauncher<String> filePickerLauncher =
        registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri == null) return;
            if (pickingVideo) openVideo(uri);
            else openAudio(uri);
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialButton btnVideo = findViewById(R.id.btnPickVideo);
        MaterialButton btnAudio = findViewById(R.id.btnPickAudio);

        btnVideo.setOnClickListener(v -> {
            pickingVideo = true;
            checkPermissionAndPick();
        });

        btnAudio.setOnClickListener(v -> {
            pickingVideo = false;
            checkPermissionAndPick();
        });

        // Handle intent from file manager
        Intent intent = getIntent();
        if (intent != null && intent.getData() != null) {
            Uri uri = intent.getData();
            String type = intent.getType();
            if (type != null && type.startsWith("video")) openVideo(uri);
            else openAudio(uri);
        }
    }

    private void checkPermissionAndPick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            String perm = pickingVideo ? Manifest.permission.READ_MEDIA_VIDEO : Manifest.permission.READ_MEDIA_AUDIO;
            if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
                launchFilePicker();
            } else {
                permissionLauncher.launch(new String[]{perm});
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                launchFilePicker();
            } else {
                permissionLauncher.launch(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE});
            }
        }
    }

    private void launchFilePicker() {
        filePickerLauncher.launch(pickingVideo ? "video/*" : "audio/*");
    }

    private void openVideo(Uri uri) {
        Intent intent = new Intent(this, VideoPlayerActivity.class);
        intent.setData(uri);
        startActivity(intent);
    }

    private void openAudio(Uri uri) {
        Intent intent = new Intent(this, AudioPlayerActivity.class);
        intent.setData(uri);
        startActivity(intent);
    }
}
