package com.awal.mediaplayer

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var empty: TextView
    private var tab = R.id.nav_video
    private val cache = HashMap<Int, List<MediaEntry>>()
    private val bg = Executors.newSingleThreadExecutor()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            cache.clear()
            show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = getString(R.string.app_name)
        recycler = findViewById(R.id.recycler)
        empty = findViewById(R.id.empty)
        val nav = findViewById<BottomNavigationView>(R.id.nav)
        nav.setOnItemSelectedListener {
            tab = it.itemId
            show()
            true
        }
        if (!hasPerms()) permLauncher.launch(perms())
    }

    override fun onResume() {
        super.onResume()
        cache.clear()
        show()
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_IMAGES
            )
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasPerms() = perms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun show() {
        val items = cache[tab]
        if (items == null) {
            val t = tab
            bg.execute {
                val r = query(t)
                runOnUiThread {
                    if (!isDestroyed) {
                        cache[t] = r
                        show()
                    }
                }
            }
            return
        }
        val grid = tab != R.id.nav_audio
        recycler.layoutManager =
            if (grid) GridLayoutManager(this, 3) else LinearLayoutManager(this)
        recycler.adapter = MediaAdapter(items, tab) { pos -> open(items, pos) }
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun open(items: List<MediaEntry>, pos: Int) {
        Shared.uris = items.map { it.uri }
        Shared.names = items.map { it.name }
        val cls = if (tab == R.id.nav_photos) ImageViewerActivity::class.java
        else PlayerActivity::class.java
        startActivity(
            Intent(this, cls)
                .putExtra("index", pos)
                .putExtra("audio", tab == R.id.nav_audio)
        )
    }

    private fun query(t: Int): List<MediaEntry> {
        val out = ArrayList<MediaEntry>()
        val base: Uri
        val proj: Array<String>
        when (t) {
            R.id.nav_video -> {
                base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                proj = arrayOf("_id", "_display_name", "duration")
            }
            R.id.nav_audio -> {
                base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                proj = arrayOf("_id", "_display_name", "duration", "artist")
            }
            else -> {
                base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                proj = arrayOf("_id", "_display_name")
            }
        }
        try {
            contentResolver.query(base, proj, null, null, "date_added DESC")?.use { c ->
                val iId = c.getColumnIndexOrThrow("_id")
                val iName = c.getColumnIndexOrThrow("_display_name")
                val iDur = c.getColumnIndex("duration")
                val iArt = c.getColumnIndex("artist")
                while (c.moveToNext()) {
                    val dur = if (iDur >= 0) c.getLong(iDur) else 0L
                    var sub = ""
                    if (t == R.id.nav_video) sub = fmtTime(dur)
                    if (t == R.id.nav_audio) {
                        val art = if (iArt >= 0) c.getString(iArt) else null
                        val a = if (art.isNullOrBlank() || art == "<unknown>") "" else "$art · "
                        sub = a + fmtTime(dur)
                    }
                    out.add(
                        MediaEntry(
                            ContentUris.withAppendedId(base, c.getLong(iId)),
                            c.getString(iName) ?: "?",
                            dur,
                            sub
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_about) {
            AlertDialog.Builder(this)
                .setTitle("Awal Media Player")
                .setMessage(
                    "Version 1.0\n\n" +
                        "Creator: Mohammod Abdul Awal\n" +
                        "Student: Department of English, National University.\n" +
                        "Mail: awal.sorkar.144@gmail.com"
                )
                .setPositiveButton("OK", null)
                .show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
