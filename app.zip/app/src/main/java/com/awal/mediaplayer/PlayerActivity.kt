package com.awal.mediaplayer

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.TrackSelectionDialogBuilder

@androidx.annotation.OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View

    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastFx = 0f
    private var lastFy = 0f
    private lateinit var scaleDetector: ScaleGestureDetector

    private var resizeIdx = 0
    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val resizeNames = arrayOf("Fit", "Crop", "Stretch")

    private val errorListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(
                this@PlayerActivity,
                "Can't play this one: ${error.errorCodeName}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val pickSub =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) addSubtitle(uri)
        }
    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        immersive()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playerView = findViewById(R.id.player_view)
        topBar = findViewById(R.id.top_bar)
        player = PlayerHolder.get(this)

        if (!loadFromIntent()) { finish(); return }
        startService(Intent(this, PlaybackService::class.java))

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        val audioOnly = intent.getBooleanExtra("audio", intent.type?.startsWith("audio") == true)
        if (audioOnly) {
            playerView.controllerShowTimeoutMs = 0
            playerView.controllerHideOnTouch = false
        }

        playerView.setControllerVisibilityListener(
            PlayerView.ControllerVisibilityListener { v -> topBar.visibility = v }
        )
        playerView.setFullscreenButtonClickListener { full -> immersive(full) }

        findViewById<View>(R.id.btn_audio).setOnClickListener { trackDialog(C.TRACK_TYPE_AUDIO, "Audio track") }
        findViewById<View>(R.id.btn_sub).setOnClickListener { trackDialog(C.TRACK_TYPE_TEXT, "Subtitles") }
        findViewById<View>(R.id.btn_add_sub).setOnClickListener { pickSub.launch(arrayOf("*/*")) }
        findViewById<View>(R.id.btn_eq).setOnClickListener { showEqualizer() }
        findViewById<View>(R.id.btn_rotate).apply {
            setOnClickListener {
                requestedOrientation =
                    if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                        ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }
            setOnLongClickListener {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                Toast.makeText(this@PlayerActivity, "Auto-rotate", Toast.LENGTH_SHORT).show()
                true
            }
        }
        findViewById<View>(R.id.btn_zoom).setOnClickListener {
            resizeIdx = (resizeIdx + 1) % resizeModes.size
            playerView.resizeMode = resizeModes[resizeIdx]
            zoom = 1f; panX = 0f; panY = 0f
            applyZoom()
            Toast.makeText(this, resizeNames[resizeIdx] + " (pinch to zoom)", Toast.LENGTH_SHORT).show()
        }

        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean {
                lastFx = d.focusX; lastFy = d.focusY
                return true
            }
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoom = (zoom * d.scaleFactor).coerceIn(1f, 5f)
                panX += d.focusX - lastFx
                panY += d.focusY - lastFy
                lastFx = d.focusX; lastFy = d.focusY
                applyZoom()
                return true
            }
        })
    }

    /** Loads a playlist from the intent. With no data (opened from the notification), re-attaches to what's playing. */
    private fun loadFromIntent(): Boolean {
        val uris: List<Uri> =
            if (intent.hasExtra("index") && Shared.uris.isNotEmpty()) Shared.uris
            else listOfNotNull(intent.data)
        if (uris.isEmpty()) return player.mediaItemCount > 0
        val start = intent.getIntExtra("index", 0).coerceIn(0, uris.size - 1)
        val names = if (Shared.names.size == uris.size) Shared.names else emptyList()
        val items = uris.mapIndexed { i, u ->
            MediaItem.Builder()
                .setUri(u)
                .setMediaId(u.toString())
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(names.getOrNull(i) ?: u.lastPathSegment)
                        .build()
                )
                .build()
        }
        player.setMediaItems(items, start, C.TIME_UNSET)
        player.prepare()
        player.playWhenReady = true
        return true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        loadFromIntent()
    }

    override fun onStart() {
        super.onStart()
        PlayerHolder.visible = true
        playerView.player = player
        player.addListener(errorListener)
    }

    override fun onStop() {
        super.onStop()
        PlayerHolder.visible = false
        player.removeListener(errorListener)
        playerView.player = null   // video surface off, audio keeps playing via the service
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing && !player.playWhenReady) {
            stopService(Intent(this, PlaybackService::class.java))
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::scaleDetector.isInitialized) scaleDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    private fun applyZoom() {
        val v = playerView.videoSurfaceView ?: return
        val mx = (zoom - 1f) * v.width / 2f
        val my = (zoom - 1f) * v.height / 2f
        panX = panX.coerceIn(-mx, mx)
        panY = panY.coerceIn(-my, my)
        v.scaleX = zoom; v.scaleY = zoom
        v.translationX = panX; v.translationY = panY
    }

    private fun trackDialog(type: Int, title: String) {
        if (player.currentTracks.groups.none { it.type == type }) {
            Toast.makeText(this, "No $title found 🤷", Toast.LENGTH_SHORT).show()
            return
        }
        TrackSelectionDialogBuilder(this, title, player, type).build().show()
    }

    private fun addSubtitle(uri: Uri) {
        val cur = player.currentMediaItem ?: return
        val name = (uri.lastPathSegment ?: "").lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") || name.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val existing = cur.localConfiguration?.subtitleConfigurations ?: emptyList()
        val item = cur.buildUpon().setSubtitleConfigurations(existing + sub).build()
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        player.replaceMediaItem(idx, item)
        player.seekTo(idx, pos)
        Toast.makeText(this, "Subtitle added 🎉", Toast.LENGTH_SHORT).show()
    }

    private fun showEqualizer() {
        val e = PlayerHolder.eq ?: run {
            Toast.makeText(this, "Equalizer not ready yet", Toast.LENGTH_SHORT).show()
            return
        }
        val prefs = PlayerHolder.prefs
        val lo = e.bandLevelRange[0].toInt()
        val hi = e.bandLevelRange[1].toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 16, 48, 0)
        }
        for (i in 0 until e.numberOfBands) {
            val band = i.toShort()
            val label = TextView(this)
            fun upd() {
                label.text = "${e.getCenterFreq(band) / 1000} Hz    ${e.getBandLevel(band) / 100} dB"
            }
            val sb = SeekBar(this).apply {
                max = hi - lo
                progress = e.getBandLevel(band) - lo
            }
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        e.setBandLevel(band, (p + lo).toShort())
                        prefs.edit().putInt("b$i", p + lo).apply()
                        upd()
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            upd()
            root.addView(label)
            root.addView(sb)
        }
        AlertDialog.Builder(this)
            .setTitle("Equalizer 🎚️")
            .setView(ScrollView(this).apply { addView(root) })
            .setPositiveButton("OK", null)
            .setNeutralButton("Presets") { _, _ ->
                val names = (0 until e.numberOfPresets.toInt())
                    .map { e.getPresetName(it.toShort()) }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("Preset")
                    .setItems(names) { _, w ->
                        e.usePreset(w.toShort())
                        PlayerHolder.saveEq()
                        showEqualizer()
                    }.show()
            }
            .setNegativeButton("Reset") { _, _ ->
                for (b in 0 until e.numberOfBands) e.setBandLevel(b.toShort(), 0)
                PlayerHolder.saveEq()
                showEqualizer()
            }
            .show()
    }
}
