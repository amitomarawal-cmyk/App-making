package com.awal.mediaplayer

import android.content.Context
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.abs

class ZoomImageView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : AppCompatImageView(c, a) {
    var onSwipe: ((Int) -> Unit)? = null
    private var s = 1f
    private var tx = 0f
    private var ty = 0f

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            s = (s * d.scaleFactor).coerceIn(1f, 6f)
            refresh()
            return true
        }
    })

    private val gd = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (s > 1f) reset() else { s = 2.5f; refresh() }
            return true
        }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (s > 1f) { tx -= dx; ty -= dy; refresh() }
            return true
        }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (s == 1f && abs(vx) > abs(vy) && abs(vx) > 800) {
                onSwipe?.invoke(if (vx < 0) 1 else -1)
                return true
            }
            return false
        }
    })

    fun reset() { s = 1f; tx = 0f; ty = 0f; refresh() }

    private fun refresh() {
        val mx = (s - 1f) * width / 2f
        val my = (s - 1f) * height / 2f
        tx = tx.coerceIn(-mx, mx)
        ty = ty.coerceIn(-my, my)
        scaleX = s; scaleY = s
        translationX = tx; translationY = ty
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        if (!sd.isInProgress) gd.onTouchEvent(e)
        return true
    }
}
