package com.awal.mediaplayer

import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class ImageViewerActivity : AppCompatActivity() {

    private var uris: List<Uri> = emptyList()
    private var idx = 0
    private lateinit var iv: ZoomImageView
    private lateinit var counter: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image)
        immersive()
        iv = findViewById(R.id.zoom_image)
        counter = findViewById(R.id.counter)

        uris = if (intent.hasExtra("index") && Shared.uris.isNotEmpty()) Shared.uris
        else listOfNotNull(intent.data)
        if (uris.isEmpty()) { finish(); return }
        idx = intent.getIntExtra("index", 0).coerceIn(0, uris.size - 1)
        iv.onSwipe = { d -> go(d) }
        showImage()
    }

    private fun go(d: Int) {
        val n = idx + d
        if (n in uris.indices) { idx = n; showImage() }
    }

    private fun showImage() {
        iv.reset()
        Glide.with(this).load(uris[idx]).override(2048, 2048).fitCenter().into(iv)
        counter.text = "${idx + 1} / ${uris.size}"
    }
}
