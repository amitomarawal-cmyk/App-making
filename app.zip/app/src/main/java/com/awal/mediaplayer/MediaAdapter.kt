package com.awal.mediaplayer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MediaAdapter(
    private val items: List<MediaEntry>,
    private val tab: Int,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.thumb)
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView = v.findViewById(R.id.sub)
        val info: View = v.findViewById(R.id.info)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (tab == R.id.nav_audio) R.layout.item_audio else R.layout.item_grid
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = items[position]
        h.title.text = e.name
        h.sub.text = e.sub
        when (tab) {
            R.id.nav_audio -> h.img.setImageResource(R.drawable.ic_music)
            R.id.nav_video -> Glide.with(h.img).load(e.uri).centerCrop().into(h.img)
            else -> {
                h.info.visibility = View.GONE
                Glide.with(h.img).load(e.uri).centerCrop().into(h.img)
            }
        }
        h.itemView.setOnClickListener { onClick(h.bindingAdapterPosition) }
    }
}
