package com.awal.mediaplayer.ui;

import android.net.Uri;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import com.awal.mediaplayer.R;
import com.awal.mediaplayer.utils.BassBoostHelper;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class VideoPlayerActivity extends AppCompatActivity {

    private ExoPlayer player;
    private PlayerView playerView;
    private BassBoostHelper bassBoostHelper;
    private SeekBar seekBass;
    private TextView tvBassValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);

        playerView = findViewById(R.id.playerView);
        seekBass = findViewById(R.id.seekBass);
        tvBassValue = findViewById(R.id.tvBassValue);
        MaterialButton btnSubtitles = findViewById(R.id.btnSubtitles);
        MaterialButton btnAudioTrack = findViewById(R.id.btnAudioTrack);

        bassBoostHelper = new BassBoostHelper();

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        Uri uri = getIntent().getData();
        if (uri != null) {
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
        } else {
            Toast.makeText(this, "No media file", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    int sessionId = player.getAudioSessionId();
                    if (sessionId != C.AUDIO_SESSION_ID_UNSET) {
                        bassBoostHelper.attach(sessionId);
                    }
                }
            }
        });

        seekBass.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean user) {
                tvBassValue.setText(String.valueOf(progress));
                bassBoostHelper.setStrength((short) progress);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        btnSubtitles.setOnClickListener(v -> showSubtitleDialog());
        btnAudioTrack.setOnClickListener(v -> showAudioTrackDialog());
    }

    private void showSubtitleDialog() {
        List<String> options = new ArrayList<>();
        List<Tracks.Group> subtitleGroups = new ArrayList<>();
        options.add("Disable Subtitles");

        for (Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType() == C.TRACK_TYPE_TEXT) {
                subtitleGroups.add(group);
                String lang = group.getMediaTrackGroup().getFormat(0).language;
                String label = group.getMediaTrackGroup().getFormat(0).label;
                String name = (label != null ? label : "") + (lang != null ? " [" + lang + "]" : "");
                options.add(name.trim().isEmpty() ? "Subtitle " + subtitleGroups.size() : name);
            }
        }

        if (subtitleGroups.isEmpty()) {
            Toast.makeText(this, "No subtitles found", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
            .setTitle("Select Subtitle")
            .setItems(options.toArray(new String[0]), (dialog, which) -> {
                if (which == 0) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build();
                } else {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .addOverride(new TrackSelectionOverride(
                            subtitleGroups.get(which - 1).getMediaTrackGroup(), 0))
                        .build();
                }
            }).show();
    }

    private void showAudioTrackDialog() {
        List<String> options = new ArrayList<>();
        List<Tracks.Group> audioGroups = new ArrayList<>();

        for (Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType() == C.TRACK_TYPE_AUDIO) {
                audioGroups.add(group);
                String lang = group.getMediaTrackGroup().getFormat(0).language;
                String label = group.getMediaTrackGroup().getFormat(0).label;
                String name = (label != null ? label : "") + (lang != null ? " [" + lang + "]" : "");
                options.add(name.trim().isEmpty() ? "Audio " + audioGroups.size() : name);
            }
        }

        if (audioGroups.size() <= 1) {
            Toast.makeText(this, "Only one audio track", Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
            .setTitle("Select Audio Track")
            .setItems(options.toArray(new String[0]), (dialog, which) ->
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .addOverride(new TrackSelectionOverride(
                        audioGroups.get(which).getMediaTrackGroup(), 0))
                    .build()
            ).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        bassBoostHelper.release();
        if (player != null) { player.release(); player = null; }
    }
}
