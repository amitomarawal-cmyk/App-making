package com.awal.mediaplayer.ui;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.exoplayer.ExoPlayer;

import com.awal.mediaplayer.R;
import com.awal.mediaplayer.service.MediaPlaybackService;
import com.awal.mediaplayer.utils.BassBoostHelper;
import com.awal.mediaplayer.utils.TimeUtils;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class AudioPlayerActivity extends AppCompatActivity {

    private ExoPlayer player;
    private BassBoostHelper bassBoostHelper;
    private SeekBar seekPosition, seekBass;
    private TextView tvAudioTitle, tvCurrentTime, tvTotalTime, tvBassValue;
    private MaterialButton btnPlayPause, btnAudioTrack;
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean isUpdatingSeek = false;

    private static final String CHANNEL_ID = MediaPlaybackService.CHANNEL_ID;
    private static final int NOTIF_ID = 2001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_player);

        tvAudioTitle = findViewById(R.id.tvAudioTitle);
        tvCurrentTime = findViewById(R.id.tvCurrentTime);
        tvTotalTime = findViewById(R.id.tvTotalTime);
        tvBassValue = findViewById(R.id.tvBassValue);
        seekPosition = findViewById(R.id.seekPosition);
        seekBass = findViewById(R.id.seekBass);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnAudioTrack = findViewById(R.id.btnAudioTrack);
        MaterialButton btnRewind = findViewById(R.id.btnRewind);
        MaterialButton btnForward = findViewById(R.id.btnForward);

        bassBoostHelper = new BassBoostHelper();
        createNotificationChannel();

        player = new ExoPlayer.Builder(this).build();

        Uri uri = getIntent().getData();
        if (uri == null) { finish(); return; }

        String fileName = uri.getLastPathSegment();
        tvAudioTitle.setText(fileName != null ? fileName : "Audio");

        MediaItem mediaItem = MediaItem.fromUri(uri);
        player.setMediaItem(mediaItem);
        player.prepare();
        player.play();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    seekPosition.setMax((int) player.getDuration());
                    tvTotalTime.setText(TimeUtils.formatTime(player.getDuration()));
                    int sessionId = player.getAudioSessionId();
                    if (sessionId != C.AUDIO_SESSION_ID_UNSET) {
                        bassBoostHelper.attach(sessionId);
                    }
                    showNotification(fileName != null ? fileName : "Audio");
                }
            }

            @Override
            public void onIsPlayingChanged(boolean isPlaying) {
                btnPlayPause.setText(isPlaying ? "⏸" : "▶");
            }
        });

        handler.post(progressUpdater);

        seekPosition.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                if (user) player.seekTo(p);
                tvCurrentTime.setText(TimeUtils.formatTime(p));
            }
            @Override public void onStartTrackingTouch(SeekBar s) { isUpdatingSeek = true; }
            @Override public void onStopTrackingTouch(SeekBar s) { isUpdatingSeek = false; }
        });

        seekBass.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean user) {
                tvBassValue.setText(String.valueOf(progress));
                bassBoostHelper.setStrength((short) progress);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });

        btnPlayPause.setOnClickListener(v -> {
            if (player.isPlaying()) player.pause(); else player.play();
        });

        btnRewind.setOnClickListener(v -> player.seekTo(Math.max(0, player.getCurrentPosition() - 10000)));
        btnForward.setOnClickListener(v -> player.seekTo(Math.min(player.getDuration(), player.getCurrentPosition() + 10000)));
        btnAudioTrack.setOnClickListener(v -> showAudioTrackDialog());
    }

    private final Runnable progressUpdater = new Runnable() {
        @Override public void run() {
            if (player != null && !isUpdatingSeek && player.isPlaying()) {
                seekPosition.setProgress((int) player.getCurrentPosition());
                tvCurrentTime.setText(TimeUtils.formatTime(player.getCurrentPosition()));
            }
            handler.postDelayed(this, 500);
        }
    };

    private void showAudioTrackDialog() {
        List<String> options = new ArrayList<>();
        List<Tracks.Group> audioGroups = new ArrayList<>();

        Tracks tracks = player.getCurrentTracks();
        for (Tracks.Group group : tracks.getGroups()) {
            if (group.getType() == C.TRACK_TYPE_AUDIO) {
                audioGroups.add(group);
                String lang = group.getMediaTrackGroup().getFormat(0).language;
                String label = group.getMediaTrackGroup().getFormat(0).label;
                String name = (label != null ? label : "") + (lang != null ? " [" + lang + "]" : "");
                options.add(name.isEmpty() ? "Audio " + audioGroups.size() : name);
            }
        }

        if (audioGroups.size() <= 1) {
            Toast.makeText(this, "Only one audio track available", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] items = options.toArray(new String[0]);
        new AlertDialog.Builder(this)
            .setTitle("Select Audio Track")
            .setItems(items, (dialog, which) -> {
                Tracks.Group selected = audioGroups.get(which);
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .addOverride(new TrackSelectionOverride(selected.getMediaTrackGroup(), 0))
                    .build();
            })
            .show();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Media Playback", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void showNotification(String title) {
        Intent intent = new Intent(this, AudioPlayerActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("🎵 Now Playing")
            .setContentText(title)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIF_ID, builder.build());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(progressUpdater);
        bassBoostHelper.release();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NOTIF_ID);
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
