package com.awal.mediaplayer

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener

/** One shared player, used by both the screen and the background service. */
@androidx.annotation.OptIn(UnstableApi::class)
object PlayerHolder {
    private var player: ExoPlayer? = null
    var eq: Equalizer? = null
    lateinit var prefs: SharedPreferences
    @Volatile var visible = false

    fun get(ctx: Context): ExoPlayer {
        player?.let { return it }
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("eq", Context.MODE_PRIVATE)
        val p = ExoPlayer.Builder(app)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        p.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(
                eventTime: AnalyticsListener.EventTime,
                audioSessionId: Int
            ) {
                setupEq(audioSessionId)
            }
        })
        player = p
        return p
    }

    private fun setupEq(session: Int) {
        if (session == C.AUDIO_SESSION_ID_UNSET) return
        eq?.release()
        eq = try {
            Equalizer(0, session).also { e ->
                e.enabled = true
                val r = e.bandLevelRange
                for (b in 0 until e.numberOfBands) {
                    if (prefs.contains("b$b")) {
                        val lvl = prefs.getInt("b$b", 0).coerceIn(r[0].toInt(), r[1].toInt())
                        e.setBandLevel(b.toShort(), lvl.toShort())
                    }
                }
            }
        } catch (ex: Exception) {
            null
        }
    }

    fun saveEq() {
        val e = eq ?: return
        val ed = prefs.edit()
        for (b in 0 until e.numberOfBands) ed.putInt("b$b", e.getBandLevel(b.toShort()).toInt())
        ed.apply()
    }

    fun release() {
        eq?.release()
        eq = null
        player?.release()
        player = null
    }
}
