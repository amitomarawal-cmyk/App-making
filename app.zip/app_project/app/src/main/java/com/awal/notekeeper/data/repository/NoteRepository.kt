package com.awal.notekeeper.data.repository

import com.awal.notekeeper.data.local.NoteDao
import com.awal.notekeeper.data.model.Note
import kotlinx.coroutines.flow.Flow

class NoteRepository(private val noteDao: NoteDao) {

    val allNotes: Flow<List<Note>> = noteDao.getAllNotes()

    fun searchNotes(query: String): Flow<List<Note>> = noteDao.searchNotes(query)

    suspend fun getNoteById(id: Long): Note? = noteDao.getNoteById(id)

    suspend fun insertNote(note: Note): Long = noteDao.insertNote(note)

    suspend fun updateNote(note: Note) = noteDao.updateNote(note)

    suspend fun deleteNote(note: Note) = noteDao.deleteNote(note)

    suspend fun deleteNoteById(id: Long) = noteDao.deleteNoteById(id)

    suspend fun deleteAllNotes() = noteDao.deleteAllNotes()

    suspend fun getAllNotesSuspend(): List<Note> = noteDao.getAllNotesSuspend()

    suspend fun insertAll(notes: List<Note>) = noteDao.insertAll(notes)

    suspend fun deleteExpiredNotes(expiryTime: Long) = noteDao.deleteExpiredNotes(expiryTime)

    suspend fun countExpiredNotes(expiryTime: Long): Int = noteDao.countExpiredNotes(expiryTime)
}
