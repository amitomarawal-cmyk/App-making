package com.awal.notekeeper.utils

import androidx.annotation.ColorRes
import com.awal.notekeeper.R

object NoteColors {

    data class NoteColor(
        val index: Int,
        @ColorRes val backgroundRes: Int,
        @ColorRes val textColorRes: Int,
        val name: String
    )

    val colors = listOf(
        NoteColor(0, R.color.note_default, R.color.text_primary, "Default"),
        NoteColor(1, R.color.note_red, R.color.text_primary, "Red"),
        NoteColor(2, R.color.note_pink, R.color.text_primary, "Pink"),
        NoteColor(3, R.color.note_orange, R.color.text_primary, "Orange"),
        NoteColor(4, R.color.note_yellow, R.color.text_primary, "Yellow"),
        NoteColor(5, R.color.note_green, R.color.text_primary, "Green"),
        NoteColor(6, R.color.note_teal, R.color.text_primary, "Teal"),
        NoteColor(7, R.color.note_blue, R.color.text_primary, "Blue"),
        NoteColor(8, R.color.note_purple, R.color.text_primary, "Purple"),
        NoteColor(9, R.color.note_brown, R.color.text_light, "Brown"),
        NoteColor(10, R.color.note_gray, R.color.text_primary, "Gray"),
        NoteColor(11, R.color.note_dark, R.color.text_light, "Dark")
    )

    fun getColor(index: Int): NoteColor = colors.getOrElse(index) { colors[0] }

    fun getCount() = colors.size
}
