package com.awal.notekeeper.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.awal.notekeeper.R
import com.awal.notekeeper.data.model.Note
import com.awal.notekeeper.databinding.ActivityMainBinding
import com.awal.notekeeper.ui.components.NoteAdapter
import com.awal.notekeeper.viewmodel.NoteViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: NoteViewModel by viewModels()
    private lateinit var adapter: NoteAdapter

    // Backup/Restore launchers
    private val saveTxtLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        uri?.let { viewModel.backupAsTxt(this, it) }
    }
    private val saveZipLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        uri?.let { viewModel.backupAsZip(this, it) }
    }
    private val openTxtLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.restoreFromTxt(this, it) }
    }
    private val openZipLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.restoreFromZip(this, it) }
    }
    private val newNoteLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        // notes auto-refresh via LiveData
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        setupRecyclerView()
        setupSearch()
        setupFab()
        observeViewModel()
    }

    private fun setupRecyclerView() {
        adapter = NoteAdapter(
            onNoteClick = { note -> openEditNote(note) },
            onNoteLongClick = { note -> showNoteOptions(note) }
        )

        val layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        layoutManager.gapStrategy = StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS

        binding.recyclerView.apply {
            this.layoutManager = layoutManager
            this.adapter = this@MainActivity.adapter
            setHasFixedSize(false)
            itemAnimator = null
        }
    }

    private fun setupSearch() {
        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                viewModel.setSearchQuery(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.clearSearchBtn.setOnClickListener {
            binding.searchEditText.text?.clear()
        }
    }

    private fun setupFab() {
        binding.fabAddNote.setOnClickListener {
            val intent = Intent(this, EditNoteActivity::class.java)
            newNoteLauncher.launch(intent)
        }
    }

    private fun observeViewModel() {
        viewModel.notes.observe(this) { notes ->
            adapter.submitList(notes)
            binding.emptyState.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerView.visibility = if (notes.isEmpty()) View.GONE else View.VISIBLE
        }

        viewModel.operationResult.observe(this) { message ->
            if (message.isNotBlank()) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openEditNote(note: Note) {
        val intent = Intent(this, EditNoteActivity::class.java).apply {
            putExtra(EditNoteActivity.EXTRA_NOTE_ID, note.id)
        }
        newNoteLauncher.launch(intent)
    }

    private fun showNoteOptions(note: Note) {
        val options = arrayOf("সম্পাদনা করুন", "মুছে ফেলুন")
        AlertDialog.Builder(this)
            .setTitle(note.title.ifBlank { "নোট" })
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openEditNote(note)
                    1 -> confirmDelete(note)
                }
            }
            .show()
    }

    private fun confirmDelete(note: Note) {
        AlertDialog.Builder(this)
            .setTitle("নোট মুছবেন?")
            .setMessage("এই নোটটি স্থায়ীভাবে মুছে যাবে।")
            .setPositiveButton("মুছুন") { _, _ -> viewModel.deleteNote(note) }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_backup_txt -> {
                val date = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                saveTxtLauncher.launch("notekeeper_backup_$date.txt")
                true
            }
            R.id.action_backup_zip -> {
                val date = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                saveZipLauncher.launch("notekeeper_backup_$date.zip")
                true
            }
            R.id.action_restore_txt -> {
                openTxtLauncher.launch(arrayOf("text/plain"))
                true
            }
            R.id.action_restore_zip -> {
                openZipLauncher.launch(arrayOf("application/zip", "application/octet-stream"))
                true
            }
            R.id.action_delete_all -> {
                confirmDeleteAll()
                true
            }
            R.id.action_about -> {
                startActivity(Intent(this, AboutActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun confirmDeleteAll() {
        AlertDialog.Builder(this)
            .setTitle("সব নোট মুছবেন?")
            .setMessage("এটি সমস্ত নোট স্থায়ীভাবে মুছে ফেলবে। আগে ব্যাকআপ নিন।")
            .setPositiveButton("সব মুছুন") { _, _ -> viewModel.deleteAllNotes() }
            .setNegativeButton("বাতিল", null)
            .show()
    }
}
