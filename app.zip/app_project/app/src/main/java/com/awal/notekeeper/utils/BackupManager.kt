package com.awal.notekeeper.utils

import android.content.Context
import android.net.Uri
import com.awal.notekeeper.data.model.Note
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class BackupManager(private val context: Context) {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    fun exportAsTxt(context: Context, uri: Uri, notes: List<Note>) {
        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
            PrintWriter(OutputStreamWriter(outputStream, "UTF-8")).use { writer ->
                writer.println("NoteKeeper Backup")
                writer.println("Creator: Mohammod Abdul Awal")
                writer.println("Exported: ${dateFormat.format(Date())}")
                writer.println("Total Notes: ${notes.size}")
                writer.println("=".repeat(60))
                writer.println()

                notes.forEach { note ->
                    writer.println("NOTE_ID: ${note.id}")
                    writer.println("TITLE: ${note.title}")
                    writer.println("COLOR: ${note.colorIndex}")
                    writer.println("CREATED: ${dateFormat.format(Date(note.createdAt))}")
                    writer.println("LAST_EDITED: ${dateFormat.format(Date(note.lastEditedAt))}")
                    writer.println("PINNED: ${note.isPinned}")
                    writer.println("CONTENT:")
                    writer.println(note.content)
                    writer.println("-".repeat(40))
                    writer.println()
                }
            }
        }
    }

    fun exportAsZip(context: Context, uri: Uri, notes: List<Note>) {
        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
            ZipOutputStream(outputStream).use { zipOut ->
                // metadata.json
                val metaJson = gson.toJson(mapOf(
                    "app" to "NoteKeeper",
                    "creator" to "Mohammod Abdul Awal",
                    "exportDate" to dateFormat.format(Date()),
                    "totalNotes" to notes.size
                ))
                zipOut.putNextEntry(ZipEntry("metadata.json"))
                zipOut.write(metaJson.toByteArray(Charsets.UTF_8))
                zipOut.closeEntry()

                // notes.json
                val notesJson = gson.toJson(notes)
                zipOut.putNextEntry(ZipEntry("notes.json"))
                zipOut.write(notesJson.toByteArray(Charsets.UTF_8))
                zipOut.closeEntry()

                // individual txt per note
                notes.forEach { note ->
                    val safeTitle = note.title.ifBlank { "note_${note.id}" }
                        .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                        .take(50)
                    val entryName = "notes/${note.id}_${safeTitle}.txt"
                    zipOut.putNextEntry(ZipEntry(entryName))
                    val content = buildString {
                        appendLine("Title: ${note.title}")
                        appendLine("Created: ${dateFormat.format(Date(note.createdAt))}")
                        appendLine("Last Edited: ${dateFormat.format(Date(note.lastEditedAt))}")
                        appendLine("---")
                        append(note.content)
                    }
                    zipOut.write(content.toByteArray(Charsets.UTF_8))
                    zipOut.closeEntry()
                }
            }
        }
    }

    fun importFromTxt(context: Context, uri: Uri): List<Note> {
        val notes = mutableListOf<Note>()
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            BufferedReader(InputStreamReader(inputStream, "UTF-8")).use { reader ->
                val lines = reader.readLines()
                var i = 0
                while (i < lines.size) {
                    val line = lines[i]
                    if (line.startsWith("NOTE_ID:")) {
                        var id = 0L
                        var title = ""
                        var colorIndex = 0
                        var createdAt = System.currentTimeMillis()
                        var lastEditedAt = System.currentTimeMillis()
                        var isPinned = false
                        val contentLines = mutableListOf<String>()
                        var readingContent = false

                        try { id = line.removePrefix("NOTE_ID:").trim().toLong() } catch (e: Exception) {}
                        i++

                        while (i < lines.size && !lines[i].startsWith("-".repeat(10))) {
                            val l = lines[i]
                            when {
                                l.startsWith("TITLE:") -> title = l.removePrefix("TITLE:").trim()
                                l.startsWith("COLOR:") -> try { colorIndex = l.removePrefix("COLOR:").trim().toInt() } catch (e: Exception) {}
                                l.startsWith("PINNED:") -> isPinned = l.removePrefix("PINNED:").trim().toBoolean()
                                l == "CONTENT:" -> readingContent = true
                                readingContent -> contentLines.add(l)
                            }
                            i++
                        }

                        if (title.isNotBlank() || contentLines.isNotEmpty()) {
                            notes.add(Note(
                                title = title,
                                content = contentLines.joinToString("\n").trimEnd(),
                                colorIndex = colorIndex,
                                createdAt = createdAt,
                                lastEditedAt = lastEditedAt,
                                isPinned = isPinned
                            ))
                        }
                    }
                    i++
                }
            }
        }
        return notes
    }

    fun importFromZip(context: Context, uri: Uri): List<Note> {
        var notes = listOf<Note>()
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            ZipInputStream(inputStream).use { zipIn ->
                var entry = zipIn.nextEntry
                while (entry != null) {
                    if (entry.name == "notes.json") {
                        val json = zipIn.bufferedReader(Charsets.UTF_8).readText()
                        val type = object : TypeToken<List<Note>>() {}.type
                        notes = gson.fromJson(json, type) ?: emptyList()
                        // Reset IDs to avoid conflicts
                        notes = notes.map { it.copy(id = 0) }
                    }
                    zipIn.closeEntry()
                    entry = zipIn.nextEntry
                }
            }
        }
        return notes
    }
}
