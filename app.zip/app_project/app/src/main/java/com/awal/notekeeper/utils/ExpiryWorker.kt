package com.awal.notekeeper.utils

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.awal.notekeeper.data.local.NoteDatabase
import com.awal.notekeeper.data.repository.NoteRepository
import java.util.concurrent.TimeUnit

class ExpiryWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val dao = NoteDatabase.getDatabase(applicationContext).noteDao()
            val repo = NoteRepository(dao)
            val fiveYearsAgo = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(365L * 5)
            repo.deleteExpiredNotes(fiveYearsAgo)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
