package com.awal.notekeeper

import android.app.Application
import com.awal.notekeeper.utils.BootReceiver

class NoteKeeperApp : Application() {
    override fun onCreate() {
        super.onCreate()
        BootReceiver.scheduleExpiryWork(this)
    }
}
