package com.awal.notekeeper.data.local

import androidx.room.*
import com.awal.notekeeper.data.model.Note
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    @Query("SELECT * FROM notes ORDER BY lastEditedAt DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' ORDER BY lastEditedAt DESC")
    fun searchNotes(query: String): Flow<List<Note>>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getNoteById(id: Long): Note?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note): Long

    @Update
    suspend fun updateNote(note: Note)

    @Delete
    suspend fun deleteNote(note: Note)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNoteById(id: Long)

    @Query("DELETE FROM notes")
    suspend fun deleteAllNotes()

    @Query("SELECT * FROM notes ORDER BY lastEditedAt DESC")
    suspend fun getAllNotesSuspend(): List<Note>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notes: List<Note>)

    // Delete notes that haven't been edited for 5 years
    @Query("DELETE FROM notes WHERE lastEditedAt < :expiryTime")
    suspend fun deleteExpiredNotes(expiryTime: Long)

    @Query("SELECT COUNT(*) FROM notes WHERE lastEditedAt < :expiryTime")
    suspend fun countExpiredNotes(expiryTime: Long): Int
}
