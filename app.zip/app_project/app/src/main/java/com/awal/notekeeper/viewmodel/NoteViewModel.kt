package com.awal.notekeeper.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.awal.notekeeper.data.local.NoteDatabase
import com.awal.notekeeper.data.model.Note
import com.awal.notekeeper.data.repository.NoteRepository
import com.awal.notekeeper.utils.BackupManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class NoteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NoteRepository
    private val backupManager: BackupManager

    private val searchQuery = MutableStateFlow("")

    val notes: LiveData<List<Note>> = searchQuery.flatMapLatest { query ->
        if (query.isBlank()) repository.allNotes
        else repository.searchNotes(query)
    }.asLiveData()

    private val _operationResult = MutableLiveData<String>()
    val operationResult: LiveData<String> = _operationResult

    init {
        val dao = NoteDatabase.getDatabase(application).noteDao()
        repository = NoteRepository(dao)
        backupManager = BackupManager(application)
        checkAndDeleteExpiredNotes()
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun insertNote(note: Note, onComplete: (Long) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.insertNote(note)
            onComplete(id)
        }
    }

    fun updateNote(note: Note) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateNote(note)
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteNote(note)
        }
    }

    fun deleteNoteById(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteNoteById(id)
        }
    }

    fun getNoteById(id: Long, onResult: (Note?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val note = repository.getNoteById(id)
            viewModelScope.launch(Dispatchers.Main) {
                onResult(note)
            }
        }
    }

    private fun checkAndDeleteExpiredNotes() {
        viewModelScope.launch(Dispatchers.IO) {
            val fiveYearsAgo = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(365L * 5)
            val count = repository.countExpiredNotes(fiveYearsAgo)
            if (count > 0) {
                repository.deleteExpiredNotes(fiveYearsAgo)
            }
        }
    }

    fun backupAsTxt(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val notes = repository.getAllNotesSuspend()
                backupManager.exportAsTxt(context, uri, notes)
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "ব্যাকআপ সফল হয়েছে (TXT)"
                }
            } catch (e: Exception) {
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "ব্যাকআপ ব্যর্থ: ${e.message}"
                }
            }
        }
    }

    fun backupAsZip(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val notes = repository.getAllNotesSuspend()
                backupManager.exportAsZip(context, uri, notes)
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "ব্যাকআপ সফল হয়েছে (ZIP)"
                }
            } catch (e: Exception) {
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "ব্যাকআপ ব্যর্থ: ${e.message}"
                }
            }
        }
    }

    fun restoreFromTxt(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val notes = backupManager.importFromTxt(context, uri)
                repository.insertAll(notes)
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "${notes.size}টি নোট পুনরুদ্ধার হয়েছে"
                }
            } catch (e: Exception) {
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "পুনরুদ্ধার ব্যর্থ: ${e.message}"
                }
            }
        }
    }

    fun restoreFromZip(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val notes = backupManager.importFromZip(context, uri)
                repository.insertAll(notes)
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "${notes.size}টি নোট পুনরুদ্ধার হয়েছে"
                }
            } catch (e: Exception) {
                viewModelScope.launch(Dispatchers.Main) {
                    _operationResult.value = "পুনরুদ্ধার ব্যর্থ: ${e.message}"
                }
            }
        }
    }

    fun deleteAllNotes() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAllNotes()
            viewModelScope.launch(Dispatchers.Main) {
                _operationResult.value = "সব নোট মুছে ফেলা হয়েছে"
            }
        }
    }
}
