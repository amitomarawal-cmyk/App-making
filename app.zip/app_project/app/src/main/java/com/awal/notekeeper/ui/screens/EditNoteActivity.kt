package com.awal.notekeeper.ui.screens

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.awal.notekeeper.R
import com.awal.notekeeper.data.model.Note
import com.awal.notekeeper.databinding.ActivityEditNoteBinding
import com.awal.notekeeper.utils.NoteColors
import com.awal.notekeeper.utils.NoteUtils
import com.awal.notekeeper.viewmodel.NoteViewModel

class EditNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditNoteBinding
    private val viewModel: NoteViewModel by viewModels()

    private var currentNote: Note? = null
    private var selectedColorIndex = 0
    private var noteId: Long = -1L

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        noteId = intent.getLongExtra(EXTRA_NOTE_ID, -1L)

        setupColorPicker()
        setupContentWatcher()

        if (noteId != -1L) {
            loadNote(noteId)
        } else {
            updateBackground()
            binding.titleEditText.requestFocus()
        }
    }

    private fun loadNote(id: Long) {
        viewModel.getNoteById(id) { note ->
            note?.let {
                currentNote = it
                selectedColorIndex = it.colorIndex
                binding.titleEditText.setText(it.title)
                binding.contentEditText.setText(it.content)
                updateBackground()
                updateSizeInfo()
                updateColorPickerSelection()
            }
        }
    }

    private fun setupColorPicker() {
        val colorContainer = binding.colorPickerContainer
        colorContainer.removeAllViews()

        NoteColors.colors.forEach { noteColor ->
            val circle = View(this).apply {
                val size = resources.getDimensionPixelSize(R.dimen.color_circle_size)
                layoutParams = LinearLayout.LayoutParams(size, size).apply {
                    marginEnd = resources.getDimensionPixelSize(R.dimen.color_circle_margin)
                }
                background = ContextCompat.getDrawable(this@EditNoteActivity, R.drawable.circle_color_selector)
                backgroundTintList = ContextCompat.getColorStateList(this@EditNoteActivity, noteColor.backgroundRes)
                tag = noteColor.index
                contentDescription = noteColor.name
                setOnClickListener {
                    selectedColorIndex = noteColor.index
                    updateBackground()
                    updateColorPickerSelection()
                }
            }
            colorContainer.addView(circle)
        }
    }

    private fun updateColorPickerSelection() {
        val container = binding.colorPickerContainer
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i)
            val idx = child.tag as? Int ?: 0
            child.isSelected = (idx == selectedColorIndex)
            child.scaleX = if (idx == selectedColorIndex) 1.3f else 1.0f
            child.scaleY = if (idx == selectedColorIndex) 1.3f else 1.0f
        }
    }

    private fun updateBackground() {
        val noteColor = NoteColors.getColor(selectedColorIndex)
        val bgColor = ContextCompat.getColor(this, noteColor.backgroundRes)
        binding.root.setBackgroundColor(bgColor)
        binding.toolbar.setBackgroundColor(bgColor)
        window.statusBarColor = bgColor

        val textColor = ContextCompat.getColor(this, noteColor.textColorRes)
        binding.titleEditText.setTextColor(textColor)
        binding.titleEditText.setHintTextColor(textColor and 0x99FFFFFF.toInt())
        binding.contentEditText.setTextColor(textColor)
        binding.contentEditText.setHintTextColor(textColor and 0x99FFFFFF.toInt())
        binding.sizeInfoText.setTextColor(textColor and 0xBBFFFFFF.toInt())
        binding.toolbar.setTitleTextColor(textColor)
        binding.toolbar.navigationIcon?.setTint(textColor)
        binding.toolbar.overflowIcon?.setTint(textColor)
    }

    private fun setupContentWatcher() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) { updateSizeInfo() }
        }
        binding.titleEditText.addTextChangedListener(watcher)
        binding.contentEditText.addTextChangedListener(watcher)
    }

    private fun updateSizeInfo() {
        val title = binding.titleEditText.text?.toString() ?: ""
        val content = binding.contentEditText.text?.toString() ?: ""
        val bytes = (title + content).toByteArray(Charsets.UTF_8).size
        val sizeStr = when {
            bytes < 1024 -> "$bytes B"
            else -> String.format("%.1f KB", bytes / 1024.0)
        }
        binding.sizeInfoText.text = "আকার: $sizeStr"
    }

    private fun saveNote() {
        val title = binding.titleEditText.text?.toString()?.trim() ?: ""
        val content = binding.contentEditText.text?.toString() ?: ""

        if (title.isBlank() && content.isBlank()) {
            Toast.makeText(this, "খালি নোট সংরক্ষণ হয়নি", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val now = System.currentTimeMillis()
        if (currentNote != null) {
            val updated = currentNote!!.copy(
                title = title,
                content = content,
                colorIndex = selectedColorIndex,
                lastEditedAt = now
            )
            viewModel.updateNote(updated)
        } else {
            val newNote = Note(
                title = title,
                content = content,
                colorIndex = selectedColorIndex,
                createdAt = now,
                lastEditedAt = now
            )
            viewModel.insertNote(newNote)
        }
        finish()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_edit, menu)
        val noteColor = NoteColors.getColor(selectedColorIndex)
        val textColor = ContextCompat.getColor(this, noteColor.textColorRes)
        for (i in 0 until menu.size()) {
            menu.getItem(i).icon?.setTint(textColor)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                saveNote()
                true
            }
            R.id.action_save -> {
                saveNote()
                true
            }
            R.id.action_delete -> {
                if (currentNote != null) {
                    AlertDialog.Builder(this)
                        .setTitle("নোট মুছবেন?")
                        .setMessage("এই নোটটি স্থায়ীভাবে মুছে যাবে।")
                        .setPositiveButton("মুছুন") { _, _ ->
                            viewModel.deleteNote(currentNote!!)
                            finish()
                        }
                        .setNegativeButton("বাতিল", null)
                        .show()
                } else {
                    finish()
                }
                true
            }
            R.id.action_expiry_info -> {
                currentNote?.let {
                    val days = NoteUtils.getDaysUntilExpiry(it.lastEditedAt)
                    Toast.makeText(this, "মেয়াদ শেষ: $days দিন পরে", Toast.LENGTH_LONG).show()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onBackPressed() {
        saveNote()
    }
}
