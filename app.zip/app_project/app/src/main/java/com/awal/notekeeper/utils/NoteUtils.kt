package com.awal.notekeeper.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object NoteUtils {

    fun getSizeKb(note: com.awal.notekeeper.data.model.Note): String {
        val bytes = (note.title + note.content).toByteArray(Charsets.UTF_8).size
        return when {
            bytes < 1024 -> "${bytes} B"
            else -> String.format("%.1f KB", bytes / 1024.0)
        }
    }

    fun formatDate(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        return when {
            diff < TimeUnit.MINUTES.toMillis(1) -> "এইমাত্র"
            diff < TimeUnit.HOURS.toMillis(1) -> "${TimeUnit.MILLISECONDS.toMinutes(diff)} মিনিট আগে"
            diff < TimeUnit.DAYS.toMillis(1) -> "${TimeUnit.MILLISECONDS.toHours(diff)} ঘণ্টা আগে"
            diff < TimeUnit.DAYS.toMillis(7) -> "${TimeUnit.MILLISECONDS.toDays(diff)} দিন আগে"
            else -> SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))
        }
    }

    fun getDaysUntilExpiry(lastEditedAt: Long): Long {
        val expiryTime = lastEditedAt + TimeUnit.DAYS.toMillis(365L * 5)
        val remaining = expiryTime - System.currentTimeMillis()
        return TimeUnit.MILLISECONDS.toDays(remaining)
    }

    fun isExpiringSoon(lastEditedAt: Long): Boolean {
        return getDaysUntilExpiry(lastEditedAt) < 30
    }
}
