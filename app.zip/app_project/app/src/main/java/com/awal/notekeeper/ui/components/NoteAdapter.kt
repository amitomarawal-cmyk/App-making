package com.awal.notekeeper.ui.components

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.awal.notekeeper.data.model.Note
import com.awal.notekeeper.databinding.ItemNoteBinding
import com.awal.notekeeper.utils.NoteColors
import com.awal.notekeeper.utils.NoteUtils

class NoteAdapter(
    private val onNoteClick: (Note) -> Unit,
    private val onNoteLongClick: (Note) -> Unit
) : ListAdapter<Note, NoteAdapter.NoteViewHolder>(NoteDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class NoteViewHolder(private val binding: ItemNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(note: Note) {
            val ctx = binding.root.context
            val noteColor = NoteColors.getColor(note.colorIndex)
            val bgColor = ContextCompat.getColor(ctx, noteColor.backgroundRes)
            val textColor = ContextCompat.getColor(ctx, noteColor.textColorRes)

            binding.cardRoot.setCardBackgroundColor(bgColor)

            if (note.title.isNotBlank()) {
                binding.titleText.text = note.title
                binding.titleText.visibility = android.view.View.VISIBLE
            } else {
                binding.titleText.visibility = android.view.View.GONE
            }

            if (note.content.isNotBlank()) {
                // Show preview (limit lines for staggered grid)
                val preview = note.content.take(300)
                binding.contentText.text = preview
                binding.contentText.visibility = android.view.View.VISIBLE
            } else {
                binding.contentText.visibility = android.view.View.GONE
            }

            binding.titleText.setTextColor(textColor)
            binding.contentText.setTextColor(textColor and 0xDDFFFFFF.toInt())
            binding.sizeText.setTextColor(textColor and 0x99FFFFFF.toInt())
            binding.dateText.setTextColor(textColor and 0x99FFFFFF.toInt())

            binding.sizeText.text = NoteUtils.getSizeKb(note)
            binding.dateText.text = NoteUtils.formatDate(note.lastEditedAt)

            // Expiry warning
            if (NoteUtils.isExpiringSoon(note.lastEditedAt)) {
                binding.expiryWarning.visibility = android.view.View.VISIBLE
                binding.expiryWarning.setTextColor(textColor)
            } else {
                binding.expiryWarning.visibility = android.view.View.GONE
            }

            binding.root.setOnClickListener { onNoteClick(note) }
            binding.root.setOnLongClickListener {
                onNoteLongClick(note)
                true
            }
        }
    }

    class NoteDiffCallback : DiffUtil.ItemCallback<Note>() {
        override fun areItemsTheSame(oldItem: Note, newItem: Note) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Note, newItem: Note) = oldItem == newItem
    }
}
