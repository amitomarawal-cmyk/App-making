package com.awal.tabbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Message;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {

    static final String HOME = "about:home";
    static final int BLUE = 0xFF0D47A1;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final String UA_DESKTOP =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    static final String HOME_HTML = """
            <html><head>
            <meta name='viewport' content='width=device-width,initial-scale=1'>
            <style>
            body{margin:0;font-family:sans-serif;background:linear-gradient(160deg,#0D47A1,#42A5F5);
            min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-align:center}
            .logo{font-size:64px}
            h1{margin:6px 0 18px}
            form{width:88%;max-width:520px}
            input{width:100%;box-sizing:border-box;padding:14px 18px;border-radius:28px;border:0;font-size:16px;outline:0}
            .links{margin-top:22px}
            .links a{display:inline-block;margin:6px;padding:8px 14px;border-radius:18px;background:rgba(255,255,255,.2);color:#fff;text-decoration:none}
            .me{margin-top:34px;font-size:13px;opacity:.9;line-height:1.7}
            </style></head><body>
            <div class='logo'>&#127760;</div>
            <h1>Awal Browser</h1>
            <form action='https://www.google.com/search' method='get'>
            <input name='q' placeholder='Search Google or type a URL'>
            </form>
            <div class='links'>
            <a href='https://www.google.com'>Google</a>
            <a href='https://www.youtube.com'>YouTube</a>
            <a href='https://www.wikipedia.org'>Wikipedia</a>
            <a href='https://www.facebook.com'>Facebook</a>
            </div>
            <div class='me'>Creator: Mohammod Abdul Awal<br>
            Student: Department of English, National University.</div>
            </body></html>
            """;

    class Tab {
        WebView web;
        String title = "New tab";
        String url = HOME;
        boolean desktop = false;
        boolean pending = false;
    }

    final ArrayList<Tab> tabs = new ArrayList<>();
    int cur = -1;
    SharedPreferences sp;
    FrameLayout root, content;
    LinearLayout tabStrip, topBars;
    HorizontalScrollView tabScroll;
    EditText urlBox;
    ProgressBar progress;
    TextView exitFs;
    boolean fullscreen = false;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> fileCb;

    // ---------------------------------------------------------------- lifecycle
    @Override
    protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("awal", MODE_PRIVATE);
        buildUi();
        restoreTabs();
        handleIntent(getIntent());
        if (tabs.isEmpty()) newTab(HOME, false, true);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handleIntent(i);
    }

    void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            newTab(i.getDataString(), false, true);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveTabs();
        CookieManager.getInstance().flush();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (fullscreen) {
            setFullscreen(false);
        } else if (cur >= 0 && curTab().web.canGoBack()) {
            curTab().web.goBack();
        } else {
            moveTaskToBack(true);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 11 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    // ---------------------------------------------------------------- UI
    int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    TextView btn(String s, View.OnClickListener l) {
        TextView b = new TextView(this);
        b.setText(s);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        b.setTextColor(0xFF202124);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
        return b;
    }

    void buildUi() {
        root = new FrameLayout(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        topBars = new LinearLayout(this);
        topBars.setOrientation(LinearLayout.VERTICAL);

        tabScroll = new HorizontalScrollView(this);
        tabScroll.setBackgroundColor(BLUE);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabScroll.addView(tabStrip);
        topBars.addView(tabScroll, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFF1F3F4);
        bar.setPadding(dp(4), dp(4), dp(4), dp(4));
        bar.addView(btn("\u2039", v -> { if (curTab().web.canGoBack()) curTab().web.goBack(); }));
        bar.addView(btn("\u203A", v -> { if (curTab().web.canGoForward()) curTab().web.goForward(); }));
        bar.addView(btn("\u27F3", v -> curTab().web.reload()));

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        urlBox.setHint("Search or type URL");
        urlBox.setSelectAllOnFocus(true);
        urlBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setPadding(dp(14), 0, dp(14), 0);
        GradientDrawable ubg = new GradientDrawable();
        ubg.setColor(Color.WHITE);
        ubg.setCornerRadius(dp(20));
        urlBox.setBackground(ubg);
        urlBox.setOnEditorActionListener((v, a, e) -> {
            load(curTab(), urlBox.getText().toString());
            hideKb();
            return true;
        });
        bar.addView(urlBox, new LinearLayout.LayoutParams(0, dp(40), 1f));
        bar.addView(btn("\u2606", v -> addBookmark()));
        bar.addView(btn("\u22EE", v -> showMenu(v)));
        topBars.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);
        topBars.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));

        col.addView(topBars, new LinearLayout.LayoutParams(MATCH, WRAP));
        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        exitFs = new TextView(this);
        exitFs.setText("\u2921");
        exitFs.setTextColor(Color.WHITE);
        exitFs.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        exitFs.setGravity(Gravity.CENTER);
        GradientDrawable ebg = new GradientDrawable();
        ebg.setColor(0x99000000);
        ebg.setCornerRadius(dp(22));
        exitFs.setBackground(ebg);
        exitFs.setVisibility(View.GONE);
        exitFs.setOnClickListener(v -> setFullscreen(false));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.END);
        lp.setMargins(0, dp(40), dp(8), 0);
        root.addView(exitFs, lp);

        setContentView(root);
    }

    void refreshTabs() {
        tabStrip.removeAllViews();
        for (int idx = 0; idx < tabs.size(); idx++) {
            final Tab t = tabs.get(idx);
            final int pos = idx;
            boolean sel = idx == cur;
            LinearLayout chip = new LinearLayout(this);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(14));
            bg.setColor(sel ? 0xFFFFFFFF : 0x33FFFFFF);
            chip.setBackground(bg);
            chip.setPadding(dp(12), dp(6), dp(4), dp(6));

            TextView ttl = new TextView(this);
            String s = t.title == null ? "Tab" : t.title;
            if (s.length() > 16) s = s.substring(0, 15) + "\u2026";
            ttl.setText(s);
            ttl.setSingleLine(true);
            ttl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            ttl.setTextColor(sel ? BLUE : Color.WHITE);
            chip.addView(ttl);

            TextView x = new TextView(this);
            x.setText("  \u2715  ");
            x.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            x.setTextColor(sel ? BLUE : Color.WHITE);
            x.setOnClickListener(v -> closeTab(pos));
            chip.addView(x);

            chip.setOnClickListener(v -> switchTo(pos));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
            lp.setMargins(dp(3), dp(5), dp(3), dp(5));
            tabStrip.addView(chip, lp);
        }
        TextView plus = new TextView(this);
        plus.setText("  \uFF0B  ");
        plus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        plus.setTextColor(Color.WHITE);
        plus.setGravity(Gravity.CENTER);
        plus.setOnClickListener(v -> newTab(HOME, false, true));
        tabStrip.addView(plus, new LinearLayout.LayoutParams(WRAP, dp(40)));

        tabScroll.post(() -> {
            if (cur >= 0) {
                View c = tabStrip.getChildAt(cur);
                if (c != null) tabScroll.smoothScrollTo(Math.max(0, c.getLeft() - dp(20)), 0);
            }
        });
    }

    void updateUrlBox() {
        if (cur < 0) return;
        Tab t = curTab();
        urlBox.setText(HOME.equals(t.url) ? "" : t.url);
    }

    void hideKb() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
        urlBox.clearFocus();
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------- tabs
    Tab curTab() {
        return tabs.get(cur);
    }

    Tab createTab(String startUrl, boolean desktop) {
        final Tab t = new Tab();
        t.desktop = desktop;
        t.url = startUrl == null ? HOME : startUrl;
        final WebView w = new WebView(this);
        t.web = w;

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
        applyDesktop(t);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if (sc == null || "http".equals(sc) || "https".equals(sc) || "about".equals(sc)
                        || "data".equals(sc) || "blob".equals(sc) || "javascript".equals(sc)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                } catch (Exception e) {
                    toast("No app found to open this link");
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String u, Bitmap f) {
                t.url = (u != null && u.contains("home.local")) ? HOME : u;
                if (isCur(t)) updateUrlBox();
            }

            @Override
            public void onPageFinished(WebView view, String u) {
                String ti = view.getTitle();
                if (HOME.equals(t.url)) {
                    t.title = "Home";
                } else {
                    t.title = (ti != null && !ti.isEmpty()) ? ti : t.url;
                    addHistory(t.title, t.url);
                }
                refreshTabs();
                CookieManager.getInstance().flush();
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                if (!isCur(t)) return;
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onReceivedTitle(WebView view, String ti) {
                if (!HOME.equals(t.url) && ti != null && !ti.isEmpty()) {
                    t.title = ti;
                    refreshTabs();
                }
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message msg) {
                Tab nt = createTab(null, t.desktop);
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(nt.web);
                msg.sendToTarget();
                switchTo(tabs.indexOf(nt));
                return true;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                v.setBackgroundColor(Color.BLACK);
                root.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
                applyImmersive(true);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), 11);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        w.setDownloadListener((du, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(du));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String ck = CookieManager.getInstance().getCookie(du);
                if (ck != null) r.addRequestHeader("Cookie", ck);
                String fn = URLUtil.guessFileName(du, cd, mime);
                r.setTitle(fn);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                toast("Downloading: " + fn);
            } catch (Exception e) {
                toast("Download failed");
            }
        });

        w.setOnLongClickListener(v -> {
            WebView.HitTestResult h = ((WebView) v).getHitTestResult();
            int ty = h.getType();
            final String ex = h.getExtra();
            if (ex != null && (ty == WebView.HitTestResult.SRC_ANCHOR_TYPE
                    || ty == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)) {
                new AlertDialog.Builder(this).setTitle(ex)
                        .setItems(new String[]{"Open in new tab", "Copy link"}, (dg, which) -> {
                            if (which == 0) {
                                newTab(ex, t.desktop, false);
                                toast("Opened in new tab");
                            } else {
                                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                                cm.setPrimaryClip(ClipData.newPlainText("url", ex));
                                toast("Link copied");
                            }
                        }).show();
                return true;
            }
            return false;
        });

        w.setVisibility(View.GONE);
        content.addView(w, new FrameLayout.LayoutParams(MATCH, MATCH));
        tabs.add(t);
        return t;
    }

    boolean isCur(Tab t) {
        return cur >= 0 && cur < tabs.size() && tabs.get(cur) == t;
    }

    void applyDesktop(Tab t) {
        WebSettings s = t.web.getSettings();
        if (t.desktop) {
            s.setUserAgentString(UA_DESKTOP);
        } else {
            s.setUserAgentString(null);
        }
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
    }

    void newTab(String url, boolean desktop, boolean sw) {
        Tab t = createTab(url, desktop);
        if (url == null || HOME.equals(url)) loadHome(t);
        else load(t, url);
        if (sw) switchTo(tabs.indexOf(t));
        else refreshTabs();
    }

    void switchTo(int i) {
        if (i < 0 || i >= tabs.size()) return;
        cur = i;
        for (Tab x : tabs) x.web.setVisibility(View.GONE);
        Tab t = tabs.get(i);
        t.web.setVisibility(View.VISIBLE);
        if (t.pending) {
            t.pending = false;
            if (HOME.equals(t.url)) loadHome(t);
            else t.web.loadUrl(t.url);
        }
        updateUrlBox();
        progress.setVisibility(View.GONE);
        refreshTabs();
    }

    void closeTab(int i) {
        if (i < 0 || i >= tabs.size()) return;
        Tab t = tabs.remove(i);
        content.removeView(t.web);
        t.web.destroy();
        if (tabs.isEmpty()) {
            cur = -1;
            newTab(HOME, false, true);
            return;
        }
        if (cur >= tabs.size()) cur = tabs.size() - 1;
        else if (i < cur) cur--;
        switchTo(cur);
    }

    void loadHome(Tab t) {
        t.pending = false;
        t.url = HOME;
        t.title = "Home";
        t.web.loadDataWithBaseURL("https://home.local/", HOME_HTML, "text/html", "UTF-8", null);
    }

    void load(Tab t, String input) {
        String u = input.trim();
        if (u.isEmpty()) return;
        t.pending = false;
        if (u.equals(HOME)) {
            loadHome(t);
            return;
        }
        if (!u.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            if (u.contains(" ") || !u.contains(".")) {
                u = "https://www.google.com/search?q=" + Uri.encode(u);
            } else {
                u = "https://" + u;
            }
        }
        t.web.loadUrl(u);
    }

    // ---------------------------------------------------------------- persistence (tabs stay until YOU close them)
    void saveTabs() {
        try {
            JSONArray a = new JSONArray();
            for (Tab t : tabs) {
                String u = t.web.getUrl();
                if (u == null) u = t.url;
                if (u.contains("home.local")) u = HOME;
                JSONObject o = new JSONObject();
                o.put("u", u);
                o.put("t", t.title);
                o.put("d", t.desktop);
                a.put(o);
            }
            sp.edit().putString("tabs", a.toString()).putInt("cur", cur).apply();
        } catch (Exception ignored) {
        }
    }

    void restoreTabs() {
        try {
            JSONArray a = new JSONArray(sp.getString("tabs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Tab t = createTab(o.optString("u", HOME), o.optBoolean("d", false));
                t.title = o.optString("t", "Tab");
                t.pending = true;
            }
        } catch (Exception ignored) {
        }
        if (!tabs.isEmpty()) {
            int c = sp.getInt("cur", 0);
            switchTo(Math.min(Math.max(c, 0), tabs.size() - 1));
        }
    }

    ArrayList<String[]> readList(String key) {
        ArrayList<String[]> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                l.add(new String[]{o.optString("t"), o.optString("u")});
            }
        } catch (Exception ignored) {
        }
        return l;
    }

    void writeList(String key, ArrayList<String[]> l) {
        JSONArray a = new JSONArray();
        for (String[] x : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("t", x[0]);
                o.put("u", x[1]);
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        sp.edit().putString(key, a.toString()).apply();
    }

    void addHistory(String title, String url) {
        if (url == null) return;
        ArrayList<String[]> l = readList("history");
        if (!l.isEmpty() && l.get(0)[1].equals(url)) return;
        l.add(0, new String[]{title, url});
        while (l.size() > 300) l.remove(l.size() - 1);
        writeList("history", l);
    }

    void addBookmark() {
        Tab t = curTab();
        if (HOME.equals(t.url)) {
            toast("Open a website first");
            return;
        }
        ArrayList<String[]> l = readList("bookmarks");
        for (String[] x : l) {
            if (x[1].equals(t.url)) {
                toast("Already bookmarked");
                return;
            }
        }
        l.add(0, new String[]{t.title, t.url});
        writeList("bookmarks", l);
        toast("\u2605 Bookmarked");
    }

    void showList(final String title, final String key) {
        final ArrayList<String[]> l = readList(key);
        if (l.isEmpty()) {
            toast("Nothing here yet");
            return;
        }
        String[] names = new String[l.size()];
        for (int i = 0; i < l.size(); i++) {
            String[] x = l.get(i);
            names[i] = (x[0].isEmpty() ? x[1] : x[0]) + "\n" + x[1];
        }
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle(title + " (long-press = delete)")
                .setItems(names, (dg, which) -> load(curTab(), l.get(which)[1]))
                .setNeutralButton("Clear all", (dg, which) -> {
                    writeList(key, new ArrayList<>());
                    toast("Cleared");
                })
                .setNegativeButton("Close", null)
                .create();
        d.show();
        d.getListView().setOnItemLongClickListener((p, v, pos, id) -> {
            l.remove(pos);
            writeList(key, l);
            d.dismiss();
            showList(title, key);
            return true;
        });
    }

    // ---------------------------------------------------------------- menu & features
    void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        Menu m = pm.getMenu();
        m.add(0, 1, 0, "New tab");
        m.add(0, 2, 0, "Home");
        m.add(0, 3, 0, "Bookmarks");
        m.add(0, 4, 0, "History");
        MenuItem dm = m.add(0, 5, 0, "Desktop mode");
        dm.setCheckable(true);
        dm.setChecked(curTab().desktop);
        m.add(0, 6, 0, "Full screen");
        m.add(0, 7, 0, "Find in page");
        m.add(0, 8, 0, "Share page");
        m.add(0, 9, 0, "Clear cache");
        m.add(0, 10, 0, "Clear all data");
        m.add(0, 11, 0, "Close all tabs");
        m.add(0, 12, 0, "About");
        pm.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: newTab(HOME, false, true); break;
                case 2: loadHome(curTab()); updateUrlBox(); break;
                case 3: showList("Bookmarks", "bookmarks"); break;
                case 4: showList("History", "history"); break;
                case 5:
                    Tab t = curTab();
                    t.desktop = !t.desktop;
                    applyDesktop(t);
                    t.web.reload();
                    toast(t.desktop ? "Desktop mode ON" : "Mobile mode");
                    break;
                case 6: setFullscreen(true); break;
                case 7: findInPage(); break;
                case 8: sharePage(); break;
                case 9: clearCache(); break;
                case 10: confirmClearAll(); break;
                case 11: confirmCloseAll(); break;
                case 12: showAbout(); break;
            }
            return true;
        });
        pm.show();
    }

    void sharePage() {
        Tab t = curTab();
        if (HOME.equals(t.url)) {
            toast("Nothing to share");
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, t.url);
        startActivity(Intent.createChooser(i, "Share link"));
    }

    void findInPage() {
        final Tab t = curTab();
        final EditText in = new EditText(this);
        in.setSingleLine(true);
        in.setHint("Search in page");
        final AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Find in page")
                .setView(in)
                .setPositiveButton("Find", null)
                .setNeutralButton("Next", null)
                .setNegativeButton("Close", (dg, which) -> t.web.clearMatches())
                .create();
        d.show();
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> t.web.findAllAsync(in.getText().toString()));
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> t.web.findNext(true));
    }

    void clearCache() {
        for (Tab t : tabs) t.web.clearCache(true);
        toast("Cache cleared");
    }

    void confirmClearAll() {
        new AlertDialog.Builder(this)
                .setTitle("Clear all data?")
                .setMessage("Cache, cookies (you will be logged out), site storage, history and form data will be deleted. Tabs and bookmarks stay.")
                .setPositiveButton("Clear", (dg, which) -> {
                    clearCache();
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                    for (Tab t : tabs) {
                        t.web.clearHistory();
                        t.web.clearFormData();
                    }
                    sp.edit().remove("history").apply();
                    toast("All data cleared");
                })
                .setNegativeButton("Cancel", null).show();
    }

    void confirmCloseAll() {
        new AlertDialog.Builder(this)
                .setTitle("Close all tabs?")
                .setPositiveButton("Close all", (dg, which) -> {
                    while (!tabs.isEmpty()) {
                        Tab t = tabs.remove(tabs.size() - 1);
                        content.removeView(t.web);
                        t.web.destroy();
                    }
                    cur = -1;
                    newTab(HOME, false, true);
                })
                .setNegativeButton("Cancel", null).show();
    }

    void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("Awal Browser 1.0")
                .setMessage("A simple multi-tab browser.\n\nCreator: Mohammod Abdul Awal\nStudent: Department of English, National University.")
                .setPositiveButton("OK", null).show();
    }

    // ---------------------------------------------------------------- fullscreen
    void setFullscreen(boolean on) {
        fullscreen = on;
        topBars.setVisibility(on ? View.GONE : View.VISIBLE);
        exitFs.setVisibility(on ? View.VISIBLE : View.GONE);
        applyImmersive(on);
    }

    void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applyImmersive(fullscreen);
    }

    @SuppressWarnings("deprecation")
    void applyImmersive(boolean on) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            if (on) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            } else {
                c.show(WindowInsets.Type.systemBars());
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(on
                    ? (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) : 0);
        }
    }
}
