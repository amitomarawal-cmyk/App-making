package com.awal.glasslauncher

import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.*

class AppItem(
    val label: String, val pkg: String, val cn: ComponentName,
    val icon: Drawable, var count: Int
) {
    var x = 0f; var y = 0f; var r = 0f
    var fx = 0f; var fy = 0f; var fr = 0f
    var tx = 0f; var ty = 0f; var tr = 0f
}

/** A big glass circle full of app bubbles. More-used apps = bigger bubbles. Drag to pan. */
class BubbleView(ctx: Context) : View(ctx) {
    var onLaunch: ((AppItem) -> Unit)? = null
    var onLong: ((AppItem) -> Unit)? = null
    var onEmptyDoubleTap: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private var apps: List<AppItem> = emptyList()
    private var panX = 0f; private var panY = 0f; private var virtualR = 0f
    private var anim: ValueAnimator? = null

    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x30FFFFFF }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = d; color = 0x77FFFFFF }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER
        setShadowLayer(3f * d, 0f, d, 0xAA000000.toInt())
    }
    private val clip = Path()

    private var downX = 0f; private var downY = 0f; private var lastX = 0f; private var lastY = 0f
    private var moved = false; private var longFired = false; private var lastEmptyTap = 0L
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val longRun = Runnable {
        longFired = true
        hit(downX, downY)?.let { onLong?.invoke(it) }
    }

    fun setApps(list: List<AppItem>) {
        apps = list; panX = 0f; panY = 0f; relayout(true)
    }

    fun resetPan() { panX = 0f; panY = 0f; invalidate() }

    private fun radiusFor(count: Int) = min(62f, 21f + 11f * ln(1f + count)) * d

    fun relayout(animate: Boolean) {
        val placed = ArrayList<AppItem>()
        for (a in apps.sortedByDescending { it.count }) {
            a.tr = radiusFor(a.count)
            var px = 0f; var py = 0f
            if (placed.isNotEmpty()) {
                var th = 0f
                while (true) {
                    val rr = 1.6f * d * th
                    px = rr * cos(th); py = rr * sin(th)
                    if (placed.none { hypot(px - it.tx, py - it.ty) < it.tr + a.tr + 4f * d }) break
                    th += 4f * d / max(rr, 20f * d)
                }
            }
            a.tx = px; a.ty = py
            placed.add(a)
        }
        virtualR = apps.maxOfOrNull { hypot(it.tx, it.ty) + it.tr } ?: 0f
        anim?.cancel()
        for (a in apps) { a.fx = a.x; a.fy = a.y; a.fr = a.r }
        if (!animate) {
            for (a in apps) { a.x = a.tx; a.y = a.ty; a.r = a.tr }
            invalidate()
        } else {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 450
                addUpdateListener {
                    val f = it.animatedFraction
                    for (a in apps) {
                        a.x = a.fx + (a.tx - a.fx) * f
                        a.y = a.fy + (a.ty - a.fy) * f
                        a.r = a.fr + (a.tr - a.fr) * f
                    }
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f; val cy = h / 2f; val rad = min(cx, cy) - 3f * d
        disc.shader = RadialGradient(
            cx, cy, rad, intArrayOf(0x12FFFFFF, 0x26FFFFFF, 0x55FFFFFF),
            floatArrayOf(0f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        ring.shader = SweepGradient(
            cx, cy, intArrayOf(
                Color.argb(190, 255, 150, 220), Color.argb(190, 130, 220, 255),
                Color.argb(190, 190, 160, 255), Color.argb(190, 255, 150, 220)
            ), null
        )
        clip.reset(); clip.addCircle(cx, cy, rad - 2f * d, Path.Direction.CW)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val rad = min(cx, cy) - 3f * d
        c.drawCircle(cx, cy, rad, disc)
        c.drawCircle(cx, cy, rad, ring)
        c.save(); c.clipPath(clip)
        for (a in apps) {
            val sx = cx + a.x + panX; val sy = cy + a.y + panY
            if (hypot(sx - cx, sy - cy) > rad + a.r) continue
            c.drawCircle(sx, sy, a.r, fill)
            c.drawCircle(sx, sy, a.r, edge)
            val ic = a.r * 1.05f
            val top = sy - a.r * 0.78f
            a.icon.setBounds((sx - ic / 2).toInt(), top.toInt(), (sx + ic / 2).toInt(), (top + ic).toInt())
            a.icon.draw(c)
            tp.textSize = max(8f * d, a.r * 0.26f)
            val txt = TextUtils.ellipsize(a.label, tp, a.r * 1.65f, TextUtils.TruncateAt.END).toString()
            c.drawText(txt, sx, sy + a.r * 0.72f, tp)
        }
        c.restore()
    }

    private fun hit(x: Float, y: Float): AppItem? {
        val cx = width / 2f; val cy = height / 2f
        return apps.lastOrNull { hypot(x - (cx + it.x + panX), y - (cy + it.y + panY)) <= it.r }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val rad = min(width, height) / 2f
                if (hypot(e.x - width / 2f, e.y - height / 2f) > rad) return false
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                moved = false; longFired = false
                postDelayed(longRun, 550)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.x - downX, e.y - downY) > slop) { moved = true; removeCallbacks(longRun) }
                if (moved) {
                    panX += e.x - lastX; panY += e.y - lastY
                    val lim = max(0f, virtualR - min(width, height) * 0.3f)
                    val len = hypot(panX, panY)
                    if (len > lim && len > 0f) { panX *= lim / len; panY *= lim / len }
                    invalidate()
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (!moved && !longFired) {
                    val h = hit(e.x, e.y)
                    if (h != null) onLaunch?.invoke(h)
                    else {
                        val now = SystemClock.uptimeMillis()
                        if (now - lastEmptyTap < 320) { onEmptyDoubleTap?.invoke(); lastEmptyTap = 0 }
                        else lastEmptyTap = now
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRun)
        }
        return true
    }
}
