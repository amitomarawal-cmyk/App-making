package com.awal.glasslauncher

import android.app.admin.DeviceAdminReceiver

class LockAdmin : DeviceAdminReceiver()
