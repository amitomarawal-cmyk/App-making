package com.awal.mediaplayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.BassBoost;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.SurfaceHolder;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MediaPlaybackService extends Service {

    private static final String CHANNEL_ID = "MediaPlayerChannel";
    private static final int NOTIFICATION_ID = 1;

    private final IBinder binder = new LocalBinder();
    private MediaPlayer mediaPlayer;
    private BassBoost bassBoost;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;

    private SurfaceHolder surfaceHolder;
    private UiCallback uiCallback;
    private Handler progressHandler = new Handler(Looper.getMainLooper());

    private String currentFileName = "No media";
    private boolean isPlaying = false;
    private List<String> subtitlePaths = new ArrayList<>();
    private SubtitleParser subtitleParser;

    public interface UiCallback {
        void onProgressUpdate(int current, int total);
        void onPlayStateChanged(boolean isPlaying);
        void onSubtitleUpdate(String text);
    }

    public class LocalBinder extends Binder {
        MediaPlaybackService getService() { return MediaPlaybackService.this; }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        createNotificationChannel();
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
                case "ACTION_PLAY_PAUSE": togglePlayPause(); break;
                case "ACTION_STOP": stopPlayback(); break;
            }
        }
        return START_STICKY;
    }

    public void loadMedia(Uri uri, String fileName) {
        currentFileName = fileName;
        releasePlayer();

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                .build());

        try {
            mediaPlayer.setDataSource(getApplicationContext(), uri);
            if (surfaceHolder != null) mediaPlayer.setDisplay(surfaceHolder);
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(mp -> {
                mp.start();
                isPlaying = true;
                applyBassBoost();
                startProgressUpdater();
                updateNotification();
                if (uiCallback != null) uiCallback.onPlayStateChanged(true);
            });
            mediaPlayer.setOnCompletionListener(mp -> {
                isPlaying = false;
                if (uiCallback != null) uiCallback.onPlayStateChanged(false);
                updateNotification();
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void togglePlayPause() {
        if (mediaPlayer == null) return;
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            isPlaying = false;
        } else {
            mediaPlayer.start();
            isPlaying = true;
        }
        if (uiCallback != null) uiCallback.onPlayStateChanged(isPlaying);
        updateNotification();
    }

    public void stopPlayback() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            isPlaying = false;
        }
        if (uiCallback != null) uiCallback.onPlayStateChanged(false);
        stopForeground(true);
    }

    public void seekTo(int ms) {
        if (mediaPlayer != null) mediaPlayer.seekTo(ms);
    }

    public void setBassBoost(short strength) {
        if (bassBoost != null) {
            bassBoost.setStrength(strength);
        }
    }

    private void applyBassBoost() {
        if (mediaPlayer == null) return;
        try {
            if (bassBoost != null) bassBoost.release();
            bassBoost = new BassBoost(0, mediaPlayer.getAudioSessionId());
            bassBoost.setEnabled(true);
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void setSurfaceHolder(SurfaceHolder holder) {
        surfaceHolder = holder;
        if (mediaPlayer != null) mediaPlayer.setDisplay(holder);
    }

    public void setUiCallback(UiCallback cb) {
        uiCallback = cb;
    }

    public void showAudioTrackSelector(Context context) {
        if (mediaPlayer == null) return;
        MediaPlayer.TrackInfo[] tracks = mediaPlayer.getTrackInfo();
        List<String> audioTracks = new ArrayList<>();
        List<Integer> audioIndices = new ArrayList<>();

        for (int i = 0; i < tracks.length; i++) {
            if (tracks[i].getTrackType() == MediaPlayer.TrackInfo.MEDIA_TRACK_TYPE_AUDIO) {
                String lang = tracks[i].getLanguage();
                audioTracks.add("Track " + (audioIndices.size() + 1) +
                        (lang != null && !lang.equals("und") ? " [" + lang + "]" : ""));
                audioIndices.add(i);
            }
        }

        if (audioTracks.isEmpty()) {
            new AlertDialog.Builder(context)
                    .setTitle("Audio Tracks")
                    .setMessage("No multiple audio tracks found.")
                    .setPositiveButton("OK", null).show();
            return;
        }

        String[] items = audioTracks.toArray(new String[0]);
        new AlertDialog.Builder(context)
                .setTitle("Select Audio Track")
                .setItems(items, (d, which) -> {
                    mediaPlayer.selectTrack(audioIndices.get(which));
                })
                .show();
    }

    public void showSubtitleOptions(Context context, ActivityResultLauncher<String[]> launcher) {
        String[] options = {"Load from file (.srt)", "Disable subtitles"};
        new AlertDialog.Builder(context)
                .setTitle("Subtitles")
                .setItems(options, (d, which) -> {
                    if (which == 0) {
                        launcher.launch(new String[]{"*/*"});
                    } else {
                        if (uiCallback != null) uiCallback.onSubtitleUpdate("");
                    }
                })
                .show();
    }

    public void loadSubtitleFile(Uri uri) {
        subtitleParser = new SubtitleParser(getApplicationContext(), uri);
        subtitleParser.start();
        startSubtitleSync();
    }

    private void startSubtitleSync() {
        progressHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && subtitleParser != null) {
                    String text = subtitleParser.getSubtitleAt(mediaPlayer.getCurrentPosition());
                    if (uiCallback != null) uiCallback.onSubtitleUpdate(text);
                    progressHandler.postDelayed(this, 200);
                }
            }
        }, 200);
    }

    private void startProgressUpdater() {
        progressHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    if (uiCallback != null) {
                        uiCallback.onProgressUpdate(
                                mediaPlayer.getCurrentPosition(),
                                mediaPlayer.getDuration());
                    }
                }
                progressHandler.postDelayed(this, 500);
            }
        }, 500);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Media Playback", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Awal Media Player controls");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void updateNotification() {
        Intent playPauseIntent = new Intent(this, MediaPlaybackService.class);
        playPauseIntent.setAction("ACTION_PLAY_PAUSE");
        PendingIntent playPausePI = PendingIntent.getService(this, 0, playPauseIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, MediaPlaybackService.class);
        stopIntent.setAction("ACTION_STOP");
        PendingIntent stopPI = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPI = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_play_notification)
                .setContentTitle("Awal Media Player")
                .setContentText(currentFileName)
                .setContentIntent(openPI)
                .addAction(isPlaying ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        isPlaying ? "Pause" : "Play", playPausePI)
                .addAction(android.R.drawable.ic_media_previous, "Stop", stopPI)
                .setStyle(new androidx.media.app.NotificationCompat.MediaStyle()
                        .setShowActionsInCompactView(0, 1))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(isPlaying)
                .build();

        startForeground(NOTIFICATION_ID, notification);
    }

    private void releasePlayer() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (bassBoost != null) {
            bassBoost.release();
            bassBoost = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        releasePlayer();
        progressHandler.removeCallbacksAndMessages(null);
    }
}
