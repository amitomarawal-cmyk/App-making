package com.awal.mediaplayer;

import android.content.Context;
import android.net.Uri;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class SubtitleParser {
    private final Context context;
    private final Uri uri;
    private final List<SubtitleEntry> entries = new ArrayList<>();

    public SubtitleParser(Context context, Uri uri) {
        this.context = context;
        this.uri = uri;
    }

    public void start() {
        new Thread(() -> {
            try {
                parseSrt();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void parseSrt() throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(context.getContentResolver().openInputStream(uri)));
        String line;
        SubtitleEntry current = null;
        StringBuilder textBuilder = new StringBuilder();

        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) {
                if (current != null && textBuilder.length() > 0) {
                    current.text = textBuilder.toString().trim();
                    synchronized (entries) { entries.add(current); }
                    current = null;
                    textBuilder.setLength(0);
                }
            } else if (current == null) {
                // sequence number - skip
                current = new SubtitleEntry();
            } else if (current.startMs == 0 && line.contains("-->")) {
                String[] parts = line.split("-->");
                current.startMs = parseTime(parts[0].trim());
                current.endMs = parseTime(parts[1].trim());
            } else {
                if (textBuilder.length() > 0) textBuilder.append("\n");
                textBuilder.append(line.replaceAll("<[^>]*>", ""));
            }
        }
        reader.close();
    }

    private long parseTime(String time) {
        try {
            time = time.replace(',', '.');
            String[] parts = time.split(":");
            long h = Long.parseLong(parts[0]);
            long m = Long.parseLong(parts[1]);
            double s = Double.parseDouble(parts[2]);
            return (long)((h * 3600 + m * 60 + s) * 1000);
        } catch (Exception e) { return 0; }
    }

    public String getSubtitleAt(long ms) {
        synchronized (entries) {
            for (SubtitleEntry e : entries) {
                if (ms >= e.startMs && ms <= e.endMs) return e.text;
            }
        }
        return "";
    }

    private static class SubtitleEntry {
        long startMs, endMs;
        String text;
    }
}
