package com.awal.mediaplayer;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.media.audiofx.BassBoost;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.slider.Slider;

public class MainActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    private SurfaceView surfaceView;
    private ImageButton btnPlayPause, btnStop, btnOpenFile;
    private SeekBar seekBar;
    private Slider bassBoostSlider;
    private TextView tvFileName, tvCurrentTime, tvTotalTime, tvSubtitleDisplay;
    private Button btnAudioTrack, btnSubtitle;

    private MediaPlaybackService mediaService;
    private boolean isBound = false;

    private ActivityResultLauncher<String[]> filePickerLauncher;
    private ActivityResultLauncher<String> permissionLauncher;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MediaPlaybackService.LocalBinder binder = (MediaPlaybackService.LocalBinder) service;
            mediaService = binder.getService();
            isBound = true;
            mediaService.setSurfaceHolder(surfaceView.getHolder());
            mediaService.setUiCallback(uiCallback);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    private final MediaPlaybackService.UiCallback uiCallback = new MediaPlaybackService.UiCallback() {
        @Override
        public void onProgressUpdate(int current, int total) {
            runOnUiThread(() -> {
                seekBar.setMax(total);
                seekBar.setProgress(current);
                tvCurrentTime.setText(formatTime(current));
                tvTotalTime.setText(formatTime(total));
            });
        }

        @Override
        public void onPlayStateChanged(boolean isPlaying) {
            runOnUiThread(() -> {
                btnPlayPause.setImageResource(isPlaying ?
                        android.R.drawable.ic_media_pause :
                        android.R.drawable.ic_media_play);
            });
        }

        @Override
        public void onSubtitleUpdate(String text) {
            runOnUiThread(() -> {
                tvSubtitleDisplay.setText(text);
                tvSubtitleDisplay.setVisibility(text != null && !text.isEmpty() ?
                        View.VISIBLE : View.INVISIBLE);
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupFilePicker();
        setupPermissionLauncher();
        startAndBindService();
        setupClickListeners();
    }

    private void initViews() {
        surfaceView = findViewById(R.id.surfaceView);
        surfaceView.getHolder().addCallback(this);

        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnStop = findViewById(R.id.btnStop);
        btnOpenFile = findViewById(R.id.btnOpenFile);
        btnAudioTrack = findViewById(R.id.btnAudioTrack);
        btnSubtitle = findViewById(R.id.btnSubtitle);

        seekBar = findViewById(R.id.seekBar);
        bassBoostSlider = findViewById(R.id.bassBoostSlider);
        tvFileName = findViewById(R.id.tvFileName);
        tvCurrentTime = findViewById(R.id.tvCurrentTime);
        tvTotalTime = findViewById(R.id.tvTotalTime);
        tvSubtitleDisplay = findViewById(R.id.tvSubtitleDisplay);
    }

    private void setupFilePicker() {
        filePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                uri -> {
                    if (uri != null && isBound) {
                        getContentResolver().takePersistableUriPermission(uri,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        String name = getFileName(uri);
                        tvFileName.setText(name);
                        mediaService.loadMedia(uri, name);
                    }
                });
    }

    private void setupPermissionLauncher() {
        permissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> {
                    if (granted) openFilePicker();
                    else Toast.makeText(this, "Storage permission needed", Toast.LENGTH_SHORT).show();
                });
    }

    private void startAndBindService() {
        Intent intent = new Intent(this, MediaPlaybackService.class);
        startService(intent);
        bindService(intent, serviceConnection, BIND_AUTO_CREATE);
    }

    private void setupClickListeners() {
        btnOpenFile.setOnClickListener(v -> checkPermissionAndOpen());

        btnPlayPause.setOnClickListener(v -> {
            if (isBound) mediaService.togglePlayPause();
        });

        btnStop.setOnClickListener(v -> {
            if (isBound) mediaService.stopPlayback();
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (fromUser && isBound) mediaService.seekTo(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        bassBoostSlider.addOnChangeListener((slider, value, fromUser) -> {
            if (isBound && fromUser) mediaService.setBassBoost((short) value);
        });

        btnAudioTrack.setOnClickListener(v -> {
            if (isBound) mediaService.showAudioTrackSelector(this);
        });

        btnSubtitle.setOnClickListener(v -> {
            if (isBound) mediaService.showSubtitleOptions(this, filePickerLauncher);
        });
    }

    private void checkPermissionAndOpen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            openFilePicker();
        } else {
            String perm = Manifest.permission.READ_EXTERNAL_STORAGE;
            if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
                openFilePicker();
            } else {
                permissionLauncher.launch(perm);
            }
        }
    }

    private void openFilePicker() {
        filePickerLauncher.launch(new String[]{"video/*", "audio/*"});
    }

    private String getFileName(Uri uri) {
        String path = uri.getPath();
        if (path != null) {
            int cut = path.lastIndexOf('/');
            if (cut != -1) return path.substring(cut + 1);
        }
        return uri.toString();
    }

    private String formatTime(int ms) {
        int totalSec = ms / 1000;
        int hours = totalSec / 3600;
        int mins = (totalSec % 3600) / 60;
        int secs = totalSec % 60;
        if (hours > 0)
            return String.format("%d:%02d:%02d", hours, mins, secs);
        return String.format("%02d:%02d", mins, secs);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_about) {
            startActivity(new Intent(this, AboutActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        if (isBound) mediaService.setSurfaceHolder(holder);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (isBound) mediaService.setSurfaceHolder(null);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isBound) {
            unbindService(serviceConnection);
            isBound = false;
        }
    }
}
