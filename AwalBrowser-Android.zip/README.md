# Awal Browser (Android)

## Build APK by uploading this ZIP without extracting it locally

1. Create an empty GitHub repository.
2. Upload this file to the repository root with the exact name `AwalBrowser-Android.zip`.
3. Create the file `.github/workflows/build.yml` in GitHub and paste the contents of the separately provided `build.yml` file.
4. Commit both files to the `main` branch.
5. Open **Actions** → **Build Awal Browser APK** → **Run workflow**. A push of either file also triggers the workflow.
6. Open the completed workflow run and download the `AwalBrowser-debug-apk` artifact. Extract that downloaded artifact ZIP to get `app-debug.apk`.

Important: GitHub does not automatically unpack a ZIP in a repository. This workflow unpacks the uploaded project ZIP during the cloud build. The workflow YAML itself must be a normal file at `.github/workflows/build.yml`.

## Features
- Multiple tabs, restored after reopening the app; tabs are only closed manually by long-pressing a tab.
- Bookmarks and bookmark removal.
- Desktop mode toggle.
- Fullscreen toggle.
- Clear cache and clear browsing data (cookies, website storage and history). Saved tab list and bookmarks are kept.
- Creator credit in the app footer and About dialog.

Creator: Mohammod Abdul Awal
Student: Department of English, National University

This is a debug APK build intended for testing. A public release should use a securely stored signing key.
