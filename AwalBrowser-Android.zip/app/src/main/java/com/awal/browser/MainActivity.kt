package com.awal.browser

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.content.Context
import android.content.SharedPreferences
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private data class BrowserTab(var url: String = "https://www.google.com", var title: String = "New tab", var web: WebView? = null)
    private val tabs = mutableListOf<BrowserTab>()
    private val bookmarks = mutableListOf<Pair<String, String>>()
    private var active = 0
    private lateinit var prefs: SharedPreferences
    private lateinit var tabStrip: LinearLayout
    private lateinit var address: EditText
    private lateinit var pageHost: FrameLayout
    private lateinit var status: TextView
    private var desktopMode = false
    private var fullscreen = false
    private val ink = Color.rgb(16, 42, 67)
    private val mint = Color.rgb(53, 201, 165)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("awal_browser", Context.MODE_PRIVATE)
        desktopMode = prefs.getBoolean("desktop", false)
        loadBookmarks()
        buildUi()
        restoreTabs()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 13f; setTextColor(Color.WHITE)
        backgroundTintList = android.content.res.ColorStateList.valueOf(ink)
        setPadding(dp(8), 0, dp(8), 0); setOnClickListener { action() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(4), dp(8), dp(4)); setBackgroundColor(ink) }
        val logo = TextView(this).apply { text = "◉"; textSize = 25f; setTextColor(mint); setPadding(0,0,dp(8),0) }
        val title = TextView(this).apply { text = "Awal Browser"; textSize = 18f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE) }
        brand.addView(logo); brand.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
        brand.addView(button("＋") { newTab("https://www.google.com") })
        brand.addView(button("⋮") { showMenu() })
        root.addView(brand)

        tabStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(4), dp(3), dp(4), dp(3)); setBackgroundColor(Color.rgb(235,242,247)) }
        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tabStrip) }
        root.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(46)))

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        nav.addView(button("‹") { goBack() }, LinearLayout.LayoutParams(dp(42), dp(44)))
        nav.addView(button("›") { currentWeb()?.goForward() }, LinearLayout.LayoutParams(dp(42), dp(44)))
        nav.addView(button("↻") { currentWeb()?.reload() }, LinearLayout.LayoutParams(dp(42), dp(44)))
        address = EditText(this).apply {
            hint = "Search or enter website"; textSize = 14f; singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(240,244,247))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) { navigate(text.toString()); true } else false
            }
        }
        nav.addView(address, LinearLayout.LayoutParams(0, dp(44), 1f))
        nav.addView(button("★") { addBookmark() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(nav)

        status = TextView(this).apply { text = "Ready"; textSize = 11f; setTextColor(Color.DKGRAY); setPadding(dp(8), dp(2), dp(8), dp(2)) }
        root.addView(status)
        pageHost = FrameLayout(this)
        root.addView(pageHost, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "Creator: Mohammod Abdul Awal  •  Student: Department of English, National University"
            textSize = 10f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun makeWebView(tab: BrowserTab): WebView {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.useWideViewPort = desktopMode
        web.settings.loadWithOverviewMode = desktopMode
        web.settings.setSupportZoom(true)
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                if (u.startsWith("http://") || u.startsWith("https://")) return false
                return true
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                url?.let { tab.url = it; if (tabs.getOrNull(active) === tab) address.setText(it) }
                status.text = "Loading…"
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                url?.let { tab.url = it }
                tab.title = view?.title?.takeIf { it.isNotBlank() } ?: tab.url
                if (tabs.getOrNull(active) === tab) { address.setText(tab.url); status.text = tab.title }
                renderTabs(); saveTabs()
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tabs.getOrNull(active) === tab) status.text = if (newProgress < 100) "Loading $newProgress%" else (tab.title)
            }
            override fun onReceivedTitle(view: WebView?, title: String?) { if (!title.isNullOrBlank()) { tab.title = title; renderTabs() } }
        }
        tab.web = web
        return web
    }

    private fun restoreTabs() {
        val raw = prefs.getString("tabs", null)
        if (raw != null) try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                tabs.add(BrowserTab(o.optString("url", "https://www.google.com"), o.optString("title", "Tab")))
            }
            active = prefs.getInt("active", 0).coerceIn(0, (tabs.size - 1).coerceAtLeast(0))
        } catch (_: Exception) { tabs.clear() }
        if (tabs.isEmpty()) tabs.add(BrowserTab())
        showTab(active, true)
    }

    private fun saveTabs() {
        val arr = JSONArray()
        tabs.forEach { arr.put(JSONObject().put("url", it.url).put("title", it.title)) }
        prefs.edit().putString("tabs", arr.toString()).putInt("active", active).putBoolean("desktop", desktopMode).apply()
    }

    private fun renderTabs() {
        if (!::tabStrip.isInitialized) return
        tabStrip.removeAllViews()
        tabs.forEachIndexed { i, tab ->
            val b = Button(this).apply {
                text = (if (i == active) "● " else "") + (tab.title.ifBlank { "Tab" }.take(13)) + "  ×"
                textSize = 11f; isAllCaps = false; setTextColor(if (i == active) Color.WHITE else ink)
                backgroundTintList = android.content.res.ColorStateList.valueOf(if (i == active) ink else Color.rgb(215,226,234))
                setPadding(dp(5), 0, dp(5), 0)
                setOnClickListener {
                    if (text.toString().endsWith("×")) {
                        // A single tap activates; use long-press to close to avoid accidental tab loss.
                        showTab(i)
                    } else showTab(i)
                }
                setOnLongClickListener { closeTab(i); true }
            }
            tabStrip.addView(b, LinearLayout.LayoutParams(dp(138), dp(38)).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
    }

    private fun showTab(index: Int, initial: Boolean = false) {
        if (tabs.isEmpty()) tabs.add(BrowserTab())
        active = index.coerceIn(0, tabs.lastIndex)
        val tab = tabs[active]
        if (tab.web == null) makeWebView(tab)
        pageHost.removeAllViews()
        (tab.web?.parent as? android.view.ViewGroup)?.removeView(tab.web)
        pageHost.addView(tab.web, FrameLayout.LayoutParams(-1, -1))
        address.setText(tab.url)
        renderTabs(); saveTabs()
        if (initial || tab.web?.url == null) tab.web?.loadUrl(tab.url)
    }

    private fun currentWeb() = tabs.getOrNull(active)?.web
    private fun newTab(url: String = "https://www.google.com") {
        tabs.add(BrowserTab(url, "New tab"))
        showTab(tabs.lastIndex, true)
    }
    private fun closeTab(index: Int) {
        if (tabs.size <= 1) { tabs[0].web?.loadUrl("https://www.google.com"); tabs[0].url = "https://www.google.com"; tabs[0].title = "New tab"; saveTabs(); renderTabs(); return }
        tabs.getOrNull(index)?.web?.let { pageHost.removeView(it); it.stopLoading(); it.destroy() }
        tabs.removeAt(index)
        if (active >= tabs.size) active = tabs.lastIndex else if (index < active) active--
        showTab(active, false)
    }

    private fun navigate(input: String) {
        var value = input.trim()
        if (value.isEmpty()) return
        if (!value.contains("://")) {
            value = if (value.contains(" ") || !value.contains(".") || value.startsWith("about:")) {
                "https://www.google.com/search?q=" + android.net.Uri.encode(value)
            } else "https://$value"
        }
        tabs[active].url = value
        currentWeb()?.loadUrl(value)
        saveTabs()
    }
    private fun goBack() { val w = currentWeb(); if (w?.canGoBack() == true) w.goBack() else if (tabs.size > 1) closeTab(active) }

    private fun addBookmark() {
        val tab = tabs[active]
        if (bookmarks.any { it.second == tab.url }) { toast("Already bookmarked"); return }
        bookmarks.add(tab.title to tab.url); saveBookmarks(); toast("Bookmark saved")
    }
    private fun saveBookmarks() {
        val a = JSONArray()
        bookmarks.forEach { a.put(JSONObject().put("title", it.first).put("url", it.second)) }
        prefs.edit().putString("bookmarks", a.toString()).apply()
    }
    private fun loadBookmarks() {
        try {
            val a = JSONArray(prefs.getString("bookmarks", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); bookmarks.add(o.optString("title") to o.optString("url")) }
        } catch (_: Exception) {}
    }
    private fun showBookmarks() {
        if (bookmarks.isEmpty()) { toast("No bookmarks yet"); return }
        val labels = bookmarks.map { it.first.ifBlank { it.second } }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Bookmarks").setItems(labels) { _, which -> navigate(bookmarks[which].second) }
            .setNeutralButton("Manage") { _, _ -> manageBookmarks() }.setNegativeButton("Close", null).show()
    }
    private fun manageBookmarks() {
        if (bookmarks.isEmpty()) return
        AlertDialog.Builder(this).setTitle("Remove bookmark").setItems(bookmarks.map { it.first }.toTypedArray()) { _, which ->
            bookmarks.removeAt(which); saveBookmarks(); toast("Bookmark removed")
        }.setNegativeButton("Cancel", null).show()
    }
    private fun showMenu() {
        val options = arrayOf("New tab", "Bookmarks", "Desktop mode: ${if (desktopMode) "ON" else "OFF"}", "Fullscreen: ${if (fullscreen) "ON" else "OFF"}", "Clear cache", "Clear browsing data", "About")
        AlertDialog.Builder(this).setTitle("Awal Browser").setItems(options) { _, which ->
            when (which) {
                0 -> newTab()
                1 -> showBookmarks()
                2 -> { desktopMode = !desktopMode; prefs.edit().putBoolean("desktop", desktopMode).apply(); tabs.forEach { it.web?.settings?.apply { useWideViewPort = desktopMode; loadWithOverviewMode = desktopMode; userAgentString = if (desktopMode) "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36" else WebSettings.getDefaultUserAgent(this@MainActivity) }; it.web?.reload() }; toast("Desktop mode ${if (desktopMode) "on" else "off"}") }
                3 -> toggleFullscreen()
                4 -> clearCache()
                5 -> confirmClearData()
                6 -> about()
            }
        }.show()
    }
    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        if (fullscreen) window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        toast(if (fullscreen) "Fullscreen on" else "Fullscreen off")
    }
    private fun clearCache() {
        tabs.forEach { it.web?.clearCache(true) }
        WebStorage.getInstance().deleteOrigin("") // Best-effort; clear browsing data below removes all storage.
        toast("Cache cleared")
    }
    private fun confirmClearData() {
        AlertDialog.Builder(this).setTitle("Clear browsing data?")
            .setMessage("This removes website cookies, local storage, cache and browsing history. Your saved tabs and bookmarks stay.")
            .setPositiveButton("Clear") { _, _ ->
                tabs.forEach { it.web?.clearCache(true); it.web?.clearHistory() }
                CookieManager.getInstance().removeAllCookies { }
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
                android.webkit.WebViewDatabase.getInstance(this).clearFormData()
                toast("Browsing data cleared")
            }.setNegativeButton("Cancel", null).show()
    }
    private fun about() {
        AlertDialog.Builder(this).setTitle("About Awal Browser")
            .setMessage("A simple multi-tab browser. Tabs and bookmarks are saved on this device.\n\nCreator: Mohammod Abdul Awal\nStudent: Department of English, National University")
            .setPositiveButton("OK", null).show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onBackPressed() { goBack() }
    override fun onPause() { super.onPause(); saveTabs() }
    override fun onDestroy() {
        tabs.forEach { it.web?.let { w -> (w.parent as? android.view.ViewGroup)?.removeView(w); w.destroy() } }
        super.onDestroy()
    }
}
