package com.icontrol.launcher;

import android.graphics.drawable.Drawable;

public class AppInfo {
    public String label;
    public String packageName;
    public String activityName;
    public Drawable icon;
}
