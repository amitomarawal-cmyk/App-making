package com.icontrol.launcher;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class LockScreenActivity extends AppCompatActivity {

    private TextView lockClock, lockDate;
    private Timer timer;
    private View swipeUpHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Show on lock screen
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        setContentView(R.layout.activity_lock_screen);

        lockClock = findViewById(R.id.lock_clock);
        lockDate = findViewById(R.id.lock_date);
        swipeUpHint = findViewById(R.id.swipe_up_hint);

        startClock();

        // Swipe up to unlock
        View rootView = findViewById(R.id.lock_root);
        rootView.setOnClickListener(v -> unlock());

        View unlockBtn = findViewById(R.id.unlock_btn);
        if (unlockBtn != null) {
            unlockBtn.setOnClickListener(v -> unlock());
        }
    }

    private void startClock() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm", Locale.getDefault());
                    SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault());
                    Date now = new Date();
                    lockClock.setText(timeFormat.format(now));
                    lockDate.setText(dateFormat.format(now));
                });
            }
        }, 0, 1000);
    }

    private void unlock() {
        finish();
        overridePendingTransition(R.anim.slide_up, R.anim.fade_out);
    }

    @Override
    public void onBackPressed() {
        // Prevent back from lock screen
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
    }
}
