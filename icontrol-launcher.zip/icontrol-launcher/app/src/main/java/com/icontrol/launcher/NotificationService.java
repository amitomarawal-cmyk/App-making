package com.icontrol.launcher;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class NotificationService extends NotificationListenerService {

    public static NotificationService instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        // Notification received - broadcast to MainActivity
        sendBroadcast(new android.content.Intent("com.icontrol.NOTIFICATION_POSTED"));
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        sendBroadcast(new android.content.Intent("com.icontrol.NOTIFICATION_REMOVED"));
    }

    public StatusBarNotification[] getActiveNotifications() {
        try {
            return super.getActiveNotifications();
        } catch (Exception e) {
            return new StatusBarNotification[0];
        }
    }
}
