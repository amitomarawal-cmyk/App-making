package com.icontrol.launcher;

import android.app.WallpaperManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    private RecyclerView appGrid;
    private AppAdapter appAdapter;
    private TextView clockText, dateText;
    private LinearLayout dockBar;
    private View controlCenterBtn;
    private View lockBtn;
    private Timer clockTimer;
    private GestureDetector gestureDetector;

    // Control Center panel
    private View controlCenterPanel;
    private boolean controlCenterVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Full screen immersive
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );

        setContentView(R.layout.activity_main);

        initViews();
        loadWallpaper();
        loadApps();
        startClock();
        setupGestures();
    }

    private void initViews() {
        appGrid = findViewById(R.id.app_grid);
        clockText = findViewById(R.id.clock_text);
        dateText = findViewById(R.id.date_text);
        dockBar = findViewById(R.id.dock_bar);
        controlCenterPanel = findViewById(R.id.control_center_panel);
        lockBtn = findViewById(R.id.lock_btn);

        // Lock button
        lockBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, LockScreenActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        });

        // Control center swipe indicator
        View swipeIndicator = findViewById(R.id.swipe_indicator);
        if (swipeIndicator != null) {
            swipeIndicator.setOnClickListener(v -> toggleControlCenter());
        }

        // Close control center on tap outside
        controlCenterPanel.setOnClickListener(v -> toggleControlCenter());
    }

    private void loadWallpaper() {
        try {
            WallpaperManager wm = WallpaperManager.getInstance(this);
            Drawable wallpaper = wm.getDrawable();
            ImageView wallpaperView = findViewById(R.id.wallpaper_view);
            if (wallpaper != null && wallpaperView != null) {
                wallpaperView.setImageDrawable(wallpaper);
            }
        } catch (Exception e) {
            // Use default background
        }
    }

    private void loadApps() {
        List<AppInfo> apps = new ArrayList<>();
        PackageManager pm = getPackageManager();

        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> resolveInfos = pm.queryIntentActivities(intent, 0);

        for (ResolveInfo ri : resolveInfos) {
            String packageName = ri.activityInfo.packageName;
            if (packageName.equals(getPackageName())) continue;

            AppInfo app = new AppInfo();
            app.label = ri.loadLabel(pm).toString();
            app.packageName = packageName;
            app.activityName = ri.activityInfo.name;
            app.icon = ri.loadIcon(pm);
            apps.add(app);
        }

        appGrid.setLayoutManager(new GridLayoutManager(this, 4));
        appAdapter = new AppAdapter(this, apps);
        appGrid.setAdapter(appAdapter);
    }

    private void startClock() {
        clockTimer = new Timer();
        clockTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> updateClock());
            }
        }, 0, 1000);
    }

    private void updateClock() {
        SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm", Locale.getDefault());
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault());
        Date now = new Date();
        if (clockText != null) clockText.setText(timeFormat.format(now));
        if (dateText != null) dateText.setText(dateFormat.format(now));
    }

    private void setupGestures() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vX, float vY) {
                if (e1 != null && e2 != null) {
                    float diffY = e2.getY() - e1.getY();
                    float diffX = e2.getX() - e1.getX();
                    if (Math.abs(diffY) > Math.abs(diffX)) {
                        if (diffY > 100) {
                            // Swipe down - show control center from top
                            if (e1.getY() < 100) {
                                toggleControlCenter();
                            }
                        }
                    }
                }
                return true;
            }
        });
    }

    private void toggleControlCenter() {
        if (controlCenterVisible) {
            controlCenterPanel.animate()
                .translationY(-controlCenterPanel.getHeight())
                .alpha(0f)
                .setDuration(300)
                .withEndAction(() -> controlCenterPanel.setVisibility(View.GONE))
                .start();
            controlCenterVisible = false;
        } else {
            controlCenterPanel.setVisibility(View.VISIBLE);
            controlCenterPanel.setAlpha(0f);
            controlCenterPanel.animate()
                .translationY(0)
                .alpha(1f)
                .setDuration(300)
                .start();
            controlCenterVisible = true;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (clockTimer != null) clockTimer.cancel();
    }

    @Override
    public void onBackPressed() {
        // Launcher - don't exit on back press
        if (controlCenterVisible) {
            toggleControlCenter();
        }
    }
}
