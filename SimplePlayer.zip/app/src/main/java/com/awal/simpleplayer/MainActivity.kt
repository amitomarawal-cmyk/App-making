package com.awal.simpleplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView

class MediaAdapter(
    private val onTap: (Int) -> Unit,
    private val onLong: (Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.VH>() {
    var items: List<Media> = emptyList()
    val selected = HashSet<Uri>()

    class VH(val root: FrameLayout, val img: ImageView, val label: TextView, val check: TextView) :
        RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(p: ViewGroup, vt: Int): VH {
        val c = p.context
        val size = c.resources.displayMetrics.widthPixels / 3
        val root = FrameLayout(c).apply {
            layoutParams = RecyclerView.LayoutParams(size, size); setPadding(2, 2, 2, 2)
        }
        val img = ImageView(c).apply { setBackgroundColor(0xFF1E293B.toInt()) }
        val label = TextView(c).apply {
            setTextColor(Color.WHITE); textSize = 10f; maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setBackgroundColor(0x99000000.toInt()); setPadding(6, 2, 6, 2)
        }
        val check = TextView(c).apply {
            text = "✓"; setTextColor(Color.BLACK); setBackgroundColor(0xFF22D3EE.toInt())
            gravity = Gravity.CENTER; textSize = 14f; visibility = View.GONE
        }
        root.addView(img, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(label, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        root.addView(check, FrameLayout.LayoutParams(c.dp(24), c.dp(24), Gravity.TOP or Gravity.END))
        return VH(root, img, label, check)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val m = items[pos]
        h.label.text = (if (m.type == 0) "▶ " else "") + m.name
        if (m.type == 1) {
            Glide.with(h.img).clear(h.img)
            h.img.scaleType = ImageView.ScaleType.CENTER
            h.img.setImageResource(android.R.drawable.ic_lock_silent_mode_off)
        } else {
            h.img.scaleType = ImageView.ScaleType.CENTER_CROP
            Glide.with(h.img).load(m.uri).centerCrop().into(h.img)
        }
        val sel = m.uri in selected
        h.check.visibility = if (sel) View.VISIBLE else View.GONE
        h.img.alpha = if (sel) 0.5f else 1f
        h.root.setOnClickListener { onTap(h.bindingAdapterPosition) }
        h.root.setOnLongClickListener { onLong(h.bindingAdapterPosition); true }
    }

    override fun getItemCount() = items.size
}

class MainActivity : AppCompatActivity() {
    private var tab = 0
    private val data = arrayOf<List<Media>>(emptyList(), emptyList(), emptyList())
    private lateinit var adapter: MediaAdapter
    private lateinit var titleTv: TextView
    private lateinit var delBtn: TextView
    private lateinit var emptyTv: TextView
    private var asked = false

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (granted()) load() else Toast.makeText(this, "Permission needed to show media", Toast.LENGTH_LONG).show()
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun granted() = perms().all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0F172A.toInt()) }

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(8), dp(8), dp(8)) }
        titleTv = TextView(this).apply { text = "Simple Player"; setTextColor(Color.WHITE); textSize = 20f }
        delBtn = TextView(this).apply {
            text = "🗑"; textSize = 22f; setPadding(dp(12), dp(8), dp(12), dp(8)); visibility = View.GONE
            setOnClickListener { confirmDelete() }
        }
        val about = TextView(this).apply {
            text = "ⓘ"; setTextColor(Color.WHITE); textSize = 22f; setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setTitle("Simple Player v1.0")
                    .setMessage("Creator: Mohammod Abdul Awal\nStudent: Department of English, National University.")
                    .setPositiveButton("OK", null).show()
            }
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(delBtn); bar.addView(about)

        adapter = MediaAdapter({ tap(it) }, { longTap(it) })
        val rv = RecyclerView(this).apply { layoutManager = GridLayoutManager(this@MainActivity, 3); adapter = this@MainActivity.adapter }
        emptyTv = TextView(this).apply {
            text = "Nothing here yet"; setTextColor(0xFF94A3B8.toInt()); gravity = Gravity.CENTER; visibility = View.GONE
        }
        val frame = FrameLayout(this)
        frame.addView(rv, FrameLayout.LayoutParams(MATCH, MATCH))
        frame.addView(emptyTv, FrameLayout.LayoutParams(MATCH, MATCH))

        val nav = BottomNavigationView(this)
        nav.menu.add(Menu.NONE, 1, 0, "Video").setIcon(android.R.drawable.ic_media_play)
        nav.menu.add(Menu.NONE, 2, 1, "Audio").setIcon(android.R.drawable.ic_lock_silent_mode_off)
        nav.menu.add(Menu.NONE, 3, 2, "Photos").setIcon(android.R.drawable.ic_menu_gallery)
        nav.setOnItemSelectedListener { tab = it.itemId - 1; show(); true }

        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(frame, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (granted()) { if (adapter.selected.isEmpty()) load() }
        else if (!asked) { asked = true; permLauncher.launch(perms()) }
    }

    private fun query(base: Uri, type: Int): List<Media> {
        val list = ArrayList<Media>()
        val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
        try {
            contentResolver.query(base, proj, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                val i = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val n = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (c.moveToNext()) list.add(Media(ContentUris.withAppendedId(base, c.getLong(i)), c.getString(n) ?: "", type))
            }
        } catch (_: Exception) {}
        return list
    }

    private fun load() {
        Thread {
            val v = query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, 0)
            val a = query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, 1)
            val p = query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, 2)
            runOnUiThread { data[0] = v; data[1] = a; data[2] = p; show() }
        }.start()
    }

    private fun show() {
        adapter.selected.clear()
        adapter.items = data[tab]
        adapter.notifyDataSetChanged()
        emptyTv.visibility = if (data[tab].isEmpty()) View.VISIBLE else View.GONE
        updateBar()
    }

    private fun updateBar() {
        val n = adapter.selected.size
        titleTv.text = if (n == 0) "Simple Player" else "$n selected"
        delBtn.visibility = if (n == 0) View.GONE else View.VISIBLE
    }

    private fun tap(i: Int) {
        if (i < 0) return
        val m = adapter.items[i]
        if (adapter.selected.isNotEmpty()) toggle(m) else {
            Shared.uris = adapter.items.map { it.uri }
            val cls = if (m.type == 2) ImageActivity::class.java else PlayerActivity::class.java
            startActivity(Intent(this, cls).setData(m.uri))
        }
    }

    private fun longTap(i: Int) { if (i >= 0) toggle(adapter.items[i]) }

    private fun toggle(m: Media) {
        if (!adapter.selected.remove(m.uri)) adapter.selected.add(m.uri)
        adapter.notifyDataSetChanged(); updateBar()
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this).setTitle("Delete ${adapter.selected.size} item(s)?")
            .setMessage("This cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> doDelete() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun doDelete() {
        val uris = adapter.selected.toList()
        if (Build.VERSION.SDK_INT >= 30) {
            val pi = MediaStore.createDeleteRequest(contentResolver, uris)
            startIntentSenderForResult(pi.intentSender, 77, null, 0, 0, 0)
        } else {
            Thread {
                uris.forEach { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                runOnUiThread { load() }
            }.start()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, d: Intent?) {
        super.onActivityResult(requestCode, resultCode, d)
        if (requestCode == 77 && resultCode == Activity.RESULT_OK) load()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (adapter.selected.isNotEmpty()) { adapter.selected.clear(); adapter.notifyDataSetChanged(); updateBar() }
        else super.onBackPressed()
    }
}
