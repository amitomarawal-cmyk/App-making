package com.awal.simpleplayer

import android.content.Context
import android.net.Uri
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** type: 0 = video, 1 = audio, 2 = photo */
data class Media(val uri: Uri, val name: String, val type: Int)

object Shared { var uris: List<Uri> = emptyList() }

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Pinch-zoom, pan, double-tap reset, 90-degree rotation for any view. */
class ZoomHelper(private val t: View, private val onTap: () -> Unit = {}) : View.OnTouchListener {
    private var base = 1f
    private var scale = 1f
    private var lx = 0f
    private var ly = 0f
    private var ready = false

    private val sd = ScaleGestureDetector(t.context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            scale = (scale * d.scaleFactor).coerceIn(base, base * 6f)
            t.scaleX = scale; t.scaleY = scale
            if (scale <= base + 0.01f) { t.translationX = 0f; t.translationY = 0f }
            return true
        }
    })
    private val gd = GestureDetector(t.context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean { reset(); return true }
    })

    override fun onTouch(v: View, e: MotionEvent): Boolean {
        sd.onTouchEvent(e); gd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> ready = false
            MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1 && scale > base + 0.01f) {
                if (ready) { t.translationX += e.rawX - lx; t.translationY += e.rawY - ly }
                lx = e.rawX; ly = e.rawY; ready = true
            }
        }
        return true
    }

    fun reset() {
        scale = base; t.scaleX = scale; t.scaleY = scale
        t.translationX = 0f; t.translationY = 0f
    }

    fun clear() { t.rotation = 0f; base = 1f; reset() }

    fun rotate() {
        t.rotation = (t.rotation + 90f) % 360f
        val w = t.width.toFloat(); val h = t.height.toFloat()
        base = if ((t.rotation / 90f).toInt() % 2 != 0 && w > 0 && h > 0) minOf(w / h, h / w) else 1f
        reset()
    }
}
