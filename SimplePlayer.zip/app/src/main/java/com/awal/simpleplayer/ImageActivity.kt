package com.awal.simpleplayer

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bumptech.glide.Glide

class ImageActivity : AppCompatActivity() {
    private var uris: List<Uri> = emptyList()
    private var idx = 0
    private lateinit var iv: ImageView
    private lateinit var zoom: ZoomHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = intent.data
        if (d == null) { finish(); return }
        val shared = Shared.uris
        uris = if (d in shared) shared else listOf(d)
        idx = uris.indexOf(d)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        zoom = ZoomHelper(iv)
        iv.setOnTouchListener(zoom)
        root.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))

        fun btn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 22f
            setPadding(dp(28), dp(12), dp(28), dp(12)); setOnClickListener { f() }
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER; setBackgroundColor(0x66000000)
            if (uris.size > 1) addView(btn("◀") { go(-1) })
            addView(btn("↻") { zoom.rotate() })
            if (uris.size > 1) addView(btn("▶") { go(1) })
        }
        root.addView(bar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        setContentView(root)
        showImage()
    }

    private fun go(step: Int) {
        idx = (idx + step + uris.size) % uris.size
        showImage()
    }

    private fun showImage() {
        zoom.clear()
        Glide.with(this).load(uris[idx]).into(iv)
    }
}
