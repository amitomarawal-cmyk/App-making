package com.awal.simpleplayer

import android.graphics.Color
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var pv: PlayerView
    private lateinit var zoom: ZoomHelper
    private lateinit var titleTv: TextView
    private var eq: Equalizer? = null
    private val levels = HashMap<Int, Short>()
    private var resizeIdx = 0
    private val modes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FILL
    )
    private val modeNames = arrayOf("Fit", "Crop-zoom", "Stretch")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = intent.data
        if (data == null) { finish(); return }
        val shared = Shared.uris
        val list = if (data in shared) shared else listOf(data)
        val start = list.indexOf(data)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        player = ExoPlayer.Builder(this, DefaultRenderersFactory(this).setEnableDecoderFallback(true)).build()
        pv = PlayerView(this)
        pv.player = player
        pv.setShowSubtitleButton(true)
        pv.controllerShowTimeoutMs = 3000
        pv.setBackgroundColor(Color.BLACK)
        zoom = ZoomHelper(pv) { if (pv.isControllerFullyVisible) pv.hideController() else pv.showController() }
        pv.setOnTouchListener(zoom)

        fun btn(t: String, f: () -> Unit) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 16f
            setPadding(dp(14), dp(10), dp(14), dp(10)); setOnClickListener { f() }
        }
        titleTv = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; maxLines = 1 }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(0x66000000)
            addView(btn("←") { finish() })
            addView(titleTv, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(btn("↻") { zoom.rotate() })
            addView(btn("⤢") {
                resizeIdx = (resizeIdx + 1) % modes.size
                pv.resizeMode = modes[resizeIdx]
                Toast.makeText(this@PlayerActivity, modeNames[resizeIdx], Toast.LENGTH_SHORT).show()
            })
            addView(btn("EQ") { showEq() })
        }
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            top.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
        })

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))
        setContentView(root)

        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                titleTv.text = nameOf(mediaItem?.localConfiguration?.uri)
                zoom.clear()
            }
        })
        player.addAnalyticsListener(object : AnalyticsListener {
            override fun onAudioSessionIdChanged(eventTime: AnalyticsListener.EventTime, audioSessionId: Int) {
                setupEq(audioSessionId)
            }
        })
        player.setMediaItems(list.map { MediaItem.fromUri(it) }, if (start < 0) 0 else start, 0L)
        player.prepare()
        player.playWhenReady = true
        titleTv.text = nameOf(data)
        if (player.audioSessionId != C.AUDIO_SESSION_ID_UNSET) setupEq(player.audioSessionId)
    }

    private fun nameOf(u: Uri?): String {
        if (u == null) return ""
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: ""
            }
        } catch (_: Exception) {}
        return u.lastPathSegment ?: ""
    }

    private fun setupEq(id: Int) {
        try { eq?.release() } catch (_: Exception) {}
        eq = try {
            Equalizer(0, id).also { e ->
                e.enabled = true
                levels.forEach { (b, l) -> if (b < e.numberOfBands) e.setBandLevel(b.toShort(), l) }
            }
        } catch (_: Exception) { null }
    }

    private fun showEq() {
        val e = eq
        if (e == null) { Toast.makeText(this, "Equalizer not available", Toast.LENGTH_SHORT).show(); return }
        val lay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), dp(10)) }
        val min = e.bandLevelRange[0].toInt()
        val max = e.bandLevelRange[1].toInt()
        for (b in 0 until e.numberOfBands) {
            val hz = e.getCenterFreq(b.toShort()) / 1000
            lay.addView(TextView(this).apply { text = if (hz >= 1000) "${hz / 1000} kHz" else "$hz Hz" })
            lay.addView(SeekBar(this).apply {
                this.max = max - min
                progress = e.getBandLevel(b.toShort()) - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) {
                            val lv = (p + min).toShort()
                            try { e.setBandLevel(b.toShort(), lv) } catch (_: Exception) {}
                            levels[b] = lv
                        }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        AlertDialog.Builder(this).setTitle("Equalizer")
            .setView(ScrollView(this).apply { addView(lay) })
            .setPositiveButton("OK", null).show()
    }

    override fun onStop() { super.onStop(); player.pause() }

    override fun onDestroy() {
        super.onDestroy()
        try { eq?.release() } catch (_: Exception) {}
        player.release()
    }
}
