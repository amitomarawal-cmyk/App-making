package com.awal.simplephone

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentProviderOperation
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.telephony.SmsManager
import android.app.role.RoleManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    data class C(val id: Long, val key: String, val name: String, val num: String)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var content: FrameLayout
    private var tab = 0
    private var inThread = false
    private var pending = ""

    private fun wanted(): List<String> {
        val l = mutableListOf(
            Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val bar = LinearLayout(this)
        listOf("Dial", "Calls", "SMS", "Contacts", "More").forEachIndexed { i, t ->
            bar.addView(Button(this).apply {
                text = t; textSize = 11f; isAllCaps = false
                setOnClickListener { go(i) }
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        val missing = wanted().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else go(0)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        val part = Uri.decode(d.schemeSpecificPart ?: "").substringBefore("?").split(";", ",")[0].trim()
        when (d.scheme) {
            "tel" -> { pending = part; go(0) }
            "sms", "smsto", "mms", "mmsto" -> if (part.isNotEmpty()) threadView(part, i.getStringExtra("sms_body"))
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); go(tab)
    }

    override fun onBackPressed() {
        if (inThread) go(2) else super.onBackPressed()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun fmt(ms: Long) = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(ms))

    private fun go(i: Int) {
        tab = i; inThread = false
        content.removeAllViews()
        content.addView(when (i) {
            0 -> dialView(); 1 -> callsView(); 2 -> smsView(); 3 -> contactsView(); else -> moreView()
        })
    }

    private fun list(items: List<String>, onClick: (Int) -> Unit) = ListView(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, items)
        setOnItemClickListener { _, _, i, _ -> onClick(i) }
    }

    private fun normalize(s: String) =
        s.trim().map { c -> if (c in '০'..'৯') '0' + (c - '০') else c }.joinToString("").replace(" ", "")

    private fun hasPhoneState() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun sims(): List<SubscriptionInfo> = try {
        if (!hasPhoneState()) emptyList()
        else (getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList ?: emptyList())
            .sortedBy { it.simSlotIndex }
    } catch (e: Exception) { emptyList() }

    private fun simLabel(s: SubscriptionInfo) = "SIM " + (s.simSlotIndex + 1) + ": " + s.displayName

    private fun simAccounts(): List<PhoneAccountHandle> = try {
        if (!hasPhoneState()) emptyList()
        else {
            val tc = getSystemService(TelecomManager::class.java)
            tc.callCapablePhoneAccounts.filter {
                tc.getPhoneAccount(it)?.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true
            }
        }
    } catch (e: Exception) { emptyList() }

    private fun placeCall(n: String, h: PhoneAccountHandle?) {
        val u = Uri.fromParts("tel", n, null)
        val i = Intent(Intent.ACTION_CALL, u)
        if (h != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h)
        try { startActivity(i) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }

    private fun call(raw: String) {
        val n = normalize(raw)
        if (n.isBlank()) return
        if (n.endsWith("#") && (n.startsWith("*") || n.startsWith("#"))) {
            val sl = sims()
            if (sl.size > 1) {
                AlertDialog.Builder(this).setTitle("Select SIM")
                    .setItems(sl.map { simLabel(it) }.toTypedArray()) { _, w -> ussd(n, sl[w].subscriptionId) }
                    .show()
            } else ussd(n, null)
            return
        }
        val acc = simAccounts()
        if (acc.size > 1) {
            val tc = getSystemService(TelecomManager::class.java)
            val labels = acc.mapIndexed { i, h -> tc.getPhoneAccount(h)?.label?.toString() ?: ("SIM " + (i + 1)) }
            AlertDialog.Builder(this).setTitle("Call with")
                .setItems(labels.toTypedArray()) { _, w -> placeCall(n, acc[w]) }
                .show()
        } else placeCall(n, null)
    }

    private fun ussd(code: String, subId: Int?) {
        if (Build.VERSION.SDK_INT < 26) { placeCall(code, null); return }
        try {
            val base = getSystemService(TelephonyManager::class.java)
            val tm = if (subId != null) base.createForSubscriptionId(subId) else base
            tm.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(t: TelephonyManager, request: String, response: CharSequence) {
                    val e = EditText(this@MainActivity).apply { hint = "Reply (optional)" }
                    AlertDialog.Builder(this@MainActivity).setTitle(request).setMessage(response).setView(e)
                        .setPositiveButton("Send") { _, _ ->
                            val r = e.text.toString().trim()
                            if (r.isNotEmpty()) ussd(r, subId)
                        }
                        .setNegativeButton("Close", null).show()
                }

                override fun onReceiveUssdResponseFailed(t: TelephonyManager, request: String, failureCode: Int) {
                    AlertDialog.Builder(this@MainActivity).setTitle("USSD failed")
                        .setMessage("Code: " + request + "\nError: " + failureCode)
                        .setPositiveButton("Try as call") { _, _ -> placeCall(code, null) }
                        .setNegativeButton("Close", null).show()
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { toast("USSD error: " + e.message) }
    }

    private fun t9(s: String) = s.lowercase().map {
        when (it) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> it; else -> ' '
        }
    }.joinToString("")

    // ---------- data ----------
    private fun loadContacts(): List<C> {
        val out = ArrayList<C>()
        try {
            contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                while (c.moveToNext())
                    out.add(C(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: ""))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun addContact(name: String, num: String) {
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
            .withValue(StructuredName.DISPLAY_NAME, name).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
            .withValue(Phone.NUMBER, num)
            .withValue(Phone.TYPE, Phone.TYPE_MOBILE).build())
        contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
    }

    // ---------- Dialer ----------
    private fun dialView(): View {
        val col = vbox().apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val num = EditText(this).apply {
            textSize = 28f; gravity = Gravity.CENTER; hint = "Number / Name"
            inputType = InputType.TYPE_CLASS_PHONE; showSoftInputOnFocus = false
        }
        val matches = vbox()
        val all = loadContacts()
        num.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                matches.removeAllViews()
                val d = s.toString()
                if (d.isEmpty()) return
                all.filter { t9(it.name).contains(d) || it.num.filter { ch -> ch.isDigit() }.contains(d) }
                    .take(3).forEach { c ->
                        matches.addView(TextView(this@MainActivity).apply {
                            text = c.name + "  " + c.num; textSize = 16f
                            setPadding(dp(12), dp(8), dp(12), dp(8))
                            setOnClickListener { num.setText(c.num) }
                        })
                    }
            }
        })
        col.addView(num); col.addView(matches)
        if (pending.isNotBlank()) { num.setText(pending); pending = "" }
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            for (k in 0 until 3) {
                val key = keys[r * 3 + k]
                row.addView(Button(this).apply {
                    text = key; textSize = 22f; setOnClickListener { num.append(key) }
                }, LinearLayout.LayoutParams(0, dp(64), 1f))
            }
            col.addView(row)
        }
        val last = LinearLayout(this)
        last.addView(btn("⌫") {
            val t = num.text.toString(); if (t.isNotEmpty()) num.setText(t.dropLast(1))
        }, LinearLayout.LayoutParams(0, dp(64), 1f))
        last.addView(btn("Call") { call(num.text.toString()) }, LinearLayout.LayoutParams(0, dp(64), 2f))
        col.addView(last)
        return col
    }

    // ---------- Call log ----------
    private fun callsView(): View {
        val rows = ArrayList<String>(); val nums = ArrayList<String>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && rows.size < 200) {
                    val n = c.getString(0) ?: ""
                    val nm = c.getString(1)
                    val t = when (c.getInt(2)) { 1 -> "Received"; 2 -> "Outgoing"; 3 -> "Missed"; else -> "Other" }
                    rows.add((if (nm.isNullOrBlank()) n else nm) + "\n" + t + " · " + fmt(c.getLong(3)))
                    nums.add(n)
                }
            }
        } catch (e: Exception) { }
        return list(rows) { call(nums[it]) }
    }

    // ---------- SMS ----------
    private fun smsView(): View {
        val col = vbox()
        col.addView(btn("+ New message") {
            val e = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            AlertDialog.Builder(this).setView(e)
                .setPositiveButton("OK") { _, _ -> if (e.text.isNotBlank()) threadView(e.text.toString().trim()) }
                .show()
        })
        val seen = LinkedHashMap<String, String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body"), null, null, "date DESC")
                ?.use { c ->
                    while (c.moveToNext()) {
                        val a = c.getString(0) ?: continue
                        if (!seen.containsKey(a)) seen[a] = c.getString(1) ?: ""
                    }
                }
        } catch (e: Exception) { }
        val keys = seen.keys.toList()
        col.addView(list(keys.map { it + "\n" + seen[it]!!.take(60) }) { threadView(keys[it]) },
            LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    private fun threadView(addr: String, prefill: String? = null) {
        inThread = true
        val items = ArrayList<String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("body", "type"),
                "address=?", arrayOf(addr), "date ASC")?.use { c ->
                while (c.moveToNext())
                    items.add((if (c.getInt(1) == 1) "← " else "→ ") + (c.getString(0) ?: ""))
            }
        } catch (e: Exception) { }
        val ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
        val lv = ListView(this).apply { adapter = ad; setSelection(items.size - 1) }
        val box = EditText(this).apply { hint = "Message"; if (prefill != null) setText(prefill) }
        val sl = sims()
        var selSim: SubscriptionInfo? = if (sl.size > 1)
            (sl.firstOrNull { it.subscriptionId == SubscriptionManager.getDefaultSmsSubscriptionId() } ?: sl[0]) else null
        val simBtn = Button(this).apply {
            visibility = if (selSim != null) View.VISIBLE else View.GONE
            text = selSim?.let { simLabel(it) } ?: ""
        }
        simBtn.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Send with")
                .setItems(sl.map { simLabel(it) }.toTypedArray()) { _, w ->
                    selSim = sl[w]; simBtn.text = simLabel(sl[w])
                }.show()
        }
        val row = LinearLayout(this)
        row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(btn("Send") {
            val t = box.text.toString()
            if (t.isNotBlank()) try {
                @Suppress("DEPRECATION") val sm = selSim?.let { SmsManager.getSmsManagerForSubscriptionId(it.subscriptionId) } ?: SmsManager.getDefault()
                sm.sendMultipartTextMessage(addr, null, sm.divideMessage(t), null, null)
                try {
                    contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                        put("address", addr); put("body", t); put("date", System.currentTimeMillis()); put("read", 1)
                    })
                } catch (e: Exception) { }
                items.add("→ $t"); ad.notifyDataSetChanged(); box.setText("")
            } catch (e: Exception) { toast("Send failed") }
        })
        val col = vbox()
        col.addView(TextView(this).apply { text = addr; textSize = 18f; setPadding(dp(12), dp(12), dp(12), dp(12)) })
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(simBtn)
        col.addView(row)
        content.removeAllViews(); content.addView(col)
    }

    // ---------- Contacts ----------
    private fun contactsView(): View {
        val col = vbox()
        col.addView(btn("+ Add contact") {
            val n = EditText(this).apply { hint = "Name" }
            val p = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            val b = vbox().apply { setPadding(dp(16), dp(8), dp(16), dp(8)); addView(n); addView(p) }
            AlertDialog.Builder(this).setView(b).setPositiveButton("Save") { _, _ ->
                try { addContact(n.text.toString(), p.text.toString()) } catch (e: Exception) { toast("Failed") }
                go(3)
            }.show()
        })
        val cs = loadContacts()
        col.addView(list(cs.map { it.name + "\n" + it.num }) { i ->
            val c = cs[i]
            val uri = ContactsContract.Contacts.getLookupUri(c.id, c.key)
            AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf("Call", "Edit", "Delete")) { _, w ->
                when (w) {
                    0 -> call(c.num)
                    1 -> startActivity(Intent(Intent.ACTION_EDIT).setDataAndType(uri, ContactsContract.Contacts.CONTENT_ITEM_TYPE))
                    else -> { try { contentResolver.delete(uri, null, null) } catch (e: Exception) { }; go(3) }
                }
            }.show()
        }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    // ---------- More: backup / restore / about ----------
    private fun askRole(dialer: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                val role = if (dialer) RoleManager.ROLE_DIALER else RoleManager.ROLE_SMS
                if (rm.isRoleHeld(role)) { toast("Already default"); return }
                startActivityForResult(rm.createRequestRoleIntent(role), 20)
            } else if (dialer) {
                startActivityForResult(Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName), 20)
            } else {
                startActivityForResult(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName), 21)
            }
        } catch (e: Exception) { toast("Not available: " + e.message) }
    }

    private fun moreView(): View {
        val col = vbox().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        col.addView(btn("Set as default Phone app") { askRole(true) })
        col.addView(btn("Set as default SMS app") { askRole(false) })
        col.addView(btn("Backup (Contacts + SMS → JSON)") {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "simple_phone_backup.json")
            }, 10)
        })
        col.addView(btn("Restore from JSON file") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 11)
        })
        col.addView(TextView(this).apply {
            text = "\nSimple Phone v2.1\n\nCreator: Mohammod Abdul Awal\nStudent: Department of English, National University."
            textSize = 16f
        })
        return col
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 10 && req != 11) return
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        Thread {
            val msg = try { if (req == 10) doBackup(uri) else doRestore(uri) } catch (e: Exception) { "Error: " + e.message }
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun doBackup(uri: Uri): String {
        val cs = JSONArray()
        loadContacts().forEach { cs.put(JSONObject().put("name", it.name).put("number", it.num)) }
        val ms = JSONArray()
        contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body", "date", "type"), null, null, "date ASC")
            ?.use { c ->
                while (c.moveToNext()) ms.put(JSONObject()
                    .put("address", c.getString(0) ?: "").put("body", c.getString(1) ?: "")
                    .put("date", c.getLong(2)).put("type", c.getInt(3)))
            }
        val root = JSONObject().put("contacts", cs).put("sms", ms)
        contentResolver.openOutputStream(uri)?.use { it.write(root.toString().toByteArray()) }
        return "Backup done: ${cs.length()} contacts, ${ms.length()} SMS"
    }

    private fun doRestore(uri: Uri): String {
        val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        val root = JSONObject(txt)
        val have = loadContacts().map { it.name + "|" + it.num }.toHashSet()
        var cc = 0; var sc = 0
        val cs = root.optJSONArray("contacts") ?: JSONArray()
        for (i in 0 until cs.length()) {
            val o = cs.getJSONObject(i)
            if (have.contains(o.getString("name") + "|" + o.getString("number"))) continue
            try { addContact(o.getString("name"), o.getString("number")); cc++ } catch (e: Exception) { }
        }
        val seen = HashSet<String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "date"), null, null, null)?.use {
                while (it.moveToNext()) seen.add(it.getString(0) + "|" + it.getLong(1))
            }
        } catch (e: Exception) { }
        val ms = root.optJSONArray("sms") ?: JSONArray()
        for (i in 0 until ms.length()) {
            val o = ms.getJSONObject(i)
            if (seen.contains(o.optString("address") + "|" + o.optLong("date"))) continue
            try {
                val v = ContentValues().apply {
                    put("address", o.getString("address")); put("body", o.getString("body"))
                    put("date", o.getLong("date")); put("type", o.getInt("type")); put("read", 1)
                }
                if (contentResolver.insert(Uri.parse("content://sms"), v) != null) sc++
            } catch (e: Exception) { }
        }
        return "Restored: $cc contacts, $sc SMS (SMS restore needs default SMS app)"
    }
}
