package com.awal.simplephone

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentProviderOperation
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.telephony.SmsManager
import android.app.role.RoleManager
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class Row(val title: String, val sub: String, val key: String = "", val tag: Any? = null) {
        // মার্ক করার জন্য ইউনিক id: contact হলে তার id, নাহলে number/address
        val sid: String = if (tag is Contact) "c" + tag.id else key
    }
    private class Msg(val id: Long, val out: Boolean, val text: String)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var content: FrameLayout
    private var tab = 0
    private var inThread = false
    private var pending = ""
    private val GREEN = Color.parseColor("#1B8F5A")
    private val DARK = Color.parseColor("#12261C")
    private val GRAY = Color.parseColor("#6B7A72")
    private val RED = Color.parseColor("#D64040")
    private val SEL = Color.parseColor("#D7EDE0")
    private var threadAd: BubbleAdapter? = null
    private val navViews = ArrayList<LinearLayout>()
    private val palette = listOf("#1B8F5A", "#2A7DE1", "#E0703B", "#8E5BD6", "#D64F7A", "#3A9AA8").map { Color.parseColor(it) }

    // ভারী কাজ (DB পড়া) পেছনের thread-এ, UI thread শুধু আঁকে
    private val io = Executors.newFixedThreadPool(3)
    private val ui = Handler(Looper.getMainLooper())
    private var viewGen = 0
    private val observers = ArrayList<ContentObserver>()
    private val df = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())

    @Volatile private var smsCache: List<Row>? = null
    @Volatile private var callsCache: List<Row>? = null
    private var smsAd: RowAdapter? = null
    private var callsAd: RowAdapter? = null
    private var contactsAd: RowAdapter? = null
    private var threadReload: (() -> Unit)? = null
    private val refreshRun = Runnable { refreshNow() }

    private fun wanted(): List<String> {
        val l = mutableListOf(
            Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.setBackgroundColor(Color.parseColor("#F6F8F7"))
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val bar = LinearLayout(this)
        bar.setBackgroundColor(Color.WHITE)
        bar.elevation = dp(8).toFloat()
        val icons = listOf("📞", "🕘", "💬", "👤", "⚙️")
        val names = listOf("Dial", "Calls", "SMS", "Contacts", "More")
        for (i in 0 until 5) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.setPadding(0, dp(8), 0, dp(8))
            item.addView(TextView(this).apply { text = icons[i]; textSize = 20f; gravity = Gravity.CENTER })
            item.addView(TextView(this).apply { text = names[i]; textSize = 11f; gravity = Gravity.CENTER })
            item.isClickable = true
            rip(item, false, 0)
            item.setOnClickListener { go(i) }
            navViews.add(item)
            bar.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        watch(ContactsContract.Contacts.CONTENT_URI) { ContactCache.dirty = true; scheduleRefresh() }
        watch(Uri.parse("content://sms")) { scheduleRefresh() }
        watch(CallLog.Calls.CONTENT_URI) { scheduleRefresh() }
        val missing = wanted().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else go(0)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        val part = Uri.decode(d.schemeSpecificPart ?: "").substringBefore("?").split(";", ",")[0].trim()
        when (d.scheme) {
            "tel" -> { pending = part; go(0) }
            "sms", "smsto", "mms", "mmsto" -> if (part.isNotEmpty()) threadView(part, i.getStringExtra("sms_body"))
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); go(tab)
    }

    override fun onBackPressed() {
        if (inThread) {
            val ta = threadAd
            if (ta != null && ta.selected.isNotEmpty()) ta.clearSel() else go(2)
        } else {
            val a = if (tab == 2) smsAd else if (tab == 3) contactsAd else null
            if (a != null && a.selected.isNotEmpty()) a.clearSel() else super.onBackPressed()
        }
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        observers.forEach { try { contentResolver.unregisterContentObserver(it) } catch (e: Exception) { } }
        observers.clear()
        io.shutdownNow()
        super.onDestroy()
    }

    // ---------- background + live refresh ----------
    private fun <T> async(work: () -> T, done: (T) -> Unit) {
        val g = viewGen
        try {
            io.execute {
                val r = try { work() } catch (e: Throwable) { return@execute }
                runOnUiThread { if (g == viewGen && !isFinishing && !isDestroyed) done(r) }
            }
        } catch (e: Exception) { }
    }

    private fun watch(uri: Uri, f: () -> Unit) {
        val o = object : ContentObserver(ui) {
            override fun onChange(selfChange: Boolean) { f() }
        }
        try { contentResolver.registerContentObserver(uri, true, o); observers.add(o) } catch (e: Exception) { }
    }

    private fun scheduleRefresh() {
        ui.removeCallbacks(refreshRun)
        ui.postDelayed(refreshRun, 350)
    }

    private fun refreshNow() {
        if (inThread) { threadReload?.invoke(); return }
        when (tab) {
            1 -> loadCalls()
            2 -> loadSms()
            3 -> loadContacts()
        }
    }


    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun circle(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    private fun rip(v: View, oval: Boolean, r: Int = 12): View {
        val mask = GradientDrawable()
        mask.setColor(Color.BLACK)
        if (oval) { mask.shape = GradientDrawable.OVAL } else { mask.cornerRadius = dp(r).toFloat() }
        v.foreground = RippleDrawable(ColorStateList.valueOf(0x33000000), null, mask)
        return v
    }

    private fun btn(t: String, filled: Boolean = true, f: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = 15f; v.gravity = Gravity.CENTER; v.typeface = Typeface.DEFAULT_BOLD
        v.setTextColor(if (filled) Color.WHITE else GREEN)
        v.background = bg(if (filled) GREEN else Color.parseColor("#E3F1EA"), 14)
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        v.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(6), dp(16), dp(6)) }
        v.isClickable = true
        rip(v, false, 14)
        v.setOnClickListener { f() }
        return v
    }

    private fun header(t: String) = TextView(this).apply {
        text = t; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(DARK)
        setPadding(dp(20), dp(22), dp(20), dp(10))
    }

    private fun empty(t: String) = TextView(this).apply {
        text = t; textSize = 14f; setTextColor(GRAY); gravity = Gravity.CENTER
        setPadding(dp(20), dp(24), dp(20), dp(8))
    }

    private fun withFab(v: View, icon: String, f: () -> Unit): View {
        val fl = FrameLayout(this)
        fl.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        val fab = TextView(this)
        fab.text = icon; fab.textSize = 30f; fab.gravity = Gravity.CENTER; fab.setTextColor(Color.WHITE)
        fab.background = circle(GREEN); fab.elevation = dp(6).toFloat(); fab.isClickable = true
        rip(fab, true)
        fab.setOnClickListener { f() }
        fl.addView(fab, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, dp(20), dp(20)) })
        return fl
    }

    private fun avatar(title: String, size: Int): TextView {
        val f = title.trim().firstOrNull()
        val a = TextView(this)
        a.text = if (f != null && f.isLetter()) f.uppercase() else "#"
        a.gravity = Gravity.CENTER; a.setTextColor(Color.WHITE); a.textSize = size / 2.6f
        a.typeface = Typeface.DEFAULT_BOLD
        a.background = circle(palette[(title.hashCode() and 0x7fffffff) % palette.size])
        return a
    }

    // ---------- list adapters (view recycle হয়, তাই scroll smooth) ----------
    private inner class RowHolder {
        val root = LinearLayout(this@MainActivity)
        val av = TextView(this@MainActivity)
        val title = TextView(this@MainActivity)
        val sub = TextView(this@MainActivity)
        private val avBg = circle(GREEN)

        init {
            av.gravity = Gravity.CENTER; av.setTextColor(Color.WHITE); av.textSize = 44 / 2.6f
            av.typeface = Typeface.DEFAULT_BOLD; av.background = avBg
            title.textSize = 16f; title.typeface = Typeface.DEFAULT_BOLD; title.setTextColor(DARK)
            title.isSingleLine = true; title.ellipsize = TextUtils.TruncateAt.END
            sub.textSize = 13f; sub.isSingleLine = true; sub.ellipsize = TextUtils.TruncateAt.END
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(dp(16), dp(10), dp(16), dp(10))
            root.addView(av, LinearLayout.LayoutParams(dp(44), dp(44)))
            val c = vbox()
            c.addView(title); c.addView(sub)
            root.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })
            root.tag = this
        }

        fun bind(r: Row, sel: Boolean) {
            root.setBackgroundColor(if (sel) SEL else Color.TRANSPARENT)
            title.text = r.title
            sub.text = r.sub
            sub.visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE
            sub.setTextColor(if (r.sub.startsWith("Missed")) RED else GRAY)
            if (sel) {
                av.text = "✓"
                avBg.setColor(GREEN)
                return
            }
            val f = r.title.trim().firstOrNull()
            av.text = if (f != null && f.isLetter()) f.uppercase() else "#"
            avBg.setColor(palette[(r.title.hashCode() and 0x7fffffff) % palette.size])
        }
    }

    private inner class RowAdapter : BaseAdapter() {
        var data: List<Row> = emptyList()
        var emptyView: View? = null
        val selected = HashSet<String>()
        var onSel: ((Int) -> Unit)? = null

        fun toggle(i: Int) {
            val r = data.getOrNull(i) ?: return
            if (!selected.remove(r.sid)) selected.add(r.sid)
            onSel?.invoke(selected.size)
            notifyDataSetChanged()
        }

        fun clearSel() {
            if (selected.isEmpty()) return
            selected.clear()
            onSel?.invoke(0)
            notifyDataSetChanged()
        }

        fun selectedRows(): List<Row> = data.filter { selected.contains(it.sid) }

        fun set(l: List<Row>) {
            data = l
            if (selected.isNotEmpty() && selected.retainAll(l.map { it.sid }.toHashSet())) onSel?.invoke(selected.size)
            emptyView?.visibility = if (l.isEmpty()) View.VISIBLE else View.GONE
            notifyDataSetChanged()
        }

        override fun getCount() = data.size
        override fun getItem(i: Int): Any = data[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val h = (v?.tag as? RowHolder) ?: RowHolder()
            h.bind(data[i], selected.contains(data[i].sid))
            return h.root
        }
    }

    private inner class BubbleHolder {
        val row = LinearLayout(this@MainActivity)
        val tv = TextView(this@MainActivity)
        private val outBg = bg(GREEN, 18)
        private val inBg = bg(Color.parseColor("#E4EBE7"), 18)

        init {
            tv.textSize = 15f
            tv.setPadding(dp(14), dp(10), dp(14), dp(10))
            tv.maxWidth = dp(280)
            row.setPadding(dp(12), dp(4), dp(12), dp(4))
            row.addView(tv)
            row.tag = this
        }

        fun bind(m: Msg, sel: Boolean) {
            row.setBackgroundColor(if (sel) SEL else Color.TRANSPARENT)
            tv.text = m.text
            tv.setTextColor(if (m.out) Color.WHITE else DARK)
            tv.background = if (m.out) outBg else inBg
            row.gravity = if (m.out) Gravity.END else Gravity.START
        }
    }

    private inner class BubbleAdapter(val data: List<Msg>) : BaseAdapter() {
        val selected = HashSet<Long>()
        var onSel: ((Int) -> Unit)? = null

        fun toggle(i: Int) {
            val m = data.getOrNull(i) ?: return
            if (m.id < 0) return
            if (!selected.remove(m.id)) selected.add(m.id)
            onSel?.invoke(selected.size)
            notifyDataSetChanged()
        }

        fun clearSel() {
            if (selected.isEmpty()) return
            selected.clear()
            onSel?.invoke(0)
            notifyDataSetChanged()
        }

        fun prune() {
            if (selected.isNotEmpty() && selected.retainAll(data.map { it.id }.toHashSet())) onSel?.invoke(selected.size)
        }

        override fun getCount() = data.size
        override fun getItem(i: Int): Any = data[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val h = (v?.tag as? BubbleHolder) ?: BubbleHolder()
            h.bind(data[i], selected.contains(data[i].id))
            return h.row
        }
    }

    private fun fmt(ms: Long): String = synchronized(df) { df.format(Date(ms)) }

    private fun go(i: Int) {
        tab = i; inThread = false; viewGen++
        smsAd = null; callsAd = null; contactsAd = null; threadReload = null; threadAd = null
        navViews.forEachIndexed { k, v ->
            val sel = k == i
            v.getChildAt(0).alpha = if (sel) 1f else 0.45f
            (v.getChildAt(1) as TextView).apply {
                setTextColor(if (sel) GREEN else GRAY)
                typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
        }
        content.removeAllViews()
        content.addView(when (i) {
            0 -> dialView(); 1 -> callsView(); 2 -> smsView(); 3 -> contactsView(); else -> moreView()
        })
    }

    private fun newList(ad: RowAdapter) = ListView(this).apply {
        adapter = ad
        divider = null; dividerHeight = 0
    }

    private fun normalize(s: String) =
        s.trim().map { c -> if (c in '০'..'৯') '0' + (c - '০') else c }.joinToString("").replace(" ", "")

    private fun hasPhoneState() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun sims(): List<SubscriptionInfo> = try {
        if (!hasPhoneState()) emptyList()
        else (getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList ?: emptyList())
            .sortedBy { it.simSlotIndex }
    } catch (e: Exception) { emptyList() }

    private fun simLabel(s: SubscriptionInfo) = "SIM " + (s.simSlotIndex + 1) + ": " + s.displayName

    private fun simAccounts(): List<PhoneAccountHandle> = try {
        if (!hasPhoneState()) emptyList()
        else {
            val tc = getSystemService(TelecomManager::class.java)
            tc.callCapablePhoneAccounts.filter {
                tc.getPhoneAccount(it)?.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true
            }
        }
    } catch (e: Exception) { emptyList() }

    private fun placeCall(n: String, h: PhoneAccountHandle?) {
        val u = Uri.fromParts("tel", n, null)
        val i = Intent(Intent.ACTION_CALL, u)
        if (h != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h)
        try { startActivity(i) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }

    private fun call(raw: String) {
        val n = normalize(raw)
        if (n.isBlank()) return
        if (n.endsWith("#") && (n.startsWith("*") || n.startsWith("#"))) {
            val sl = sims()
            if (sl.size > 1) {
                AlertDialog.Builder(this).setTitle("Select SIM")
                    .setItems(sl.map { simLabel(it) }.toTypedArray()) { _, w -> placeCall(n, handleFor(sl[w].subscriptionId)) }
                    .show()
            } else placeCall(n, null)
            return
        }
        val acc = simAccounts()
        if (acc.size > 1) {
            val tc = getSystemService(TelecomManager::class.java)
            val labels = acc.mapIndexed { i, h -> tc.getPhoneAccount(h)?.label?.toString() ?: ("SIM " + (i + 1)) }
            AlertDialog.Builder(this).setTitle("Call with")
                .setItems(labels.toTypedArray()) { _, w -> placeCall(n, acc[w]) }
                .show()
        } else placeCall(n, null)
    }

    private fun handleFor(subId: Int?): PhoneAccountHandle? {
        val acc = simAccounts()
        if (subId == null || acc.isEmpty()) return null
        val s = sims().firstOrNull { it.subscriptionId == subId } ?: return null
        return acc.firstOrNull { it.id == s.iccId } ?: acc.getOrNull(s.simSlotIndex)
    }

    private fun isDefaultSms() = Telephony.Sms.getDefaultSmsPackage(this) == packageName

    private fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Delete") { _, _ -> ok() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun delThreads(addrs: List<String>, after: () -> Unit) {
        if (!isDefaultSms()) { toast("Set as default SMS app first (More tab)"); return }
        after()
        io.execute {
            var total = 0
            var failed = false
            for (a in addrs) {
                try { total += contentResolver.delete(Uri.parse("content://sms"), "address=?", arrayOf(a)) }
                catch (e: Exception) { failed = true }
            }
            runOnUiThread { toast(if (failed) "Some deletes failed" else "Deleted $total messages"); refreshNow() }
        }
    }

    private fun delContacts(list: List<Contact>, after: () -> Unit) {
        after()
        io.execute {
            var failed = false
            for (c in list) {
                try { contentResolver.delete(ContactsContract.Contacts.getLookupUri(c.id, c.key), null, null) }
                catch (e: Exception) { failed = true }
            }
            ContactCache.dirty = true
            runOnUiThread { if (failed) toast("Some deletes failed"); refreshNow() }
        }
    }

    // ---------- selection bar (লং-প্রেস করলে মার্ক, উপরে Delete bar) ----------
    private class SelBar(val view: View, val count: TextView)

    private fun selBar(onClear: () -> Unit, onDelete: () -> Unit): SelBar {
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#E3F1EA"))
        bar.visibility = View.GONE
        bar.isClickable = true
        val x = TextView(this)
        x.text = "✕"; x.textSize = 22f; x.setTextColor(DARK); x.isClickable = true
        x.setPadding(dp(18), dp(10), dp(18), dp(10))
        x.setOnClickListener { onClear() }
        val cnt = TextView(this)
        cnt.textSize = 18f; cnt.typeface = Typeface.DEFAULT_BOLD; cnt.setTextColor(DARK)
        val del = TextView(this)
        del.text = "🗑 Delete"; del.textSize = 16f; del.typeface = Typeface.DEFAULT_BOLD
        del.setTextColor(RED); del.isClickable = true
        del.setPadding(dp(18), dp(10), dp(18), dp(10))
        del.setOnClickListener { onDelete() }
        bar.addView(x)
        bar.addView(cnt, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(del)
        return SelBar(bar, cnt)
    }

    private fun selHeader(base: View, bar: SelBar, onSel: (((Int) -> Unit)?) -> Unit): View {
        onSel { n ->
            bar.view.visibility = if (n > 0) View.VISIBLE else View.GONE
            bar.count.text = "$n selected"
        }
        val fl = FrameLayout(this)
        fl.addView(base)
        fl.addView(bar.view, FrameLayout.LayoutParams(MATCH, MATCH))
        return fl
    }

    private fun ussd(code: String, subId: Int?) {
        if (Build.VERSION.SDK_INT < 26) { placeCall(code, null); return }
        try {
            val base = getSystemService(TelephonyManager::class.java)
            val tm = if (subId != null) base.createForSubscriptionId(subId) else base
            tm.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(t: TelephonyManager, request: String, response: CharSequence) {
                    val e = EditText(this@MainActivity).apply { hint = "Reply (optional)" }
                    AlertDialog.Builder(this@MainActivity).setTitle(request).setMessage(response).setView(e)
                        .setPositiveButton("Send") { _, _ ->
                            val r = e.text.toString().trim()
                            if (r.isNotEmpty()) ussd(r, subId)
                        }
                        .setNegativeButton("Close", null).show()
                }

                override fun onReceiveUssdResponseFailed(t: TelephonyManager, request: String, failureCode: Int) {
                    AlertDialog.Builder(this@MainActivity).setTitle("USSD failed")
                        .setMessage("Network/SIM did not accept this code (error " + failureCode + ").\nCheck signal, try the other SIM, or tap Try as call.")
                        .setPositiveButton("Try as call") { _, _ -> placeCall(code, handleFor(subId)) }
                        .setNegativeButton("Close", null).show()
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { toast("USSD error: " + e.message) }
    }

    // ---------- Dialer ----------
    private fun dialView(): View {
        val col = vbox().apply { setPadding(dp(12), dp(4), dp(12), dp(4)) }
        val num = TextView(this)
        num.textSize = 30f; num.gravity = Gravity.CENTER; num.setTextColor(DARK)
        num.hint = "Number or name"; num.setHintTextColor(Color.parseColor("#AAB5AF"))
        num.isSingleLine = true; num.ellipsize = TextUtils.TruncateAt.START
        num.typeface = Typeface.DEFAULT_BOLD
        val back = TextView(this)
        back.text = "⌫"; back.textSize = 26f; back.setTextColor(GRAY)
        back.setPadding(dp(14), dp(10), dp(14), dp(10)); back.isClickable = true
        back.setOnClickListener { val t = num.text.toString(); if (t.isNotEmpty()) num.text = t.dropLast(1) }
        back.setOnLongClickListener { num.text = ""; true }
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(View(this), LinearLayout.LayoutParams(dp(54), 1))
        top.addView(num, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(back)
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        val matches = vbox()
        val sv = ScrollView(this)
        sv.addView(matches)
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // contacts পেছনে লোড হয়; লোড শেষ হলে নিজে থেকেই match আপডেট হয়
        var all: List<Contact> = ContactCache.list ?: emptyList()

        fun filter() {
            matches.removeAllViews()
            val d = num.text.toString()
            if (d.isEmpty() || d.startsWith("*") || d.startsWith("#")) return
            val dd = d.filter { it.isDigit() }
            if (dd.isEmpty()) return
            val found = ArrayList<Pair<Int, Contact>>()
            for (c in all) {
                val rank = when {
                    c.t9.startsWith(dd) -> 0
                    c.words.any { it.startsWith(dd) } -> 1
                    c.t9.contains(dd) -> 2
                    c.digits.contains(dd) -> 3
                    else -> 9
                }
                if (rank < 9) found.add(Pair(rank, c))
            }
            if (found.isEmpty()) {
                if (all.isNotEmpty()) matches.addView(empty("No matching contact"))
                return
            }
            found.sortBy { it.first }
            for (k in 0 until minOf(8, found.size)) {
                val c = found[k].second
                val r = LinearLayout(this@MainActivity)
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(10), dp(8), dp(6), dp(8))
                r.background = bg(Color.WHITE, 14)
                r.addView(avatar(c.name, 40), LinearLayout.LayoutParams(dp(40), dp(40)))
                val tc = vbox()
                tc.addView(TextView(this@MainActivity).apply {
                    text = c.name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(DARK); isSingleLine = true
                })
                tc.addView(TextView(this@MainActivity).apply { text = c.num; textSize = 13f; setTextColor(GRAY) })
                r.addView(tc, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
                val cb = TextView(this@MainActivity)
                cb.text = "📞"; cb.textSize = 22f; cb.setPadding(dp(12), dp(6), dp(12), dp(6)); cb.isClickable = true
                cb.setOnClickListener { call(c.num) }
                r.addView(cb)
                r.isClickable = true
                rip(r, false, 14)
                r.setOnClickListener { num.text = c.num }
                matches.addView(r, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(3), 0, dp(3)) })
            }
        }

        num.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filter() }
        })
        if (pending.isNotBlank()) { num.text = pending; pending = "" }
        if (ContactCache.list == null || ContactCache.dirty) {
            async({ ContactCache.load(this) }) { all = it; filter() }
        }

        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        val pad = vbox()
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            for (k in 0 until 3) {
                val (d, l) = keys[r * 3 + k]
                val key = vbox()
                key.gravity = Gravity.CENTER
                key.background = circle(Color.parseColor("#E9F0EC"))
                key.addView(TextView(this).apply { text = d; textSize = 26f; gravity = Gravity.CENTER; setTextColor(DARK) })
                key.addView(TextView(this).apply {
                    text = l; textSize = 9f; gravity = Gravity.CENTER; setTextColor(GRAY)
                    visibility = if (l.isEmpty()) View.GONE else View.VISIBLE
                })
                key.isClickable = true
                rip(key, true)
                key.setOnClickListener { num.append(d) }
                if (d == "0") key.setOnLongClickListener { num.append("+"); true }
                val cell = LinearLayout(this)
                cell.gravity = Gravity.CENTER
                cell.addView(key, LinearLayout.LayoutParams(dp(72), dp(72)))
                row.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(0, dp(4), 0, dp(4)) })
            }
            pad.addView(row)
        }
        col.addView(pad)

        val callBtn = TextView(this)
        callBtn.text = "CALL"; callBtn.textSize = 15f; callBtn.typeface = Typeface.DEFAULT_BOLD
        callBtn.gravity = Gravity.CENTER; callBtn.setTextColor(Color.WHITE)
        callBtn.background = circle(GREEN); callBtn.elevation = dp(4).toFloat(); callBtn.isClickable = true
        rip(callBtn, true)
        callBtn.setOnClickListener { call(num.text.toString()) }
        val cr = LinearLayout(this)
        cr.gravity = Gravity.CENTER
        cr.addView(callBtn, LinearLayout.LayoutParams(dp(68), dp(68)))
        col.addView(cr, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(6), 0, dp(8)) })
        return col
    }

    // ---------- Call log ----------
    private fun callsView(): View {
        val col = vbox()
        col.addView(header("Recent calls"))
        val emptyTv = empty("No calls to show").apply { visibility = View.GONE }
        col.addView(emptyTv)
        val ad = RowAdapter()
        ad.emptyView = emptyTv
        callsAd = ad
        val lv = newList(ad)
        lv.setOnItemClickListener { _, _, i, _ -> ad.data.getOrNull(i)?.let { call(it.key) } }
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        callsCache?.let { ad.set(it) }
        loadCalls()
        return col
    }

    private fun loadCalls() {
        val ad = callsAd ?: return
        async({ queryCalls() }) { ad.set(it) }
    }

    private fun queryCalls(): List<Row> {
        val rows = ArrayList<Row>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && rows.size < 200) {
                    val n = c.getString(0) ?: ""
                    val nm = c.getString(1)
                    val t = when (c.getInt(2)) { 1 -> "Received"; 2 -> "Outgoing"; 3 -> "Missed"; else -> "Other" }
                    rows.add(Row(if (nm.isNullOrBlank()) n else nm, t + " · " + fmt(c.getLong(3)), n))
                }
            }
        } catch (e: Exception) { }
        callsCache = rows
        return rows
    }

    // ---------- SMS ----------
    private fun smsView(): View {
        val col = vbox()
        val ad = RowAdapter()
        val bar = selBar({ ad.clearSel() }) {
            val rows = ad.selectedRows()
            if (rows.isNotEmpty()) confirm("Delete " + rows.size + " conversation(s)?") {
                delThreads(rows.map { it.key }) { ad.clearSel() }
            }
        }
        col.addView(selHeader(header("Messages"), bar) { ad.onSel = it })
        val emptyTv = empty("No messages").apply { visibility = View.GONE }
        col.addView(emptyTv)
        ad.emptyView = emptyTv
        smsAd = ad
        val lv = newList(ad)
        lv.setOnItemClickListener { _, _, i, _ ->
            if (ad.selected.isNotEmpty()) ad.toggle(i) else ad.data.getOrNull(i)?.let { threadView(it.key) }
        }
        lv.setOnItemLongClickListener { _, _, i, _ -> ad.toggle(i); true }
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        smsCache?.let { ad.set(it) }
        loadSms()
        return withFab(col, "+") {
            val e = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            AlertDialog.Builder(this).setTitle("New message").setView(e)
                .setPositiveButton("OK") { _, _ -> if (e.text.isNotBlank()) threadView(e.text.toString().trim()) }
                .show()
        }
    }

    private fun loadSms() {
        val ad = smsAd ?: return
        async({ querySms() }) { ad.set(it) }
    }

    private fun querySms(): List<Row> {
        val seen = LinkedHashMap<String, String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body"), null, null, "date DESC")
                ?.use { c ->
                    while (c.moveToNext()) {
                        val a = c.getString(0) ?: continue
                        if (!seen.containsKey(a)) seen[a] = c.getString(1) ?: ""
                    }
                }
        } catch (e: Exception) { }
        ContactCache.load(this)
        val rows = ArrayList<Row>(seen.size)
        for ((a, b) in seen) {
            rows.add(Row(ContactCache.nameOf(this, a) ?: a, b.take(60).replace('\n', ' '), a))
        }
        smsCache = rows
        return rows
    }

    private fun queryThread(addr: String): ArrayList<Msg> {
        val out = ArrayList<Msg>()
        try {
            // শেষ ৫০০টা মেসেজ; হাজার হাজার মেসেজের thread-ও তাই সাথে সাথে খোলে
            contentResolver.query(Uri.parse("content://sms"), arrayOf("_id", "body", "type"),
                "address=?", arrayOf(addr), "date DESC LIMIT 500")?.use { c ->
                while (c.moveToNext())
                    out.add(Msg(c.getLong(0), c.getInt(2) == 1, c.getString(1) ?: ""))
            }
        } catch (e: Exception) { }
        java.util.Collections.reverse(out)
        return out
    }

    private fun threadView(addr: String, prefill: String? = null) {
        inThread = true; viewGen++
        val msgs = ArrayList<Msg>()
        val ad = BubbleAdapter(msgs)
        val lv = ListView(this).apply {
            adapter = ad; divider = null; dividerHeight = 0
            transcriptMode = ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL
        }
        threadAd = ad
        lv.setOnItemClickListener { _, _, i, _ -> if (ad.selected.isNotEmpty()) ad.toggle(i) }
        lv.setOnItemLongClickListener { _, _, i, _ -> ad.toggle(i); true }
        val bar = selBar({ ad.clearSel() }) {
            val ids = ad.selected.toList()
            if (ids.isNotEmpty()) confirm("Delete " + ids.size + " message(s)?") {
                if (!isDefaultSms()) { toast("Set as default SMS app first (More tab)") }
                else {
                    msgs.removeAll { it.id in ids }
                    ad.clearSel()
                    io.execute {
                        var failed = false
                        for (id in ids) {
                            try { contentResolver.delete(Uri.parse("content://sms/" + id), null, null) }
                            catch (e: Exception) { failed = true }
                        }
                        if (failed) runOnUiThread { toast("Delete failed") }
                    }
                }
            }
        }
        ad.onSel = { n ->
            bar.view.visibility = if (n > 0) View.VISIBLE else View.GONE
            bar.count.text = "$n selected"
        }
        val reload = {
            async({ queryThread(addr) }) { list ->
                if (list.size != msgs.size || list.lastOrNull()?.id != msgs.lastOrNull()?.id) {
                    msgs.clear(); msgs.addAll(list); ad.prune(); ad.notifyDataSetChanged()
                    if (ad.selected.isEmpty()) lv.setSelection(msgs.size - 1)
                }
            }
        }
        threadReload = reload
        reload()

        val box = EditText(this).apply {
            hint = "Message"; if (prefill != null) setText(prefill)
            background = bg(Color.WHITE, 22); setPadding(dp(16), dp(10), dp(16), dp(10)); maxLines = 4
        }
        var simList: List<SubscriptionInfo> = emptyList()
        var selSim: SubscriptionInfo? = null
        val simBtn = TextView(this).apply {
            visibility = View.GONE
            setTextColor(GREEN); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            background = bg(Color.parseColor("#E3F1EA"), 16); setPadding(dp(14), dp(6), dp(14), dp(6)); isClickable = true
        }
        simBtn.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Send with")
                .setItems(simList.map { simLabel(it) }.toTypedArray()) { _, w ->
                    selSim = simList[w]; simBtn.text = simLabel(simList[w])
                }.show()
        }
        async({ sims() }) { sl ->
            if (sl.size > 1) {
                simList = sl
                val s = sl.firstOrNull { it.subscriptionId == SubscriptionManager.getDefaultSmsSubscriptionId() } ?: sl[0]
                selSim = s; simBtn.text = simLabel(s); simBtn.visibility = View.VISIBLE
            }
        }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))
        row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(btn("Send") {
            val t = box.text.toString()
            if (t.isNotBlank()) {
                val m = Msg(-1L, true, t)
                msgs.add(m); ad.notifyDataSetChanged(); box.setText("")
                val sim = selSim
                io.execute {
                    try {
                        @Suppress("DEPRECATION") val sm = sim?.let { SmsManager.getSmsManagerForSubscriptionId(it.subscriptionId) } ?: SmsManager.getDefault()
                        sm.sendMultipartTextMessage(addr, null, sm.divideMessage(t), null, null)
                        try {
                            contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                                put("address", addr); put("body", t); put("date", System.currentTimeMillis()); put("read", 1)
                            })
                        } catch (e: Exception) { }
                    } catch (e: Exception) {
                        runOnUiThread { msgs.remove(m); ad.notifyDataSetChanged(); box.setText(t); toast("Send failed") }
                    }
                }
            }
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(6), 0, dp(2), 0) })
        val col = vbox()
        val hd = LinearLayout(this)
        hd.gravity = Gravity.CENTER_VERTICAL
        hd.setBackgroundColor(Color.WHITE)
        hd.setPadding(dp(8), dp(12), dp(16), dp(12))
        hd.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; setTextColor(GREEN); setPadding(dp(12), 0, dp(18), 0)
            isClickable = true; setOnClickListener { go(2) }
        })
        val nameTv = TextView(this).apply {
            text = ContactCache.peek(addr) ?: addr
            textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(DARK); isSingleLine = true
        }
        hd.addView(nameTv)
        async({ Util.name(this, addr) }) { n -> if (n != null) nameTv.text = n }
        val hdFrame = FrameLayout(this)
        hdFrame.addView(hd)
        hdFrame.addView(bar.view, FrameLayout.LayoutParams(MATCH, MATCH))
        col.addView(hdFrame)
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(simBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(12), dp(4), 0, 0) })
        col.addView(row)
        content.removeAllViews(); content.addView(col)
    }

    // ---------- Contacts ----------
    private fun addContact(name: String, num: String) {
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
            .withValue(StructuredName.DISPLAY_NAME, name).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
            .withValue(Phone.NUMBER, num)
            .withValue(Phone.TYPE, Phone.TYPE_MOBILE).build())
        contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
        ContactCache.dirty = true
    }

    private fun contactRows(l: List<Contact>): List<Row> = l.map { Row(it.name, it.num, "", it) }

    private fun contactsView(): View {
        val col = vbox()
        val ad = RowAdapter()
        val bar = selBar({ ad.clearSel() }) {
            val cs = ad.selectedRows().mapNotNull { it.tag as? Contact }.distinctBy { it.id }
            if (cs.isNotEmpty()) confirm("Delete " + cs.size + " contact(s)?") {
                delContacts(cs) { ad.clearSel() }
            }
        }
        col.addView(selHeader(header("Contacts"), bar) { ad.onSel = it })
        val emptyTv = empty("No contacts").apply { visibility = View.GONE }
        col.addView(emptyTv)
        ad.emptyView = emptyTv
        contactsAd = ad
        val lv = newList(ad)
        lv.isFastScrollEnabled = true
        lv.setOnItemClickListener { _, _, i, _ ->
            if (ad.selected.isNotEmpty()) ad.toggle(i)
            else (ad.data.getOrNull(i)?.tag as? Contact)?.let { contactMenu(it) }
        }
        lv.setOnItemLongClickListener { _, _, i, _ -> ad.toggle(i); true }
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        ContactCache.list?.let { ad.set(contactRows(it)) }
        loadContacts()
        return withFab(col, "+") {
            val n = EditText(this).apply { hint = "Name" }
            val p = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            val b = vbox().apply { setPadding(dp(16), dp(8), dp(16), dp(8)); addView(n); addView(p) }
            AlertDialog.Builder(this).setTitle("New contact").setView(b).setPositiveButton("Save") { _, _ ->
                val nm = n.text.toString(); val ph = p.text.toString()
                io.execute {
                    try { addContact(nm, ph); runOnUiThread { refreshNow() } }
                    catch (e: Exception) { runOnUiThread { toast("Failed") } }
                }
            }.show()
        }
    }

    private fun loadContacts() {
        val ad = contactsAd ?: return
        if (ContactCache.list != null && !ContactCache.dirty) return
        async({ contactRows(ContactCache.load(this)) }) { ad.set(it) }
    }

    private fun contactMenu(c: Contact) {
        val uri = ContactsContract.Contacts.getLookupUri(c.id, c.key)
        AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf("Call", "Edit", "Delete")) { _, w ->
            when (w) {
                0 -> call(c.num)
                1 -> startActivity(Intent(Intent.ACTION_EDIT).setDataAndType(uri, ContactsContract.Contacts.CONTENT_ITEM_TYPE))
                else -> io.execute {
                    try { contentResolver.delete(uri, null, null) } catch (e: Exception) { }
                    ContactCache.dirty = true
                    runOnUiThread { refreshNow() }
                }
            }
        }.show()
    }

    // ---------- More: backup / restore / about ----------
    private fun askRole(dialer: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                val role = if (dialer) RoleManager.ROLE_DIALER else RoleManager.ROLE_SMS
                if (rm.isRoleHeld(role)) { toast("Already default"); return }
                startActivityForResult(rm.createRequestRoleIntent(role), 20)
            } else if (dialer) {
                startActivityForResult(Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName), 20)
            } else {
                startActivityForResult(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName), 21)
            }
        } catch (e: Exception) { toast("Not available: " + e.message) }
    }

    private fun moreView(): View {
        val col = vbox()
        col.addView(header("Settings"))
        col.addView(btn("Set as default Phone app") { askRole(true) })
        col.addView(btn("Set as default SMS app") { askRole(false) })
        col.addView(btn("Backup contacts + SMS to file", false) {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "simple_phone_backup.json")
            }, 10)
        })
        col.addView(btn("Restore from backup file", false) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 11)
        })
        val card = vbox()
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.background = bg(Color.WHITE, 18)
        card.setPadding(dp(20), dp(20), dp(20), dp(20))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        card.addView(logo, LinearLayout.LayoutParams(dp(64), dp(64)))
        card.addView(TextView(this).apply {
            text = "Simple Phone v2.5"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(DARK); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(6))
        })
        card.addView(TextView(this).apply {
            text = "Creator: Mohammod Abdul Awal\nStudent: Department of English, National University."
            textSize = 14f; setTextColor(GRAY); gravity = Gravity.CENTER
        })
        col.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(16), dp(16), dp(16)) })
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 10 && req != 11) return
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        Thread {
            val msg = try { if (req == 10) doBackup(uri) else doRestore(uri) } catch (e: Exception) { "Error: " + e.message }
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun doBackup(uri: Uri): String {
        val cs = JSONArray()
        ContactCache.load(this, true).forEach { cs.put(JSONObject().put("name", it.name).put("number", it.num)) }
        val ms = JSONArray()
        contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body", "date", "type"), null, null, "date ASC")
            ?.use { c ->
                while (c.moveToNext()) ms.put(JSONObject()
                    .put("address", c.getString(0) ?: "").put("body", c.getString(1) ?: "")
                    .put("date", c.getLong(2)).put("type", c.getInt(3)))
            }
        val root = JSONObject().put("contacts", cs).put("sms", ms)
        contentResolver.openOutputStream(uri)?.use { it.write(root.toString().toByteArray()) }
        return "Backup done: ${cs.length()} contacts, ${ms.length()} SMS"
    }

    private fun doRestore(uri: Uri): String {
        val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        val root = JSONObject(txt)
        val have = ContactCache.load(this, true).map { it.name + "|" + it.num }.toHashSet()
        var cc = 0; var sc = 0
        val cs = root.optJSONArray("contacts") ?: JSONArray()
        for (i in 0 until cs.length()) {
            val o = cs.getJSONObject(i)
            if (have.contains(o.getString("name") + "|" + o.getString("number"))) continue
            try { addContact(o.getString("name"), o.getString("number")); cc++ } catch (e: Exception) { }
        }
        val seen = HashSet<String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "date"), null, null, null)?.use {
                while (it.moveToNext()) seen.add(it.getString(0) + "|" + it.getLong(1))
            }
        } catch (e: Exception) { }
        val ms = root.optJSONArray("sms") ?: JSONArray()
        for (i in 0 until ms.length()) {
            val o = ms.getJSONObject(i)
            if (seen.contains(o.optString("address") + "|" + o.optLong("date"))) continue
            try {
                val v = ContentValues().apply {
                    put("address", o.getString("address")); put("body", o.getString("body"))
                    put("date", o.getLong("date")); put("type", o.getInt("type")); put("read", 1)
                }
                if (contentResolver.insert(Uri.parse("content://sms"), v) != null) sc++
            } catch (e: Exception) { }
        }
        ContactCache.dirty = true
        return "Restored: $cc contacts, $sc SMS (SMS restore needs default SMS app)"
    }
}
