package com.awal.simplephone

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentProviderOperation
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.telecom.PhoneAccount
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.telephony.SmsManager
import android.app.role.RoleManager
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    data class C(val id: Long, val key: String, val name: String, val num: String)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var content: FrameLayout
    private var tab = 0
    private var inThread = false
    private var pending = ""
    private val GREEN = Color.parseColor("#1B8F5A")
    private val DARK = Color.parseColor("#12261C")
    private val GRAY = Color.parseColor("#6B7A72")
    private val navViews = ArrayList<LinearLayout>()
    private val palette = listOf("#1B8F5A", "#2A7DE1", "#E0703B", "#8E5BD6", "#D64F7A", "#3A9AA8").map { Color.parseColor(it) }

    private fun wanted(): List<String> {
        val l = mutableListOf(
            Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.setBackgroundColor(Color.parseColor("#F6F8F7"))
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        val bar = LinearLayout(this)
        bar.setBackgroundColor(Color.WHITE)
        bar.elevation = dp(8).toFloat()
        val icons = listOf("📞", "🕘", "💬", "👤", "⚙️")
        val names = listOf("Dial", "Calls", "SMS", "Contacts", "More")
        for (i in 0 until 5) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.setPadding(0, dp(8), 0, dp(8))
            item.addView(TextView(this).apply { text = icons[i]; textSize = 20f; gravity = Gravity.CENTER })
            item.addView(TextView(this).apply { text = names[i]; textSize = 11f; gravity = Gravity.CENTER })
            item.isClickable = true
            rip(item, false, 0)
            item.setOnClickListener { go(i) }
            navViews.add(item)
            bar.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        root.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
        val missing = wanted().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else go(0)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        val d = i?.data ?: return
        val part = Uri.decode(d.schemeSpecificPart ?: "").substringBefore("?").split(";", ",")[0].trim()
        when (d.scheme) {
            "tel" -> { pending = part; go(0) }
            "sms", "smsto", "mms", "mmsto" -> if (part.isNotEmpty()) threadView(part, i.getStringExtra("sms_body"))
        }
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r); go(tab)
    }

    override fun onBackPressed() {
        if (inThread) go(2) else super.onBackPressed()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun vbox() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun bg(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun circle(color: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

    private fun rip(v: View, oval: Boolean, r: Int = 12): View {
        val mask = GradientDrawable()
        mask.setColor(Color.BLACK)
        if (oval) { mask.shape = GradientDrawable.OVAL } else { mask.cornerRadius = dp(r).toFloat() }
        v.foreground = RippleDrawable(ColorStateList.valueOf(0x33000000), null, mask)
        return v
    }

    private fun btn(t: String, filled: Boolean = true, f: () -> Unit): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = 15f; v.gravity = Gravity.CENTER; v.typeface = Typeface.DEFAULT_BOLD
        v.setTextColor(if (filled) Color.WHITE else GREEN)
        v.background = bg(if (filled) GREEN else Color.parseColor("#E3F1EA"), 14)
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        v.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(6), dp(16), dp(6)) }
        v.isClickable = true
        rip(v, false, 14)
        v.setOnClickListener { f() }
        return v
    }

    private fun header(t: String) = TextView(this).apply {
        text = t; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(DARK)
        setPadding(dp(20), dp(22), dp(20), dp(10))
    }

    private fun empty(t: String) = TextView(this).apply {
        text = t; textSize = 14f; setTextColor(GRAY); gravity = Gravity.CENTER
        setPadding(dp(20), dp(24), dp(20), dp(8))
    }

    private fun withFab(v: View, icon: String, f: () -> Unit): View {
        val fl = FrameLayout(this)
        fl.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        val fab = TextView(this)
        fab.text = icon; fab.textSize = 30f; fab.gravity = Gravity.CENTER; fab.setTextColor(Color.WHITE)
        fab.background = circle(GREEN); fab.elevation = dp(6).toFloat(); fab.isClickable = true
        rip(fab, true)
        fab.setOnClickListener { f() }
        fl.addView(fab, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, dp(20), dp(20)) })
        return fl
    }

    private fun avatar(title: String, size: Int): TextView {
        val f = title.trim().firstOrNull()
        val a = TextView(this)
        a.text = if (f != null && f.isLetter()) f.uppercase() else "#"
        a.gravity = Gravity.CENTER; a.setTextColor(Color.WHITE); a.textSize = size / 2.6f
        a.typeface = Typeface.DEFAULT_BOLD
        a.background = circle(palette[(title.hashCode() and 0x7fffffff) % palette.size])
        return a
    }

    private inner class RowAdapter(val data: List<String>) : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(i: Int): Any = data[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val parts = data[i].split("\n", limit = 2)
            val title = parts[0]
            val sub = if (parts.size > 1) parts[1] else ""
            val h = LinearLayout(this@MainActivity)
            h.gravity = Gravity.CENTER_VERTICAL
            h.setPadding(dp(16), dp(10), dp(16), dp(10))
            h.addView(avatar(title, 44), LinearLayout.LayoutParams(dp(44), dp(44)))
            val c = LinearLayout(this@MainActivity)
            c.orientation = LinearLayout.VERTICAL
            c.addView(TextView(this@MainActivity).apply {
                text = title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(DARK); isSingleLine = true
            })
            if (sub.isNotEmpty()) c.addView(TextView(this@MainActivity).apply {
                text = sub; textSize = 13f; isSingleLine = true
                setTextColor(if (sub.startsWith("Missed")) Color.parseColor("#D64040") else GRAY)
            })
            h.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(14) })
            return h
        }
    }

    private inner class BubbleAdapter(val data: List<String>) : BaseAdapter() {
        override fun getCount() = data.size
        override fun getItem(i: Int): Any = data[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val t = data[i]
            val out = t.startsWith("→")
            val tv = TextView(this@MainActivity)
            tv.text = t.substring(2); tv.textSize = 15f
            tv.setPadding(dp(14), dp(10), dp(14), dp(10))
            tv.setTextColor(if (out) Color.WHITE else DARK)
            tv.background = bg(if (out) GREEN else Color.parseColor("#E4EBE7"), 18)
            tv.maxWidth = dp(280)
            val row = LinearLayout(this@MainActivity)
            row.gravity = if (out) Gravity.END else Gravity.START
            row.setPadding(dp(12), dp(4), dp(12), dp(4))
            row.addView(tv)
            return row
        }
    }
    private fun fmt(ms: Long) = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(ms))

    private fun go(i: Int) {
        tab = i; inThread = false
        navViews.forEachIndexed { k, v ->
            val sel = k == i
            v.getChildAt(0).alpha = if (sel) 1f else 0.45f
            (v.getChildAt(1) as TextView).apply {
                setTextColor(if (sel) GREEN else GRAY)
                typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
        }
        content.removeAllViews()
        content.addView(when (i) {
            0 -> dialView(); 1 -> callsView(); 2 -> smsView(); 3 -> contactsView(); else -> moreView()
        })
    }

    private fun list(items: List<String>, onClick: (Int) -> Unit) = ListView(this).apply {
        adapter = RowAdapter(items)
        divider = null; dividerHeight = 0
        setOnItemClickListener { _, _, i, _ -> onClick(i) }
    }

    private fun normalize(s: String) =
        s.trim().map { c -> if (c in '০'..'৯') '0' + (c - '০') else c }.joinToString("").replace(" ", "")

    private fun hasPhoneState() =
        checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun sims(): List<SubscriptionInfo> = try {
        if (!hasPhoneState()) emptyList()
        else (getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList ?: emptyList())
            .sortedBy { it.simSlotIndex }
    } catch (e: Exception) { emptyList() }

    private fun simLabel(s: SubscriptionInfo) = "SIM " + (s.simSlotIndex + 1) + ": " + s.displayName

    private fun simAccounts(): List<PhoneAccountHandle> = try {
        if (!hasPhoneState()) emptyList()
        else {
            val tc = getSystemService(TelecomManager::class.java)
            tc.callCapablePhoneAccounts.filter {
                tc.getPhoneAccount(it)?.hasCapabilities(PhoneAccount.CAPABILITY_SIM_SUBSCRIPTION) == true
            }
        }
    } catch (e: Exception) { emptyList() }

    private fun placeCall(n: String, h: PhoneAccountHandle?) {
        val u = Uri.fromParts("tel", n, null)
        val i = Intent(Intent.ACTION_CALL, u)
        if (h != null) i.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h)
        try { startActivity(i) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_DIAL, u)) }
    }

    private fun call(raw: String) {
        val n = normalize(raw)
        if (n.isBlank()) return
        if (n.endsWith("#") && (n.startsWith("*") || n.startsWith("#"))) {
            val sl = sims()
            if (sl.size > 1) {
                AlertDialog.Builder(this).setTitle("Select SIM")
                    .setItems(sl.map { simLabel(it) }.toTypedArray()) { _, w -> placeCall(n, handleFor(sl[w].subscriptionId)) }
                    .show()
            } else placeCall(n, null)
            return
        }
        val acc = simAccounts()
        if (acc.size > 1) {
            val tc = getSystemService(TelecomManager::class.java)
            val labels = acc.mapIndexed { i, h -> tc.getPhoneAccount(h)?.label?.toString() ?: ("SIM " + (i + 1)) }
            AlertDialog.Builder(this).setTitle("Call with")
                .setItems(labels.toTypedArray()) { _, w -> placeCall(n, acc[w]) }
                .show()
        } else placeCall(n, null)
    }

    private fun handleFor(subId: Int?): PhoneAccountHandle? {
        val acc = simAccounts()
        if (subId == null || acc.isEmpty()) return null
        val s = sims().firstOrNull { it.subscriptionId == subId } ?: return null
        return acc.firstOrNull { it.id == s.iccId } ?: acc.getOrNull(s.simSlotIndex)
    }

    private fun isDefaultSms() = Telephony.Sms.getDefaultSmsPackage(this) == packageName

    private fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("Delete") { _, _ -> ok() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun delThread(addr: String) {
        if (!isDefaultSms()) { toast("Set as default SMS app first (More tab)"); return }
        try {
            val n = contentResolver.delete(Uri.parse("content://sms"), "address=?", arrayOf(addr))
            toast("Deleted $n messages")
        } catch (e: Exception) { toast("Delete failed") }
        go(2)
    }

    private fun ussd(code: String, subId: Int?) {
        if (Build.VERSION.SDK_INT < 26) { placeCall(code, null); return }
        try {
            val base = getSystemService(TelephonyManager::class.java)
            val tm = if (subId != null) base.createForSubscriptionId(subId) else base
            tm.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(t: TelephonyManager, request: String, response: CharSequence) {
                    val e = EditText(this@MainActivity).apply { hint = "Reply (optional)" }
                    AlertDialog.Builder(this@MainActivity).setTitle(request).setMessage(response).setView(e)
                        .setPositiveButton("Send") { _, _ ->
                            val r = e.text.toString().trim()
                            if (r.isNotEmpty()) ussd(r, subId)
                        }
                        .setNegativeButton("Close", null).show()
                }

                override fun onReceiveUssdResponseFailed(t: TelephonyManager, request: String, failureCode: Int) {
                    AlertDialog.Builder(this@MainActivity).setTitle("USSD failed")
                        .setMessage("Network/SIM did not accept this code (error " + failureCode + ").\nCheck signal, try the other SIM, or tap Try as call.")
                        .setPositiveButton("Try as call") { _, _ -> placeCall(code, handleFor(subId)) }
                        .setNegativeButton("Close", null).show()
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { toast("USSD error: " + e.message) }
    }

    private fun t9(s: String) = s.lowercase().map {
        when (it) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> it; else -> ' '
        }
    }.joinToString("")

    // ---------- data ----------
    private fun loadContacts(): List<C> {
        val out = ArrayList<C>()
        try {
            contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                while (c.moveToNext())
                    out.add(C(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: ""))
            }
        } catch (e: Exception) { }
        return out
    }

    private fun addContact(name: String, num: String) {
        val ops = ArrayList<ContentProviderOperation>()
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
            .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
            .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE)
            .withValue(StructuredName.DISPLAY_NAME, name).build())
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, Phone.CONTENT_ITEM_TYPE)
            .withValue(Phone.NUMBER, num)
            .withValue(Phone.TYPE, Phone.TYPE_MOBILE).build())
        contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
    }

    // ---------- Dialer ----------
    private fun dialView(): View {
        val col = vbox().apply { setPadding(dp(12), dp(4), dp(12), dp(4)) }
        val num = TextView(this)
        num.textSize = 30f; num.gravity = Gravity.CENTER; num.setTextColor(DARK)
        num.hint = "Number or name"; num.setHintTextColor(Color.parseColor("#AAB5AF"))
        num.isSingleLine = true; num.ellipsize = TextUtils.TruncateAt.START
        num.typeface = Typeface.DEFAULT_BOLD
        val back = TextView(this)
        back.text = "⌫"; back.textSize = 26f; back.setTextColor(GRAY)
        back.setPadding(dp(14), dp(10), dp(14), dp(10)); back.isClickable = true
        back.setOnClickListener { val t = num.text.toString(); if (t.isNotEmpty()) num.text = t.dropLast(1) }
        back.setOnLongClickListener { num.text = ""; true }
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(View(this), LinearLayout.LayoutParams(dp(54), 1))
        top.addView(num, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(back)
        col.addView(top, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        val matches = vbox()
        val sv = ScrollView(this)
        sv.addView(matches)
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val all = loadContacts()

        num.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                matches.removeAllViews()
                val d = s.toString()
                if (d.isEmpty() || d.startsWith("*") || d.startsWith("#")) return
                val dd = d.filter { it.isDigit() }
                if (dd.isEmpty()) return
                val found = all.mapNotNull { c ->
                    val tn = t9(c.name)
                    val words = tn.split(" ").filter { it.isNotEmpty() }
                    val digits = c.num.filter { ch -> ch.isDigit() }
                    val rank = when {
                        tn.startsWith(dd) -> 0
                        words.any { it.startsWith(dd) } -> 1
                        tn.contains(dd) -> 2
                        digits.contains(dd) -> 3
                        else -> 9
                    }
                    if (rank < 9) Pair(rank, c) else null
                }.sortedBy { it.first }.take(8)
                if (found.isEmpty()) {
                    matches.addView(empty("No matching contact"))
                    return
                }
                found.forEach { (_, c) ->
                    val r = LinearLayout(this@MainActivity)
                    r.gravity = Gravity.CENTER_VERTICAL
                    r.setPadding(dp(10), dp(8), dp(6), dp(8))
                    r.background = bg(Color.WHITE, 14)
                    r.addView(avatar(c.name, 40), LinearLayout.LayoutParams(dp(40), dp(40)))
                    val tc = vbox()
                    tc.addView(TextView(this@MainActivity).apply {
                        text = c.name; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(DARK); isSingleLine = true
                    })
                    tc.addView(TextView(this@MainActivity).apply { text = c.num; textSize = 13f; setTextColor(GRAY) })
                    r.addView(tc, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(12) })
                    val cb = TextView(this@MainActivity)
                    cb.text = "📞"; cb.textSize = 22f; cb.setPadding(dp(12), dp(6), dp(12), dp(6)); cb.isClickable = true
                    cb.setOnClickListener { call(c.num) }
                    r.addView(cb)
                    r.isClickable = true
                    rip(r, false, 14)
                    r.setOnClickListener { num.text = c.num }
                    matches.addView(r, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(3), 0, dp(3)) })
                }
            }
        })
        if (pending.isNotBlank()) { num.text = pending; pending = "" }

        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        val pad = vbox()
        for (r in 0 until 4) {
            val row = LinearLayout(this)
            for (k in 0 until 3) {
                val (d, l) = keys[r * 3 + k]
                val key = vbox()
                key.gravity = Gravity.CENTER
                key.background = circle(Color.parseColor("#E9F0EC"))
                key.addView(TextView(this).apply { text = d; textSize = 26f; gravity = Gravity.CENTER; setTextColor(DARK) })
                key.addView(TextView(this).apply {
                    text = l; textSize = 9f; gravity = Gravity.CENTER; setTextColor(GRAY)
                    visibility = if (l.isEmpty()) View.GONE else View.VISIBLE
                })
                key.isClickable = true
                rip(key, true)
                key.setOnClickListener { num.append(d) }
                if (d == "0") key.setOnLongClickListener { num.append("+"); true }
                val cell = LinearLayout(this)
                cell.gravity = Gravity.CENTER
                cell.addView(key, LinearLayout.LayoutParams(dp(72), dp(72)))
                row.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(0, dp(4), 0, dp(4)) })
            }
            pad.addView(row)
        }
        col.addView(pad)

        val callBtn = TextView(this)
        callBtn.text = "CALL"; callBtn.textSize = 15f; callBtn.typeface = Typeface.DEFAULT_BOLD
        callBtn.gravity = Gravity.CENTER; callBtn.setTextColor(Color.WHITE)
        callBtn.background = circle(GREEN); callBtn.elevation = dp(4).toFloat(); callBtn.isClickable = true
        rip(callBtn, true)
        callBtn.setOnClickListener { call(num.text.toString()) }
        val cr = LinearLayout(this)
        cr.gravity = Gravity.CENTER
        cr.addView(callBtn, LinearLayout.LayoutParams(dp(68), dp(68)))
        col.addView(cr, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(0, dp(6), 0, dp(8)) })
        return col
    }

    // ---------- Call log ----------
    private fun callsView(): View {
        val rows = ArrayList<String>(); val nums = ArrayList<String>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                while (c.moveToNext() && rows.size < 200) {
                    val n = c.getString(0) ?: ""
                    val nm = c.getString(1)
                    val t = when (c.getInt(2)) { 1 -> "Received"; 2 -> "Outgoing"; 3 -> "Missed"; else -> "Other" }
                    rows.add((if (nm.isNullOrBlank()) n else nm) + "\n" + t + " · " + fmt(c.getLong(3)))
                    nums.add(n)
                }
            }
        } catch (e: Exception) { }
        val col = vbox()
        col.addView(header("Recent calls"))
        if (rows.isEmpty()) col.addView(empty("No calls to show"))
        col.addView(list(rows) { call(nums[it]) }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    // ---------- SMS ----------
    private fun smsView(): View {
        val col = vbox()
        col.addView(header("Messages"))
        val seen = LinkedHashMap<String, String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body"), null, null, "date DESC")
                ?.use { c ->
                    while (c.moveToNext()) {
                        val a = c.getString(0) ?: continue
                        if (!seen.containsKey(a)) seen[a] = c.getString(1) ?: ""
                    }
                }
        } catch (e: Exception) { }
        val keys = seen.keys.toList()
        if (keys.isEmpty()) col.addView(empty("No messages"))
        val lvc = list(keys.map { (Util.name(this, it) ?: it) + "\n" + seen[it]!!.take(60) }) { threadView(keys[it]) }
        lvc.setOnItemLongClickListener { _, _, i, _ ->
            confirm("Delete whole conversation with " + keys[i] + "?") { delThread(keys[i]) }
            true
        }
        col.addView(lvc, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return withFab(col, "+") {
            val e = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            AlertDialog.Builder(this).setTitle("New message").setView(e)
                .setPositiveButton("OK") { _, _ -> if (e.text.isNotBlank()) threadView(e.text.toString().trim()) }
                .show()
        }
    }

    private fun threadView(addr: String, prefill: String? = null) {
        inThread = true
        val items = ArrayList<String>()
        val ids = ArrayList<Long>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("_id", "body", "type"),
                "address=?", arrayOf(addr), "date ASC")?.use { c ->
                while (c.moveToNext()) {
                    ids.add(c.getLong(0))
                    items.add((if (c.getInt(2) == 1) "← " else "→ ") + (c.getString(1) ?: ""))
                }
            }
        } catch (e: Exception) { }
        val ad = BubbleAdapter(items)
        val lv = ListView(this).apply {
            adapter = ad; divider = null; dividerHeight = 0
            transcriptMode = ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL
            setSelection(items.size - 1)
        }
        lv.setOnItemLongClickListener { _, _, i, _ ->
            confirm("Delete this message?") {
                if (!isDefaultSms()) { toast("Set as default SMS app first (More tab)") }
                else {
                    try {
                        if (ids[i] >= 0) contentResolver.delete(Uri.parse("content://sms/" + ids[i]), null, null)
                        items.removeAt(i); ids.removeAt(i); ad.notifyDataSetChanged()
                    } catch (e: Exception) { toast("Delete failed") }
                }
            }
            true
        }
        val box = EditText(this).apply {
            hint = "Message"; if (prefill != null) setText(prefill)
            background = bg(Color.WHITE, 22); setPadding(dp(16), dp(10), dp(16), dp(10)); maxLines = 4
        }
        val sl = sims()
        var selSim: SubscriptionInfo? = if (sl.size > 1)
            (sl.firstOrNull { it.subscriptionId == SubscriptionManager.getDefaultSmsSubscriptionId() } ?: sl[0]) else null
        val simBtn = TextView(this).apply {
            visibility = if (selSim != null) View.VISIBLE else View.GONE
            text = selSim?.let { simLabel(it) } ?: ""
            setTextColor(GREEN); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            background = bg(Color.parseColor("#E3F1EA"), 16); setPadding(dp(14), dp(6), dp(14), dp(6)); isClickable = true
        }
        simBtn.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Send with")
                .setItems(sl.map { simLabel(it) }.toTypedArray()) { _, w ->
                    selSim = sl[w]; simBtn.text = simLabel(sl[w])
                }.show()
        }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))
        row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(btn("Send") {
            val t = box.text.toString()
            if (t.isNotBlank()) try {
                @Suppress("DEPRECATION") val sm = selSim?.let { SmsManager.getSmsManagerForSubscriptionId(it.subscriptionId) } ?: SmsManager.getDefault()
                sm.sendMultipartTextMessage(addr, null, sm.divideMessage(t), null, null)
                try {
                    contentResolver.insert(Telephony.Sms.Sent.CONTENT_URI, ContentValues().apply {
                        put("address", addr); put("body", t); put("date", System.currentTimeMillis()); put("read", 1)
                    })
                } catch (e: Exception) { }
                items.add("→ $t"); ids.add(-1L); ad.notifyDataSetChanged(); box.setText("")
            } catch (e: Exception) { toast("Send failed") }
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(6), 0, dp(2), 0) })
        val col = vbox()
        val hd = LinearLayout(this)
        hd.gravity = Gravity.CENTER_VERTICAL
        hd.setBackgroundColor(Color.WHITE)
        hd.setPadding(dp(8), dp(12), dp(16), dp(12))
        hd.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; setTextColor(GREEN); setPadding(dp(12), 0, dp(18), 0)
            isClickable = true; setOnClickListener { go(2) }
        })
        hd.addView(TextView(this).apply {
            text = Util.name(this@MainActivity, addr) ?: addr
            textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(DARK); isSingleLine = true
        })
        col.addView(hd)
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        col.addView(simBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(12), dp(4), 0, 0) })
        col.addView(row)
        content.removeAllViews(); content.addView(col)
    }

    // ---------- Contacts ----------
    private fun contactsView(): View {
        val col = vbox()
        col.addView(header("Contacts"))
        val cs = loadContacts()
        if (cs.isEmpty()) col.addView(empty("No contacts"))
        col.addView(list(cs.map { it.name + "\n" + it.num }) { i ->
            val c = cs[i]
            val uri = ContactsContract.Contacts.getLookupUri(c.id, c.key)
            AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf("Call", "Edit", "Delete")) { _, w ->
                when (w) {
                    0 -> call(c.num)
                    1 -> startActivity(Intent(Intent.ACTION_EDIT).setDataAndType(uri, ContactsContract.Contacts.CONTENT_ITEM_TYPE))
                    else -> { try { contentResolver.delete(uri, null, null) } catch (e: Exception) { }; go(3) }
                }
            }.show()
        }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return withFab(col, "+") {
            val n = EditText(this).apply { hint = "Name" }
            val p = EditText(this).apply { hint = "Number"; inputType = InputType.TYPE_CLASS_PHONE }
            val b = vbox().apply { setPadding(dp(16), dp(8), dp(16), dp(8)); addView(n); addView(p) }
            AlertDialog.Builder(this).setTitle("New contact").setView(b).setPositiveButton("Save") { _, _ ->
                try { addContact(n.text.toString(), p.text.toString()) } catch (e: Exception) { toast("Failed") }
                go(3)
            }.show()
        }
    }

    // ---------- More: backup / restore / about ----------
    private fun askRole(dialer: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                val role = if (dialer) RoleManager.ROLE_DIALER else RoleManager.ROLE_SMS
                if (rm.isRoleHeld(role)) { toast("Already default"); return }
                startActivityForResult(rm.createRequestRoleIntent(role), 20)
            } else if (dialer) {
                startActivityForResult(Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName), 20)
            } else {
                startActivityForResult(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName), 21)
            }
        } catch (e: Exception) { toast("Not available: " + e.message) }
    }

    private fun moreView(): View {
        val col = vbox()
        col.addView(header("Settings"))
        col.addView(btn("Set as default Phone app") { askRole(true) })
        col.addView(btn("Set as default SMS app") { askRole(false) })
        col.addView(btn("Backup contacts + SMS to file", false) {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "simple_phone_backup.json")
            }, 10)
        })
        col.addView(btn("Restore from backup file", false) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 11)
        })
        val card = vbox()
        card.gravity = Gravity.CENTER_HORIZONTAL
        card.background = bg(Color.WHITE, 18)
        card.setPadding(dp(20), dp(20), dp(20), dp(20))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        card.addView(logo, LinearLayout.LayoutParams(dp(64), dp(64)))
        card.addView(TextView(this).apply {
            text = "Simple Phone v2.4"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(DARK); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(6))
        })
        card.addView(TextView(this).apply {
            text = "Creator: Mohammod Abdul Awal\nStudent: Department of English, National University."
            textSize = 14f; setTextColor(GRAY); gravity = Gravity.CENTER
        })
        col.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(16), dp(16), dp(16)) })
        val sv = ScrollView(this)
        sv.addView(col)
        return sv
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 10 && req != 11) return
        val uri = data?.data ?: return
        if (res != RESULT_OK) return
        Thread {
            val msg = try { if (req == 10) doBackup(uri) else doRestore(uri) } catch (e: Exception) { "Error: " + e.message }
            runOnUiThread { toast(msg) }
        }.start()
    }

    private fun doBackup(uri: Uri): String {
        val cs = JSONArray()
        loadContacts().forEach { cs.put(JSONObject().put("name", it.name).put("number", it.num)) }
        val ms = JSONArray()
        contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body", "date", "type"), null, null, "date ASC")
            ?.use { c ->
                while (c.moveToNext()) ms.put(JSONObject()
                    .put("address", c.getString(0) ?: "").put("body", c.getString(1) ?: "")
                    .put("date", c.getLong(2)).put("type", c.getInt(3)))
            }
        val root = JSONObject().put("contacts", cs).put("sms", ms)
        contentResolver.openOutputStream(uri)?.use { it.write(root.toString().toByteArray()) }
        return "Backup done: ${cs.length()} contacts, ${ms.length()} SMS"
    }

    private fun doRestore(uri: Uri): String {
        val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
        val root = JSONObject(txt)
        val have = loadContacts().map { it.name + "|" + it.num }.toHashSet()
        var cc = 0; var sc = 0
        val cs = root.optJSONArray("contacts") ?: JSONArray()
        for (i in 0 until cs.length()) {
            val o = cs.getJSONObject(i)
            if (have.contains(o.getString("name") + "|" + o.getString("number"))) continue
            try { addContact(o.getString("name"), o.getString("number")); cc++ } catch (e: Exception) { }
        }
        val seen = HashSet<String>()
        try {
            contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "date"), null, null, null)?.use {
                while (it.moveToNext()) seen.add(it.getString(0) + "|" + it.getLong(1))
            }
        } catch (e: Exception) { }
        val ms = root.optJSONArray("sms") ?: JSONArray()
        for (i in 0 until ms.length()) {
            val o = ms.getJSONObject(i)
            if (seen.contains(o.optString("address") + "|" + o.optLong("date"))) continue
            try {
                val v = ContentValues().apply {
                    put("address", o.getString("address")); put("body", o.getString("body"))
                    put("date", o.getLong("date")); put("type", o.getInt("type")); put("read", 1)
                }
                if (contentResolver.insert(Uri.parse("content://sms"), v) != null) sc++
            } catch (e: Exception) { }
        }
        return "Restored: $cc contacts, $sc SMS (SMS restore needs default SMS app)"
    }
}
