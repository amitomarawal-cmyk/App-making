@file:Suppress("DEPRECATION")

package com.awal.simplephone

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.Telephony
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object CallManager {
    val calls = ArrayList<Call>()
    var service: InCallService? = null
    var onChange: (() -> Unit)? = null
    fun current(): Call? = calls.firstOrNull { it.state == Call.STATE_RINGING } ?: calls.lastOrNull()
    fun changed() { Handler(Looper.getMainLooper()).post { onChange?.invoke() } }
}

fun t9of(s: String): String {
    val sb = StringBuilder(s.length)
    for (ch in s.lowercase()) {
        sb.append(
            when (ch) {
                in 'a'..'c' -> '2'
                in 'd'..'f' -> '3'
                in 'g'..'i' -> '4'
                in 'j'..'l' -> '5'
                in 'm'..'o' -> '6'
                in 'p'..'s' -> '7'
                in 't'..'v' -> '8'
                in 'w'..'z' -> '9'
                in '0'..'9' -> ch
                else -> ' '
            }
        )
    }
    return sb.toString()
}

// T9 / digits আগে থেকেই হিসাব করা থাকে, তাই dial করার সময় প্রতি key-তে নতুন করে হিসাব লাগে না
class Contact(val id: Long, val key: String, val name: String, val num: String) {
    val t9: String = t9of(name)
    val words: List<String> = t9.split(" ").filter { it.isNotEmpty() }
    val digits: String = num.filter { it.isDigit() }
}

// একবার contacts লোড করে memory-তে রাখে। নাম খোঁজা = HashMap lookup (DB query নয়)।
object ContactCache {
    @Volatile var list: List<Contact>? = null
    @Volatile var dirty = true
    @Volatile private var names: Map<String, String> = emptyMap()

    // শেষ ১০ digit দিয়ে মেলানো হয়: +8801712345678 আর 01712345678 একই ধরা হয়
    fun key(num: String): String {
        val sb = StringBuilder()
        for (ch in num) {
            val d = Character.digit(ch, 10)
            if (d >= 0) sb.append(d)
        }
        return if (sb.length > 10) sb.substring(sb.length - 10) else sb.toString()
    }

    @Synchronized
    fun load(ctx: Context, force: Boolean = false): List<Contact> {
        val cur = list
        if (cur != null && !dirty && !force) return cur
        dirty = false
        val out = ArrayList<Contact>()
        var ok = false
        try {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.CONTACT_ID, Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER),
                null, null, Phone.DISPLAY_NAME + " ASC"
            )?.use { c ->
                while (c.moveToNext())
                    out.add(Contact(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: ""))
                ok = true
            }
        } catch (e: Exception) { }
        if (!ok) { dirty = true; return cur ?: out }
        val m = HashMap<String, String>(out.size * 2 + 16)
        for (c in out) {
            val k = key(c.num)
            if (k.isNotEmpty() && !m.containsKey(k)) m[k] = c.name
        }
        names = m
        list = out
        return out
    }

    // শুধু cache থেকে দেখে, DB-তে যায় না (main thread-এ নিরাপদ)
    fun peek(num: String): String? {
        if (list == null) return null
        val k = key(num)
        return if (k.isEmpty()) null else names[k]
    }

    fun nameOf(ctx: Context, num: String): String? {
        if (num.isBlank()) return null
        return if (list != null) peek(num) else Util.lookup(ctx, num)
    }
}

object Util {
    fun number(call: Call): String = call.details?.handle?.schemeSpecificPart ?: ""

    fun name(ctx: Context, num: String): String? = ContactCache.nameOf(ctx, num)

    fun lookup(ctx: Context, num: String): String? {
        if (num.isBlank()) return null
        return try {
            ctx.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    fun label(ctx: Context, call: Call): String {
        val n = number(call)
        return name(ctx, n) ?: (if (n.isBlank()) "Unknown" else n)
    }

    fun builder(ctx: Context, ch: String, chName: String, imp: Int): Notification.Builder {
        return if (Build.VERSION.SDK_INT >= 26) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val c = NotificationChannel(ch, chName, imp)
            if (ch == "calls") c.setSound(null, null)
            nm.createNotificationChannel(c)
            Notification.Builder(ctx, ch)
        } else Notification.Builder(ctx)
    }
}

class CallService : InCallService() {
    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) { CallManager.changed() }
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.calls.add(call)
        call.registerCallback(cb)
        val i = Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (call.state == Call.STATE_RINGING) {
            try {
                val pi = PendingIntent.getActivity(this, 0, i,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val n = Util.builder(this, "calls", "Calls", NotificationManager.IMPORTANCE_HIGH)
                    .setSmallIcon(android.R.drawable.sym_action_call)
                    .setContentTitle("Incoming call")
                    .setContentText(Util.label(this, call))
                    .setCategory(Notification.CATEGORY_CALL)
                    .setOngoing(true)
                    .setContentIntent(pi)
                    .setFullScreenIntent(pi, true)
                    .build()
                getSystemService(NotificationManager::class.java).notify(1, n)
            } catch (e: Exception) { }
        }
        try { startActivity(i) } catch (e: Exception) { }
        CallManager.changed()
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        call.unregisterCallback(cb)
        CallManager.calls.remove(call)
        try { getSystemService(NotificationManager::class.java).cancel(1) } catch (e: Exception) { }
        CallManager.changed()
    }
}

class InCallActivity : Activity() {
    private lateinit var nameTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var answerBtn: Button
    private lateinit var endBtn: Button
    private lateinit var muteBtn: Button
    private lateinit var spkBtn: Button
    private var muted = false
    private var speaker = false

    private fun mk(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 18f; setOnClickListener { f() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#101820"))
            setPadding(48, 48, 48, 48)
        }
        nameTv = TextView(this).apply { textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        statusTv = TextView(this).apply { textSize = 18f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        answerBtn = mk("Answer") {
            CallManager.current()?.answer(VideoProfile.STATE_AUDIO_ONLY)
        }
        endBtn = mk("End") {
            val c = CallManager.current()
            if (c != null) {
                if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
            }
        }
        muteBtn = mk("Mute") {
            muted = !muted
            CallManager.service?.setMuted(muted)
            muteBtn.text = if (muted) "Unmute" else "Mute"
        }
        spkBtn = mk("Speaker") {
            speaker = !speaker
            CallManager.service?.setAudioRoute(
                if (speaker) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE
            )
            spkBtn.text = if (speaker) "Speaker off" else "Speaker"
        }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(muteBtn); row.addView(spkBtn)
        root.addView(nameTv); root.addView(statusTv)
        root.addView(View(this), LinearLayout.LayoutParams(1, 120))
        root.addView(row); root.addView(answerBtn); root.addView(endBtn)
        setContentView(root)
        CallManager.onChange = { refresh() }
        refresh()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        refresh()
    }

    private fun refresh() {
        val c = CallManager.current()
        if (c == null) { finish(); return }
        nameTv.text = Util.label(this, c)
        val s = c.state
        statusTv.text = when (s) {
            Call.STATE_RINGING -> "Incoming call"
            Call.STATE_DIALING, Call.STATE_CONNECTING -> "Calling..."
            Call.STATE_ACTIVE -> "In call"
            Call.STATE_HOLDING -> "On hold"
            Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "Ending..."
            else -> "..."
        }
        val ringing = s == Call.STATE_RINGING
        answerBtn.visibility = if (ringing) View.VISIBLE else View.GONE
        muteBtn.visibility = if (ringing) View.GONE else View.VISIBLE
        spkBtn.visibility = if (ringing) View.GONE else View.VISIBLE
        endBtn.text = if (ringing) "Decline" else "End"
    }

    override fun onDestroy() {
        CallManager.onChange = null
        super.onDestroy()
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val map = LinkedHashMap<String, StringBuilder>()
        for (m in msgs) {
            map.getOrPut(m.originatingAddress ?: "") { StringBuilder() }.append(m.messageBody ?: "")
        }
        val now = System.currentTimeMillis()
        for ((addr, body) in map) {
            try {
                ctx.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, addr)
                    put(Telephony.Sms.BODY, body.toString())
                    put(Telephony.Sms.DATE, now)
                    put(Telephony.Sms.READ, 0)
                })
            } catch (e: Exception) { }
            try {
                val pi = PendingIntent.getActivity(ctx, addr.hashCode(),
                    Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val n = Util.builder(ctx, "sms", "Messages", NotificationManager.IMPORTANCE_DEFAULT)
                    .setSmallIcon(android.R.drawable.sym_action_email)
                    .setContentTitle(Util.name(ctx, addr) ?: addr)
                    .setContentText(body.toString())
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build()
                ctx.getSystemService(NotificationManager::class.java).notify(addr.hashCode(), n)
            } catch (e: Exception) { }
        }
    }
}

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { }
}

class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
