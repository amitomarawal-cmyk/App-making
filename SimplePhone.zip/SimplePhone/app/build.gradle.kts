plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.awal.simplephone"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.awal.simplephone"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "2.5"
    }
    buildTypes {
        // debug APK-ও যেন release-এর মতো দ্রুত চলে (debugger overhead বন্ধ)
        debug { isDebuggable = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
